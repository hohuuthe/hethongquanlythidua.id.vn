--
-- PostgreSQL database dump
--

\restrict EObl9lYRSfodcSqnOGcbWVKVmIBRuIVT6tgOOu4qEaoINxeZHOphkUfkmsZX4oa

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "quyen pknxkg_3" ON "storage"."objects";
DROP POLICY IF EXISTS "quyen pknxkg_2" ON "storage"."objects";
DROP POLICY IF EXISTS "quyen pknxkg_1" ON "storage"."objects";
DROP POLICY IF EXISTS "quyen pknxkg_0" ON "storage"."objects";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."theodoi360";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."ql_nop_bc";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."push_subscriptions";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Tài khoản đăng nhập thành công có full quyền trên " ON "public"."taikhoan";
DROP POLICY IF EXISTS "Public access tuanhoc" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Public access tieuchitd" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Public access taikhoan" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Public access settings" ON "public"."settings";
DROP POLICY IF EXISTS "Public access qlchidoan" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Public access ptdoanvien" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Public access phanquyen" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Public access phancong" ON "public"."phancong";
DROP POLICY IF EXISTS "Public access namhoc" ON "public"."namhoc";
DROP POLICY IF EXISTS "Public access dotptdoanvien" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Public access doanvien" ON "public"."doanvien";
DROP POLICY IF EXISTS "Public access chamdiem" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Public access activity_logs" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."xet_thidua";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."ql_baocao";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."phancong";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."namhoc";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."gio_hoc_tap";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."doanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."cauhinh_tieuchi_xet_thidua";
DROP POLICY IF EXISTS "Mọi người có thể xem tài khoản" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Mọi người có thể xem" ON "public"."settings";
DROP POLICY IF EXISTS "Mọi người có thể xem" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Mọi người có thể xem" ON "public"."github_settings";
DROP POLICY IF EXISTS "Chỉ Admin được sửa tài khoản" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."settings";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."github_settings";
DROP POLICY IF EXISTS "Cho phép đọc taikhoan để xác thực đăng nhập" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Cho phép mọi người xem duytricsdl" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Cho phép mọi người cập nhật duytricsdl" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "BCH chỉ được phép sửa" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "BCH chỉ được phép sửa" ON "public"."doanvien";
DROP POLICY IF EXISTS "Admin, BTV, NC có full quyền" ON "public"."gio_hoc_tap";
DROP POLICY IF EXISTS "Admin, BTV, NC có full quyền" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Admin, BTV, BGH, GVCN có full quyền" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Admin, BTV, BCH có full quyền" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Admin, BTV có full quyền" ON "public"."xet_thidua";
DROP POLICY IF EXISTS "Admin, BTV có full quyền" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."ql_baocao";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."phancong";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."namhoc";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."doanvien";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."cauhinh_tieuchi_xet_thidua";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_namhoc_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tuan_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tieu_chi_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nguoi_to_cao_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nam_hoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_doan_vien_vi_pham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "fk_tuanhoc_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "fk_tieuchitd_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_riengbiet" DROP CONSTRAINT IF EXISTS "fk_thongbao_riengbiet_taikhoan";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_riengbiet" DROP CONSTRAINT IF EXISTS "fk_thongbao_riengbiet_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "fk_settings_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "fk_qlchidoan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_doanvien";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_baocao";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "fk_ql_baocao_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "fk_ptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "fk_phanquyen_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "fk_phancong_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_tuan";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "fk_dotptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "fk_doanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "fk_chamdiem_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_doanvienid_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "cauhinh_tieuchi_xet_thidua_namhoc_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_namhoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_dotdangki_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP TRIGGER IF EXISTS "update_tuanhoc_modtime" ON "public"."tuanhoc";
DROP TRIGGER IF EXISTS "update_tieuchitd_modtime" ON "public"."tieuchitd";
DROP TRIGGER IF EXISTS "update_taikhoan_modtime" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "update_settings_modtime" ON "public"."settings";
DROP TRIGGER IF EXISTS "update_qlchidoan_modtime" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "update_ptdoanvien_modtime" ON "public"."ptdoanvien";
DROP TRIGGER IF EXISTS "update_phanquyen_modtime" ON "public"."phanquyen";
DROP TRIGGER IF EXISTS "update_phancong_modtime" ON "public"."phancong";
DROP TRIGGER IF EXISTS "update_namhoc_modtime" ON "public"."namhoc";
DROP TRIGGER IF EXISTS "update_github_settings_modtime" ON "public"."github_settings";
DROP TRIGGER IF EXISTS "update_duytricsdl_modtime" ON "public"."duytricsdl";
DROP TRIGGER IF EXISTS "update_dotptdoanvien_modtime" ON "public"."dotptdoanvien";
DROP TRIGGER IF EXISTS "update_doanvien_modtime" ON "public"."doanvien";
DROP TRIGGER IF EXISTS "update_chamdiem_modtime" ON "public"."chamdiem";
DROP TRIGGER IF EXISTS "trigger_chi_doan_deletion" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "trg_sync_taikhoan_to_auth" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "trg_hash_password_before_save" ON "public"."taikhoan";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name_lower";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_selec";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_xet_thidua_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_xet_thidua_chidoan";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_optimization_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_context";
DROP INDEX IF EXISTS "public"."idx_tuan_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_context";
DROP INDEX IF EXISTS "public"."idx_thongbao_riengbiet_sender";
DROP INDEX IF EXISTS "public"."idx_thongbao_riengbiet_namhoc";
DROP INDEX IF EXISTS "public"."idx_thongbao_riengbiet_dates";
DROP INDEX IF EXISTS "public"."idx_theodoi360_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_theodoi360_doanvien";
DROP INDEX IF EXISTS "public"."idx_taikhoan_username_lower";
DROP INDEX IF EXISTS "public"."idx_taikhoan_role";
DROP INDEX IF EXISTS "public"."idx_taikhoan_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_settings_namhoc";
DROP INDEX IF EXISTS "public"."idx_qlchidoan_optimization_namhoc";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_doanvien";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_chidoan";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_baocao";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dot";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien";
DROP INDEX IF EXISTS "public"."idx_phanquyen_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_lopcham";
DROP INDEX IF EXISTS "public"."idx_phancong_context";
DROP INDEX IF EXISTS "public"."idx_phancong_chamlop";
DROP INDEX IF EXISTS "public"."idx_namhoc_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_nam_hk";
DROP INDEX IF EXISTS "public"."idx_doanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_hoten";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_chamdiem_thongke";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_hocky_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_lopcham_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_loaitieuchi";
DROP INDEX IF EXISTS "public"."idx_chamdiem_hocky";
DROP INDEX IF EXISTS "public"."idx_chamdiem_doanvienid";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chamlop";
DROP INDEX IF EXISTS "public"."idx_cauhinh_thidua_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_activity_logs_user_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_created_at";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_users_name";
DROP INDEX IF EXISTS "auth"."idx_users_last_sign_in_at_desc";
DROP INDEX IF EXISTS "auth"."idx_users_email";
DROP INDEX IF EXISTS "auth"."idx_users_created_at_desc";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_payload_exclusive";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_20" DROP CONSTRAINT IF EXISTS "messages_2026_08_20_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_19" DROP CONSTRAINT IF EXISTS "messages_2026_08_19_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_18" DROP CONSTRAINT IF EXISTS "messages_2026_08_18_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_17" DROP CONSTRAINT IF EXISTS "messages_2026_08_17_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_16" DROP CONSTRAINT IF EXISTS "messages_2026_08_16_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_15" DROP CONSTRAINT IF EXISTS "messages_2026_08_15_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_14" DROP CONSTRAINT IF EXISTS "messages_2026_08_14_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_pkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "unique_xet_thidua_chidoan_hocky";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "unique_namhoc_tenchidoan";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "unique_chidoan_tuan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "unique_chamdiem_record";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "unique_cauhinh_namhoc_hocky";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "tuanhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_matieuchi_namhoc_hocky_unique";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_riengbiet" DROP CONSTRAINT IF EXISTS "thongbao_riengbiet_pkey";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_hethong" DROP CONSTRAINT IF EXISTS "thongbao_hethong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_pkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_ten_nam_unique";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "ql_nop_bc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "ql_baocao_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_endpoint_key";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "ptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_doi_tuong_tab_namhoc_unique";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."namhoc" DROP CONSTRAINT IF EXISTS "namhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."github_settings" DROP CONSTRAINT IF EXISTS "github_settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "gio_hoc_tap_pkey";
ALTER TABLE IF EXISTS ONLY "public"."duytricsdl" DROP CONSTRAINT IF EXISTS "duytricsdl_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "dotptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_pkey2";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "cauhinh_tieuchi_xet_thidua_pkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_20";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_19";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_18";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_17";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_16";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_15";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_14";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."xet_thidua";
DROP TABLE IF EXISTS "public"."tuanhoc";
DROP TABLE IF EXISTS "public"."tieuchitd";
DROP TABLE IF EXISTS "public"."thongbao_riengbiet";
DROP TABLE IF EXISTS "public"."thongbao_hethong";
DROP TABLE IF EXISTS "public"."theodoi360";
DROP TABLE IF EXISTS "public"."taikhoan";
DROP TABLE IF EXISTS "public"."settings";
DROP TABLE IF EXISTS "public"."qlchidoan";
DROP TABLE IF EXISTS "public"."ql_nop_bc";
DROP TABLE IF EXISTS "public"."ql_baocao";
DROP TABLE IF EXISTS "public"."push_subscriptions";
DROP TABLE IF EXISTS "public"."ptdoanvien";
DROP TABLE IF EXISTS "public"."phanquyen";
DROP TABLE IF EXISTS "public"."phancong";
DROP TABLE IF EXISTS "public"."namhoc";
DROP TABLE IF EXISTS "public"."github_settings";
DROP TABLE IF EXISTS "public"."gio_hoc_tap";
DROP TABLE IF EXISTS "public"."duytricsdl";
DROP TABLE IF EXISTS "public"."dotptdoanvien";
DROP TABLE IF EXISTS "public"."doanvien";
DROP TABLE IF EXISTS "public"."chamdiem";
DROP TABLE IF EXISTS "public"."cauhinh_tieuchi_xet_thidua";
DROP TABLE IF EXISTS "public"."activity_logs";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "storage"."allow_only_operation"("expected_operation" "text");
DROP FUNCTION IF EXISTS "storage"."allow_any_operation"("expected_operations" "text"[]);
DROP FUNCTION IF EXISTS "realtime"."wal2json_escape_identifier"("name" "text");
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "public"."update_modified_column"();
DROP FUNCTION IF EXISTS "public"."update_likes_count"();
DROP FUNCTION IF EXISTS "public"."sync_taikhoan_to_auth_users"();
DROP FUNCTION IF EXISTS "public"."rpc_get_user_by_username"("p_username" "text");
DROP FUNCTION IF EXISTS "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]);
DROP FUNCTION IF EXISTS "public"."rpc_authenticate_user"("p_username" "text", "p_password" "text");
DROP FUNCTION IF EXISTS "public"."hash_taikhoan_password_before_save"();
DROP FUNCTION IF EXISTS "public"."handle_update_likes_count"();
DROP FUNCTION IF EXISTS "public"."handle_post_like"();
DROP FUNCTION IF EXISTS "public"."handle_chi_doan_deletion"();
DROP FUNCTION IF EXISTS "public"."get_secure_role"();
DROP FUNCTION IF EXISTS "public"."get_secure_doanvien_id"();
DROP FUNCTION IF EXISTS "public"."get_secure_chidoan_id"();
DROP FUNCTION IF EXISTS "public"."get_auth_role"();
DROP FUNCTION IF EXISTS "public"."get_auth_doanvien_id"();
DROP FUNCTION IF EXISTS "public"."get_auth_chidoan_id"();
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP EXTENSION IF EXISTS "pg_graphql";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";


--
-- Name: EXTENSION "pg_graphql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_graphql" IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_realtime_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_realtime_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text",
	"negate" boolean
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_realtime_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: get_auth_chidoan_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_chidoan_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT chidoan_id FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_chidoan_id"() OWNER TO "postgres";

--
-- Name: get_auth_doanvien_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_doanvien_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT doanvien_id FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_doanvien_id"() OWNER TO "postgres";

--
-- Name: get_auth_role(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_role"() RETURNS "text"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT role FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_role"() OWNER TO "postgres";

--
-- Name: get_secure_chidoan_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_secure_chidoan_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT chidoan_id FROM public.taikhoan WHERE username = split_part(auth.email(), '@', 1) LIMIT 1;
$$;


ALTER FUNCTION "public"."get_secure_chidoan_id"() OWNER TO "postgres";

--
-- Name: get_secure_doanvien_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_secure_doanvien_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT doanvien_id FROM public.taikhoan WHERE username = split_part(auth.email(), '@', 1) LIMIT 1;
$$;


ALTER FUNCTION "public"."get_secure_doanvien_id"() OWNER TO "postgres";

--
-- Name: get_secure_role(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_secure_role"() RETURNS "text"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT role FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_secure_role"() OWNER TO "postgres";

--
-- Name: handle_chi_doan_deletion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_chi_doan_deletion"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Sửa "chiDoan" thành chidoan (viết thường, không cần ngoặc kép)
    DELETE FROM "doanvien" 
    WHERE chidoan = OLD.tenchidoan;
    
    RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chi_doan_deletion"() OWNER TO "postgres";

--
-- Name: handle_post_like(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_post_like"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_post_like"() OWNER TO "postgres";

--
-- Name: handle_update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_update_likes_count"() OWNER TO "postgres";

--
-- Name: hash_taikhoan_password_before_save(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."hash_taikhoan_password_before_save"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'extensions', 'public'
    AS $_$
BEGIN
  IF NEW.password IS NOT NULL AND NOT (NEW.password LIKE '$2a$%' OR NEW.password LIKE '$2b$%') THEN
    NEW.password := extensions.crypt(NEW.password, extensions.gen_salt('bf', 10));
  END IF;
  RETURN NEW;
END;
$_$;


ALTER FUNCTION "public"."hash_taikhoan_password_before_save"() OWNER TO "postgres";

--
-- Name: rpc_authenticate_user("text", "text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_authenticate_user"("p_username" "text", "p_password" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'extensions', 'public'
    AS $_$
DECLARE
  v_user RECORD;
  v_is_valid boolean := false;
BEGIN
  -- Tìm tài khoản trong bảng taikhoan
  IF lower(p_username) = 'admin' THEN
    SELECT * INTO v_user FROM public.taikhoan WHERE username IN ('Admin', 'admin') LIMIT 1;
  ELSE
    SELECT * INTO v_user FROM public.taikhoan WHERE lower(username) = lower(p_username) LIMIT 1;
  END IF;

  IF v_user.id IS NULL THEN
    RETURN NULL;
  END IF;

  -- Kiểm tra mật khẩu:
  -- TH1: Mật khẩu là chuỗi băm Bcrypt ($2a$ hoặc $2b$)
  IF v_user.password LIKE '$2a$%' OR v_user.password LIKE '$2b$%' THEN
    IF v_user.password = extensions.crypt(p_password, v_user.password) THEN
      v_is_valid := true;
    END IF;
  -- TH2: Mật khẩu là chuỗi thường (tự động nâng cấp sang Bcrypt)
  ELSE
    IF v_user.password = p_password THEN
      v_is_valid := true;
      UPDATE public.taikhoan 
      SET password = extensions.crypt(p_password, extensions.gen_salt('bf', 10))
      WHERE id = v_user.id;
    END IF;
  END IF;

  IF v_is_valid THEN
    -- Trả về dữ liệu tài khoản an toàn
    RETURN jsonb_build_object(
      'id', v_user.id,
      'username', v_user.username,
      'fullname', v_user.fullname,
      'role', v_user.role,
      'chidoan_id', v_user.chidoan_id,
      'sl_dangnhap', v_user.sl_dangnhap,
      'tg_truycap', v_user.tg_truycap
    );
  ELSE
    RETURN NULL;
  END IF;
END;
$_$;


ALTER FUNCTION "public"."rpc_authenticate_user"("p_username" "text", "p_password" "text") OWNER TO "postgres";

--
-- Name: rpc_delete_auth_users_by_usernames("text"[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth', 'extensions'
    AS $$
DECLARE
  v_uname text;
  v_safe text;
  v_emails text[] := '{}';
BEGIN
  IF p_usernames IS NULL OR array_length(p_usernames, 1) IS NULL THEN
    RETURN;
  END IF;

  FOREACH v_uname IN ARRAY p_usernames LOOP
    v_safe := lower(regexp_replace(v_uname, '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe <> '' THEN
      v_emails := array_append(v_emails, v_safe || '@htqltd.vn');
      v_emails := array_append(v_emails, v_safe || '@%');
    END IF;
  END LOOP;

  -- Xóa chính xác các người dùng tương ứng trong auth.users
  DELETE FROM auth.users WHERE email = ANY(v_emails) OR email ILIKE ANY(v_emails);
END;
$$;


ALTER FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) OWNER TO "postgres";

--
-- Name: rpc_get_user_by_username("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") RETURNS json
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user record;
  v_trimmed text;
BEGIN
  v_trimmed := trim(p_username);
  
  -- Tìm tài khoản Admin
  IF lower(v_trimmed) = 'admin' THEN
    SELECT * INTO v_user FROM public.taikhoan WHERE lower(username) = 'admin' LIMIT 1;
  ELSE
    -- Tìm không phân biệt hoa thường
    SELECT * INTO v_user FROM public.taikhoan WHERE username ILIKE v_trimmed LIMIT 1;
  END IF;

  -- Nếu không thấy, tìm khớp chính xác
  IF v_user IS NULL THEN
    SELECT * INTO v_user FROM public.taikhoan WHERE username = v_trimmed LIMIT 1;
  END IF;

  IF v_user IS NULL THEN
    RETURN NULL;
  END IF;

  RETURN row_to_json(v_user);
END;
$$;


ALTER FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") OWNER TO "postgres";

--
-- Name: sync_taikhoan_to_auth_users(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."sync_taikhoan_to_auth_users"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'extensions', 'auth', 'public'
    AS $_$
DECLARE
  v_safe_username text;
  v_mapped_email text;
  v_encrypted_pw text;
BEGIN
  -- XÓA TÀI KHOẢN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM auth.identities WHERE user_id = OLD.id OR provider_id = OLD.id::text;
    DELETE FROM auth.users WHERE id = OLD.id OR email = lower(regexp_replace(OLD.username, '[^a-zA-Z0-9_.-]', '', 'g')) || '@system.com';
    RETURN OLD;
  END IF;

  -- THÊM HOẶC SỬA TÀI KHOẢN
  v_safe_username := lower(regexp_replace(NEW.username, '[^a-zA-Z0-9_.-]', '', 'g'));
  IF v_safe_username = '' THEN
    v_safe_username := 'user_' || substr(replace(NEW.id::text, '-', ''), 1, 12);
  END IF;
  v_mapped_email := v_safe_username || '@system.com';
  v_encrypted_pw := NEW.password; -- Đã được Trigger BEFORE băm thành $2a$

  IF TG_OP = 'INSERT' THEN
    DELETE FROM auth.identities WHERE provider_id = NEW.id::text OR user_id = NEW.id;
    DELETE FROM auth.users WHERE id = NEW.id OR email = v_mapped_email;

    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      created_at,
      updated_at
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      NEW.id,
      'authenticated',
      'authenticated',
      v_mapped_email,
      v_encrypted_pw,
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      json_build_object('username', NEW.username, 'fullName', COALESCE(NEW.fullname, NEW.username), 'role', NEW.role)::jsonb,
      false,
      now(),
      now()
    );

    INSERT INTO auth.identities (
      id,
      provider_id,
      user_id,
      identity_data,
      provider,
      last_sign_in_at,
      created_at,
      updated_at
    ) VALUES (
      NEW.id,
      NEW.id::text,
      NEW.id,
      json_build_object('sub', NEW.id::text, 'email', v_mapped_email)::jsonb,
      'email',
      now(),
      now(),
      now()
    );

  ELSIF TG_OP = 'UPDATE' THEN
    UPDATE auth.users
    SET 
      email = v_mapped_email,
      encrypted_password = v_encrypted_pw,
      raw_user_meta_data = json_build_object('username', NEW.username, 'fullName', COALESCE(NEW.fullname, NEW.username), 'role', NEW.role)::jsonb,
      updated_at = now()
    WHERE id = NEW.id;

    UPDATE auth.identities
    SET 
      identity_data = json_build_object('sub', NEW.id::text, 'email', v_mapped_email)::jsonb,
      updated_at = now()
    WHERE user_id = NEW.id OR provider_id = NEW.id::text;
  END IF;

  RETURN NEW;
END;
$_$;


ALTER FUNCTION "public"."sync_taikhoan_to_auth_users"() OWNER TO "postgres";

--
-- Name: update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."update_likes_count"() OWNER TO "postgres";

--
-- Name: update_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_modified_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updatedat = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_modified_column"() OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) RETURNS boolean
    LANGUAGE "plpgsql" STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS TABLE("wal" "jsonb", "is_rls_enabled" boolean, "subscription_ids" "uuid"[], "errors" "text"[], "slot_changes_count" bigint)
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_realtime_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: send_binary("bytea", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_realtime_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: wal2json_escape_identifier("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: allow_any_operation("text"[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";

--
-- Name: allow_only_operation("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    RETURN _parts[array_length(_parts, 1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "custom_claims_allowlist" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "username" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "tab_name" "text" NOT NULL,
    "table_name" "text" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid"
);


ALTER TABLE "public"."activity_logs" OWNER TO "postgres";

--
-- Name: cauhinh_tieuchi_xet_thidua; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."cauhinh_tieuchi_xet_thidua" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "hoc_ky" character varying(20) NOT NULL,
    "ten_tieuchi_1" character varying(255) DEFAULT 'Tiêu chí 1'::character varying,
    "sudung_1" boolean DEFAULT true,
    "kieudulieu_1" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_2" character varying(255) DEFAULT 'Tiêu chí 2'::character varying,
    "sudung_2" boolean DEFAULT true,
    "kieudulieu_2" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_3" character varying(255) DEFAULT 'Tiêu chí 3'::character varying,
    "sudung_3" boolean DEFAULT true,
    "kieudulieu_3" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_4" character varying(255) DEFAULT 'Tiêu chí 4'::character varying,
    "sudung_4" boolean DEFAULT true,
    "kieudulieu_4" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_5" character varying(255) DEFAULT 'Tiêu chí 5'::character varying,
    "sudung_5" boolean DEFAULT true,
    "kieudulieu_5" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_6" character varying(255) DEFAULT 'Tiêu chí 6'::character varying,
    "sudung_6" boolean DEFAULT false,
    "kieudulieu_6" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_7" character varying(255) DEFAULT 'Tiêu chí 7'::character varying,
    "sudung_7" boolean DEFAULT false,
    "kieudulieu_7" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_8" character varying(255) DEFAULT 'Tiêu chí 8'::character varying,
    "sudung_8" boolean DEFAULT false,
    "kieudulieu_8" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_9" character varying(255) DEFAULT 'Tiêu chí 9'::character varying,
    "sudung_9" boolean DEFAULT false,
    "kieudulieu_9" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_10" character varying(255) DEFAULT 'Tiêu chí 10'::character varying,
    "sudung_10" boolean DEFAULT false,
    "kieudulieu_10" character varying(20) DEFAULT 'NUMBER'::character varying,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "ghi_chu" "text",
    "giai_thich" "text",
    "trang_thai" character varying(30) DEFAULT 'dang_xet'::character varying,
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_hoc_ky_check" CHECK ((("hoc_ky")::"text" = ANY (ARRAY[('HK1'::character varying)::"text", ('HK2'::character varying)::"text", ('CA_NAM'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_10_check" CHECK ((("kieudulieu_10")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_1_check" CHECK ((("kieudulieu_1")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_2_check" CHECK ((("kieudulieu_2")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_3_check" CHECK ((("kieudulieu_3")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_4_check" CHECK ((("kieudulieu_4")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_5_check" CHECK ((("kieudulieu_5")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_6_check" CHECK ((("kieudulieu_6")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_7_check" CHECK ((("kieudulieu_7")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_8_check" CHECK ((("kieudulieu_8")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_9_check" CHECK ((("kieudulieu_9")::"text" = ANY (ARRAY[('NUMBER'::character varying)::"text", ('TEXT'::character varying)::"text"]))),
    CONSTRAINT "chk_cauhinh_trang_thai" CHECK ((("trang_thai")::"text" = ANY (ARRAY[('dang_xet'::character varying)::"text", ('ban_du_thao'::character varying)::"text", ('ban_cong_bo'::character varying)::"text"])))
);


ALTER TABLE "public"."cauhinh_tieuchi_xet_thidua" OWNER TO "postgres";

--
-- Name: chamdiem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."chamdiem" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "namhoc" "uuid",
    "hocky" "text",
    "tuan" "text",
    "thu" "text",
    "ngay" "text",
    "lopcham" "uuid",
    "chamlop" "uuid",
    "doanvienid" "uuid",
    "hotendoanvien" "text",
    "matieuchi" "text",
    "tentieuchi" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "nguoicham" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."chamdiem" OWNER TO "postgres";

--
-- Name: doanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."doanvien" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hoten" "text" NOT NULL,
    "ngaysinh" "text",
    "gioitinh" "text",
    "dantoc" "text",
    "doituong" "text",
    "doanvien" boolean DEFAULT false,
    "chidoan" "text",
    "ngayvaodoan" "text",
    "sdt" "text",
    "thongtinthem" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "diachi" "text",
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."doanvien" OWNER TO "postgres";

--
-- Name: dotptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."dotptdoanvien" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tendot" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."dotptdoanvien" OWNER TO "postgres";

--
-- Name: duytricsdl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."duytricsdl" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "so" bigint DEFAULT 0,
    "thoigian" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."duytricsdl" OWNER TO "postgres";

--
-- Name: gio_hoc_tap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."gio_hoc_tap" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "chidoan_id" "uuid" NOT NULL,
    "tuan_id" "uuid" NOT NULL,
    "so_tot" integer DEFAULT 0,
    "so_kha" integer DEFAULT 0,
    "so_tb" integer DEFAULT 0,
    "so_yeu" integer DEFAULT 0,
    "diem_tot_cauhinh" numeric DEFAULT 10,
    "diem_kha_cauhinh" numeric DEFAULT 7,
    "diem_tb_cauhinh" numeric DEFAULT 4,
    "diem_yeu_cauhinh" numeric DEFAULT 1,
    "diem_tb_hoc_tap" numeric(5,2) DEFAULT 0.00,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()),
    "hocky" "text"
);


ALTER TABLE "public"."gio_hoc_tap" OWNER TO "postgres";

--
-- Name: TABLE "gio_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."gio_hoc_tap" IS 'Bảng quản lý giờ học tập và điểm trung bình học tập của Chi đoàn theo tuần và năm học';


--
-- Name: COLUMN "gio_hoc_tap"."namhoc_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."namhoc_id" IS 'Liên kết với năm học hiện tại';


--
-- Name: COLUMN "gio_hoc_tap"."chidoan_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."chidoan_id" IS 'Liên kết với Chi đoàn được xếp loại giờ học';


--
-- Name: COLUMN "gio_hoc_tap"."tuan_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."tuan_id" IS 'Liên kết với tuần học tương ứng';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tot_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tot_cauhinh" IS 'Điểm cấu hình của giờ Tốt tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_kha_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_kha_cauhinh" IS 'Điểm cấu hình của giờ Khá tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tb_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tb_cauhinh" IS 'Điểm cấu hình của giờ Trung bình tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_yeu_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_yeu_cauhinh" IS 'Điểm cấu hình của giờ Yếu tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tb_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tb_hoc_tap" IS 'Điểm trung bình học tập thực tế cuối cùng của tuần';


--
-- Name: COLUMN "gio_hoc_tap"."hocky"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."hocky" IS 'Học kỳ diễn ra tuần học tập (ví dụ: HK1, HK2)';


--
-- Name: github_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."github_settings" (
    "id" "text" NOT NULL,
    "github_repo_path" "text",
    "github_branch" "text" DEFAULT 'main'::"text",
    "github_workflow_file" "text" DEFAULT 'supabase-backup.yml'::"text",
    "github_restore_workflow_file" "text" DEFAULT 'supabase-restore.yml'::"text",
    "github_token" "text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" "text",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."github_settings" OWNER TO "postgres";

--
-- Name: namhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."namhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tennamhoc" "text" NOT NULL,
    "islocked" boolean DEFAULT false,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "isdefault" boolean DEFAULT false
);


ALTER TABLE "public"."namhoc" OWNER TO "postgres";

--
-- Name: phancong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phancong" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "lopcham" "uuid" NOT NULL,
    "chamlop" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."phancong" OWNER TO "postgres";

--
-- Name: phanquyen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phanquyen" (
    "id" bigint NOT NULL,
    "doi_tuong" character varying(50) NOT NULL,
    "tab_chuc_nang" character varying(100) NOT NULL,
    "ngay_cap_nhat" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "nam_hoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "quyen_xem" boolean DEFAULT false,
    "quyen_them" boolean DEFAULT false,
    "quyen_sua" boolean DEFAULT false,
    "quyen_xoa" boolean DEFAULT false,
    "giai_thich" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."phanquyen" OWNER TO "postgres";

--
-- Name: TABLE "phanquyen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."phanquyen" IS 'Bảng cấu hình phân quyền động cho hệ thống';


--
-- Name: COLUMN "phanquyen"."doi_tuong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."doi_tuong" IS 'Vai trò của người dùng (Admin, BTV, BCH, BT, DV)';


--
-- Name: COLUMN "phanquyen"."tab_chuc_nang"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."tab_chuc_nang" IS 'Mã tab chức năng trên giao diện';


--
-- Name: phanquyen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."phanquyen_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ptdoanvien" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "doanvien_id" "uuid",
    "dotdangki" "uuid",
    "thongkerenluyen" "text",
    "diemrenluyen" integer DEFAULT 0,
    "pheduyet" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "soquyetdinh" "text",
    "ngayquyetdinh" "date"
);


ALTER TABLE "public"."ptdoanvien" OWNER TO "postgres";

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."push_subscriptions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "text",
    "chidoan_id" "uuid",
    "subscription" "jsonb" NOT NULL,
    "endpoint" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."push_subscriptions" OWNER TO "postgres";

--
-- Name: ql_baocao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_baocao" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "chu_de" "text" NOT NULL,
    "chu_de_phu" "text",
    "tu_ngay" "date",
    "den_ngay" "date",
    "cho_phep_minh_chung" boolean DEFAULT true,
    "doi_tuong_nop" "text",
    "huong_dan" "text",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "nam_hoc_id" "uuid",
    "hoc_ky" "text",
    "config_noi_dung1" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 1", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung2" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 2", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung3" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 3", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung4" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 4", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung5" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 5", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung6" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 6", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung7" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 7", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung8" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 8", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung9" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 9", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung10" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 10", "enabled": true, "options": "", "required": false}'::"jsonb",
    "allowed_file_types" "text" DEFAULT 'image,video,pdf,doc'::"text",
    "max_file_size" integer DEFAULT 10
);


ALTER TABLE "public"."ql_baocao" OWNER TO "postgres";

--
-- Name: COLUMN "ql_baocao"."config_noi_dung1"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung1" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 1';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung2"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung2" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 2';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung3"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung3" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 3';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung4"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung4" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 4';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung5"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung5" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 5';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung6"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung6" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 6';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung7"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung7" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 7';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung8"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung8" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 8';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung9"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung9" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 9';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung10"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung10" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 10';


--
-- Name: ql_nop_bc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_nop_bc" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "ql_bao_cao_id" "uuid" NOT NULL,
    "doanvien_id" "uuid",
    "noi_dung1" "text",
    "noi_dung2" "text",
    "noi_dung3" "text",
    "noi_dung4" "text",
    "noi_dung5" "text",
    "noi_dung6" "text",
    "noi_dung7" "text",
    "noi_dung8" "text",
    "noi_dung9" "text",
    "noi_dung10" "text",
    "duong_dan_minh_chung" "text",
    "ghi_chu" "text",
    "trang_thai" "text",
    "ngay_capnhat" timestamp with time zone DEFAULT "now"(),
    "chi_doan_id" "uuid",
    "danh_sach_anh" "text",
    "vaitro_nop" "text",
    "doituong_nop" "text",
    "nguoi_tao_id" "text"
);


ALTER TABLE "public"."ql_nop_bc" OWNER TO "postgres";

--
-- Name: COLUMN "ql_nop_bc"."danh_sach_anh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_nop_bc"."danh_sach_anh" IS 'Danh sách liên kết các ảnh minh chứng tải lên R2, phân tách bằng dấu phẩy';


--
-- Name: qlchidoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."qlchidoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenchidoan" "text" NOT NULL,
    "buoihoc" "text" NOT NULL,
    "ban" "text",
    "phonghoc" "text",
    "bithu" "text",
    "gvcn" "text",
    "namhoc" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "he_so_tru" numeric DEFAULT 1,
    "he_so_cong" numeric DEFAULT 1
);


ALTER TABLE "public"."qlchidoan" OWNER TO "postgres";

--
-- Name: COLUMN "qlchidoan"."he_so_tru"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."qlchidoan"."he_so_tru" IS 'Hệ số nhân điểm trừ riêng biệt cho từng Chi đoàn';


--
-- Name: COLUMN "qlchidoan"."he_so_cong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."qlchidoan"."he_so_cong" IS 'Hệ số nhân điểm cộng riêng biệt cho từng Chi đoàn';


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."settings" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title1" "text",
    "title2" "text",
    "diemsan" numeric,
    "aiprompttemplate" "text",
    "geminiapikey" "text",
    "diemsanhocky" numeric DEFAULT 0,
    "aiassistantprompt" "text",
    "thongbaochamdiem" "text",
    "doituongthongbao" "text",
    "noidungthongbao" "text",
    "thongbaodoanvien" "text",
    "autopenaltytime" "text" DEFAULT '23:55'::"text",
    "autopenaltypoints" integer DEFAULT 30,
    "autopenaltycriteria" "text" DEFAULT 'Lỗi không báo cáo điểm tuần'::"text",
    "autopenaltyenabled" boolean DEFAULT false,
    "autopenaltyreporter" "text" DEFAULT 'Hệ thống tự động'::"text",
    "autopenaltyday" integer DEFAULT 0,
    "thongbaophattriendoan" "text" DEFAULT ''::"text",
    "excel_header_left" "text",
    "excel_header_right" "text",
    "excel_footer_left" "text",
    "excel_footer_right" "text",
    "word_header_left" "text",
    "word_header_right" "text",
    "word_footer_left" "text",
    "word_footer_right" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "cloudinary_cloud_name" "text",
    "cloudinary_upload_preset" "text",
    "cloudinary_api_key" "text",
    "cloudinary_api_secret" "text",
    "r2_account_id" "text",
    "r2_access_key_id" "text",
    "r2_secret_access_key" "text",
    "r2_bucket_name" "text",
    "r2_custom_domain" "text",
    "show_class_select_gvcn" "text" DEFAULT 'Không hiển thị'::"text",
    "diem_tot" numeric DEFAULT 10,
    "diem_kha" numeric DEFAULT 7,
    "diem_tb" numeric DEFAULT 4,
    "diem_yeu" numeric DEFAULT 1,
    "ti_trong_diem_tuan" numeric DEFAULT 50,
    "ti_trong_diem_hoc_tap" numeric DEFAULT 50
);


ALTER TABLE "public"."settings" OWNER TO "postgres";

--
-- Name: COLUMN "settings"."autopenaltytime"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltytime" IS 'Giờ kiểm tra xử phạt tự động vào Chủ Nhật';


--
-- Name: COLUMN "settings"."autopenaltypoints"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltypoints" IS 'Số điểm trừ khi vi phạm lỗi không nhập điểm';


--
-- Name: COLUMN "settings"."autopenaltycriteria"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltycriteria" IS 'Tên tiêu chí hiển thị khi xử phạt';


--
-- Name: COLUMN "settings"."autopenaltyenabled"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyenabled" IS 'Trạng thái bật/tắt chức năng xử phạt tự động';


--
-- Name: COLUMN "settings"."autopenaltyreporter"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyreporter" IS 'Tên người chấm hiển thị trong bảng điểm';


--
-- Name: COLUMN "settings"."diem_tot"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_tot" IS 'Điểm cấu hình mặc định cho giờ Tốt (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_kha"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_kha" IS 'Điểm cấu hình mặc định cho giờ Khá (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_tb"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_tb" IS 'Điểm cấu hình mặc định cho giờ Trung bình (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_yeu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_yeu" IS 'Điểm cấu hình mặc định cho giờ Yếu (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."ti_trong_diem_tuan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."ti_trong_diem_tuan" IS 'Tỉ trọng % đóng góp của điểm tuần (trừ vi phạm) vào tổng điểm thi đua chung';


--
-- Name: COLUMN "settings"."ti_trong_diem_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."ti_trong_diem_hoc_tap" IS 'Tỉ trọng % đóng góp của điểm trung bình giờ học tập vào tổng điểm thi đua chung';


--
-- Name: taikhoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."taikhoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "username" "text" NOT NULL,
    "password" "text" NOT NULL,
    "fullname" "text" NOT NULL,
    "role" "text" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "doanvien_id" "uuid",
    "sl_dangnhap" integer DEFAULT 0,
    "tg_truycap" timestamp with time zone
);


ALTER TABLE "public"."taikhoan" OWNER TO "postgres";

--
-- Name: theodoi360; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."theodoi360" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nguoi_to_cao_id" "uuid" NOT NULL,
    "doan_vien_vi_pham_id" "uuid" NOT NULL,
    "tieu_chi_id" "uuid" NOT NULL,
    "chi_tiet_vi_pham" "text",
    "danh_sach_hinh_anh" "jsonb" DEFAULT '[]'::"jsonb",
    "url_video" "text",
    "trang_thai" "text" DEFAULT 'cho_duyet'::"text",
    "nam_hoc_id" "uuid" NOT NULL,
    "tuan_id" "uuid" NOT NULL,
    "ngay_vi_pham" "date",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "hoc_ky" "text",
    "phan_hoi_bi_to_cao" "text",
    "phan_hoi_lop" "text",
    "minh_chung_drive" "text"
);


ALTER TABLE "public"."theodoi360" OWNER TO "postgres";

--
-- Name: thongbao_hethong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_hethong" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "sender" "text" DEFAULT 'Hệ thống'::"text",
    "target_role" "text" DEFAULT 'all'::"text",
    "target_chidoan_id" "uuid",
    "target_user_id" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "read_by" "jsonb" DEFAULT '[]'::"jsonb"
);


ALTER TABLE "public"."thongbao_hethong" OWNER TO "postgres";

--
-- Name: thongbao_riengbiet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_riengbiet" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "sender_id" "uuid" NOT NULL,
    "sender_name" "text" NOT NULL,
    "sender_role" "text" NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "attachments" "jsonb" DEFAULT '[]'::"jsonb",
    "target_roles" "jsonb" DEFAULT '[]'::"jsonb",
    "target_chidoan_ids" "jsonb" DEFAULT '[]'::"jsonb",
    "start_at" timestamp with time zone DEFAULT "now"(),
    "end_at" timestamp with time zone NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "read_by" "jsonb" DEFAULT '[]'::"jsonb"
);


ALTER TABLE "public"."thongbao_riengbiet" OWNER TO "postgres";

--
-- Name: tieuchitd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tieuchitd" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "matieuchi" "text" NOT NULL,
    "tentieuchi" "text" NOT NULL,
    "mota" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "hocky" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tieuchitd" OWNER TO "postgres";

--
-- Name: tuanhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tuanhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tuanhoc" OWNER TO "postgres";

--
-- Name: xet_thidua; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."xet_thidua" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "hoc_ky" character varying(20) NOT NULL,
    "chidoan_id" "uuid" NOT NULL,
    "tong_diem_cham_tuan" numeric(10,2) DEFAULT 0,
    "tieuchi_1" "text" DEFAULT ''::"text",
    "tieuchi_2" "text" DEFAULT ''::"text",
    "tieuchi_3" "text" DEFAULT ''::"text",
    "tieuchi_4" "text" DEFAULT ''::"text",
    "tieuchi_5" "text" DEFAULT ''::"text",
    "tieuchi_6" "text" DEFAULT ''::"text",
    "tieuchi_7" "text" DEFAULT ''::"text",
    "tieuchi_8" "text" DEFAULT ''::"text",
    "tieuchi_9" "text" DEFAULT ''::"text",
    "tieuchi_10" "text" DEFAULT ''::"text",
    "tong_diem" numeric(10,2) DEFAULT 0,
    "xep_hang" integer,
    "danh_hieu_thi_dua" character varying(255) DEFAULT ''::character varying,
    "ghi_chu" "text" DEFAULT ''::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "xet_thidua_hoc_ky_check" CHECK ((("hoc_ky")::"text" = ANY (ARRAY[('HK1'::character varying)::"text", ('HK2'::character varying)::"text", ('CA_NAM'::character varying)::"text"])))
);


ALTER TABLE "public"."xet_thidua" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_14; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_14" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_14" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_15; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_15" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_15" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_16; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_16" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_16" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_17; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_17" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_17" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_18; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_18" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_18" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_19; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_19" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_19" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_20; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_20" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_20" OWNER TO "supabase_realtime_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone DEFAULT "now"()
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    "selected_columns" "text"[],
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_08_14; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_14" FOR VALUES FROM ('2026-08-14 00:00:00') TO ('2026-08-15 00:00:00');


--
-- Name: messages_2026_08_15; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_15" FOR VALUES FROM ('2026-08-15 00:00:00') TO ('2026-08-16 00:00:00');


--
-- Name: messages_2026_08_16; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_16" FOR VALUES FROM ('2026-08-16 00:00:00') TO ('2026-08-17 00:00:00');


--
-- Name: messages_2026_08_17; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_17" FOR VALUES FROM ('2026-08-17 00:00:00') TO ('2026-08-18 00:00:00');


--
-- Name: messages_2026_08_18; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_18" FOR VALUES FROM ('2026-08-18 00:00:00') TO ('2026-08-19 00:00:00');


--
-- Name: messages_2026_08_19; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_19" FOR VALUES FROM ('2026-08-19 00:00:00') TO ('2026-08-20 00:00:00');


--
-- Name: messages_2026_08_20; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_20" FOR VALUES FROM ('2026-08-20 00:00:00') TO ('2026-08-21 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at", "custom_claims_allowlist") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
d60dd419-93ee-4570-9a5d-87a81f540576	d60dd419-93ee-4570-9a5d-87a81f540576	{"sub": "d60dd419-93ee-4570-9a5d-87a81f540576", "email": "nguoicham12b109l1f7@htqltd.vn", "email_verified": false, "phone_verified": false}	email	2026-08-15 23:42:00.98498+00	2026-08-15 23:42:00.985045+00	2026-08-15 23:42:00.985045+00	26895931-17df-4957-9699-9f43f1e1e3fd
140cd2a9-fd20-492f-8d0e-598929dcf97c	140cd2a9-fd20-492f-8d0e-598929dcf97c	{"sub": "140cd2a9-fd20-492f-8d0e-598929dcf97c", "email": "admin@htqltd.vn", "email_verified": false, "phone_verified": false}	email	2026-08-15 07:29:29.673587+00	2026-08-15 07:29:29.673635+00	2026-08-15 07:29:29.673635+00	f70ab3e0-b98f-441f-815c-ce8d3f3ae570
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
764d22b6-f865-46cf-8323-e62599face82	2026-08-15 15:25:22.873603+00	2026-08-15 15:25:22.873603+00	password	21aac056-a344-42bb-ab7a-e04e8f8bb29a
c663a01f-cdfe-4892-9dc8-38b74a120c3a	2026-08-15 15:38:39.899679+00	2026-08-15 15:38:39.899679+00	password	34194120-b3cb-459d-883b-9626bb5963e2
4b6e12c9-eea0-482d-aa77-8768a71594dc	2026-08-15 23:31:52.321299+00	2026-08-15 23:31:52.321299+00	password	a0d3e374-fd0b-42a2-9d0a-46ff71c96d86
41f917ce-4140-4432-b86d-2f2177fb0570	2026-08-15 23:42:01.025907+00	2026-08-15 23:42:01.025907+00	password	724d940c-5943-4b99-a3ff-ad528b12a1de
21d66a84-79f0-41d6-b20d-a9140f8e6143	2026-08-15 23:43:03.954668+00	2026-08-15 23:43:03.954668+00	password	00fe8a09-e5ae-44e7-8070-50cdec4a6fb3
48b20247-75a5-4fd6-ad47-964164159995	2026-08-15 23:43:44.531906+00	2026-08-15 23:43:44.531906+00	password	35c0450a-72c8-4c0c-a012-7cb2c9a91d46
63944591-740d-4bdc-9bba-fc62456509f6	2026-08-16 00:04:28.537019+00	2026-08-16 00:04:28.537019+00	password	9c7795c3-9714-4806-a30d-2b83fdef6496
57552965-dce2-439e-8437-ddc2b155e1fc	2026-08-16 00:50:43.798932+00	2026-08-16 00:50:43.798932+00	password	110e7817-e158-429b-9f6b-7428c52e3471
fa081a34-6358-477e-a04e-1402a3e9b762	2026-08-16 00:51:58.106295+00	2026-08-16 00:51:58.106295+00	password	34d76abb-6639-46f5-b643-2ffd4578a086
75e35ff1-7c64-4f44-8324-02c4f6d9afe5	2026-08-16 03:03:19.586142+00	2026-08-16 03:03:19.586142+00	password	92dee10d-9a84-4048-9497-5b31c05bc529
f215be6a-f969-402f-bdb4-8d2cc4dd9038	2026-08-16 06:57:53.495712+00	2026-08-16 06:57:53.495712+00	password	2c5c6646-4938-412a-9e64-166c9b74ee78
7056f734-37d3-4866-8f41-9281a6a65188	2026-08-16 23:19:55.132759+00	2026-08-16 23:19:55.132759+00	password	a257ab1c-cd83-40ff-b303-7fb79f6b6148
fefba1f5-3bae-402d-ad91-1301b97468c1	2026-08-17 00:19:58.561998+00	2026-08-17 00:19:58.561998+00	password	feb4abbd-d713-49b5-a68f-b7c08bf28c6a
2ce0fbc4-8cdd-4199-ab21-7021d2a5e507	2026-08-17 04:20:14.779542+00	2026-08-17 04:20:14.779542+00	password	f3bc29fc-79cf-4b61-aecf-6849ff05e991
f2363b1d-2d54-46ec-af7b-8453fa8008e7	2026-08-17 05:46:45.835925+00	2026-08-17 05:46:45.835925+00	password	78443407-e322-44c6-85cd-cf4a14ceeaec
67a02f68-ce4a-4190-813c-f7ac37d3d853	2026-08-17 05:47:03.378553+00	2026-08-17 05:47:03.378553+00	password	6ebee95b-4741-412b-89e5-4c79e0efdfdc
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	2267	tnfiqechy5sq	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 09:01:21.035972+00	2026-08-16 15:44:38.448553+00	qqazo3wpzftq	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	2268	f7io66zlxjos	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 15:44:38.456119+00	2026-08-16 21:49:13.089246+00	tnfiqechy5sq	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	2269	itkpsbuq4hlc	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 21:49:13.110296+00	2026-08-16 22:48:42.472476+00	f7io66zlxjos	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	75	6sishrarqqcz	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-15 15:25:22.867164+00	2026-08-15 22:58:43.636611+00	\N	764d22b6-f865-46cf-8323-e62599face82
00000000-0000-0000-0000-000000000000	77	pmu5v2dtxgel	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-15 22:58:43.647866+00	2026-08-15 22:58:43.647866+00	6sishrarqqcz	764d22b6-f865-46cf-8323-e62599face82
00000000-0000-0000-0000-000000000000	78	jlz5x5mywgl2	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-15 23:31:52.298989+00	2026-08-15 23:31:52.298989+00	\N	4b6e12c9-eea0-482d-aa77-8768a71594dc
00000000-0000-0000-0000-000000000000	79	w26db2o5oe64	d60dd419-93ee-4570-9a5d-87a81f540576	f	2026-08-15 23:42:01.008206+00	2026-08-15 23:42:01.008206+00	\N	41f917ce-4140-4432-b86d-2f2177fb0570
00000000-0000-0000-0000-000000000000	80	kx2nvth4dqtg	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-15 23:43:03.913724+00	2026-08-15 23:43:03.913724+00	\N	21d66a84-79f0-41d6-b20d-a9140f8e6143
00000000-0000-0000-0000-000000000000	81	ko4gxgulxvly	d60dd419-93ee-4570-9a5d-87a81f540576	f	2026-08-15 23:43:44.527042+00	2026-08-15 23:43:44.527042+00	\N	48b20247-75a5-4fd6-ad47-964164159995
00000000-0000-0000-0000-000000000000	76	zoiukm7637wb	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-15 15:38:39.877205+00	2026-08-16 00:50:31.023537+00	\N	c663a01f-cdfe-4892-9dc8-38b74a120c3a
00000000-0000-0000-0000-000000000000	83	evuill7il22p	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-16 00:50:31.047866+00	2026-08-16 00:50:31.047866+00	zoiukm7637wb	c663a01f-cdfe-4892-9dc8-38b74a120c3a
00000000-0000-0000-0000-000000000000	84	mjxmr6jzovdl	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-16 00:50:43.790268+00	2026-08-16 00:50:43.790268+00	\N	57552965-dce2-439e-8437-ddc2b155e1fc
00000000-0000-0000-0000-000000000000	82	ottfwtdon7gk	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 00:04:28.517285+00	2026-08-16 01:02:38.216404+00	\N	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	2270	lugpft7da3np	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 22:48:42.487539+00	2026-08-17 02:20:50.530084+00	itkpsbuq4hlc	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	85	5byrodfbnix5	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 00:51:58.10039+00	2026-08-16 01:51:21.311008+00	\N	fa081a34-6358-477e-a04e-1402a3e9b762
00000000-0000-0000-0000-000000000000	86	qxsvdvneqxqm	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 01:02:38.228799+00	2026-08-16 02:00:41.99325+00	ottfwtdon7gk	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	87	6uqmr7dqkmcp	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 01:51:21.336672+00	2026-08-16 02:50:21.029855+00	5byrodfbnix5	fa081a34-6358-477e-a04e-1402a3e9b762
00000000-0000-0000-0000-000000000000	89	5vhrldcft73h	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-16 02:50:21.049887+00	2026-08-16 02:50:21.049887+00	6uqmr7dqkmcp	fa081a34-6358-477e-a04e-1402a3e9b762
00000000-0000-0000-0000-000000000000	88	rtg3etkfvauc	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 02:00:41.998735+00	2026-08-16 02:59:21.307608+00	qxsvdvneqxqm	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	91	fhn5xjxdpudz	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-16 03:03:19.579688+00	2026-08-16 03:03:19.579688+00	\N	75e35ff1-7c64-4f44-8324-02c4f6d9afe5
00000000-0000-0000-0000-000000000000	90	cxm6pckzu2rc	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 02:59:21.320515+00	2026-08-16 07:04:11.152528+00	rtg3etkfvauc	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	92	i23pxxizty73	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 06:57:53.477863+00	2026-08-16 07:57:20.938178+00	\N	f215be6a-f969-402f-bdb4-8d2cc4dd9038
00000000-0000-0000-0000-000000000000	93	sny2vcy4xjx6	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 07:04:11.166071+00	2026-08-16 08:02:44.798145+00	cxm6pckzu2rc	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	94	cwer6u2oock4	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 07:57:20.957197+00	2026-08-16 08:56:20.81923+00	i23pxxizty73	f215be6a-f969-402f-bdb4-8d2cc4dd9038
00000000-0000-0000-0000-000000000000	95	qqazo3wpzftq	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 08:02:44.812131+00	2026-08-16 09:01:21.028633+00	sny2vcy4xjx6	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	2272	r5ieyp7ct2wd	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-17 00:19:58.527187+00	2026-08-17 00:19:58.527187+00	\N	fefba1f5-3bae-402d-ad91-1301b97468c1
00000000-0000-0000-0000-000000000000	2271	i6o3oribrjka	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 23:19:55.108246+00	2026-08-17 02:20:50.531276+00	\N	7056f734-37d3-4866-8f41-9281a6a65188
00000000-0000-0000-0000-000000000000	2274	33iq2uisnlue	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-17 02:20:50.544969+00	2026-08-17 03:19:32.528735+00	lugpft7da3np	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	2275	vm4wgqkbbay6	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-17 03:19:32.545087+00	2026-08-17 03:19:32.545087+00	33iq2uisnlue	63944591-740d-4bdc-9bba-fc62456509f6
00000000-0000-0000-0000-000000000000	2273	ttnb4v52kww5	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-17 02:20:50.545121+00	2026-08-17 03:19:36.483029+00	i6o3oribrjka	7056f734-37d3-4866-8f41-9281a6a65188
00000000-0000-0000-0000-000000000000	2276	ttoe7ylygnol	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-17 03:19:36.485488+00	2026-08-17 03:19:36.485488+00	ttnb4v52kww5	7056f734-37d3-4866-8f41-9281a6a65188
00000000-0000-0000-0000-000000000000	2277	iifwzvqn7lbv	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-17 04:20:14.768732+00	2026-08-17 04:20:14.768732+00	\N	2ce0fbc4-8cdd-4199-ab21-7021d2a5e507
00000000-0000-0000-0000-000000000000	2266	hrvwypfnrxgw	140cd2a9-fd20-492f-8d0e-598929dcf97c	t	2026-08-16 08:56:20.838253+00	2026-08-17 05:46:31.818679+00	cwer6u2oock4	f215be6a-f969-402f-bdb4-8d2cc4dd9038
00000000-0000-0000-0000-000000000000	2278	eazgc76wfwzg	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-17 05:46:31.828049+00	2026-08-17 05:46:31.828049+00	hrvwypfnrxgw	f215be6a-f969-402f-bdb4-8d2cc4dd9038
00000000-0000-0000-0000-000000000000	2279	hxiilxnx2ha6	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-17 05:46:45.826659+00	2026-08-17 05:46:45.826659+00	\N	f2363b1d-2d54-46ec-af7b-8453fa8008e7
00000000-0000-0000-0000-000000000000	2280	qumfa5swott4	140cd2a9-fd20-492f-8d0e-598929dcf97c	f	2026-08-17 05:47:03.377047+00	2026-08-17 05:47:03.377047+00	\N	67a02f68-ce4a-4190-813c-f7ac37d3d853
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
63944591-740d-4bdc-9bba-fc62456509f6	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-16 00:04:28.497069+00	2026-08-17 03:19:32.570065+00	\N	aal1	\N	2026-08-17 03:19:32.569926	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
fa081a34-6358-477e-a04e-1402a3e9b762	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-16 00:51:58.092387+00	2026-08-16 02:50:21.071116+00	\N	aal1	\N	2026-08-16 02:50:21.071006	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
2ce0fbc4-8cdd-4199-ab21-7021d2a5e507	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-17 04:20:14.763407+00	2026-08-17 04:20:14.763407+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
75e35ff1-7c64-4f44-8324-02c4f6d9afe5	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-16 03:03:19.564251+00	2026-08-16 03:03:19.564251+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36	171.254.180.31	\N	\N	\N	\N	\N
f215be6a-f969-402f-bdb4-8d2cc4dd9038	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-16 06:57:53.451354+00	2026-08-17 05:46:31.850541+00	\N	aal1	\N	2026-08-17 05:46:31.850392	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
f2363b1d-2d54-46ec-af7b-8453fa8008e7	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-17 05:46:45.823237+00	2026-08-17 05:46:45.823237+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
764d22b6-f865-46cf-8323-e62599face82	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-15 15:25:22.852296+00	2026-08-15 22:58:43.666942+00	\N	aal1	\N	2026-08-15 22:58:43.666837	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
4b6e12c9-eea0-482d-aa77-8768a71594dc	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-15 23:31:52.281256+00	2026-08-15 23:31:52.281256+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
41f917ce-4140-4432-b86d-2f2177fb0570	d60dd419-93ee-4570-9a5d-87a81f540576	2026-08-15 23:42:01.003073+00	2026-08-15 23:42:01.003073+00	\N	aal1	\N	\N	node	34.34.244.45	\N	\N	\N	\N	\N
21d66a84-79f0-41d6-b20d-a9140f8e6143	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-15 23:43:03.874482+00	2026-08-15 23:43:03.874482+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
48b20247-75a5-4fd6-ad47-964164159995	d60dd419-93ee-4570-9a5d-87a81f540576	2026-08-15 23:43:44.521655+00	2026-08-15 23:43:44.521655+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
c663a01f-cdfe-4892-9dc8-38b74a120c3a	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-15 15:38:39.859858+00	2026-08-16 00:50:31.067176+00	\N	aal1	\N	2026-08-16 00:50:31.067077	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
57552965-dce2-439e-8437-ddc2b155e1fc	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-16 00:50:43.770769+00	2026-08-16 00:50:43.770769+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
67a02f68-ce4a-4190-813c-f7ac37d3d853	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-17 05:47:03.374814+00	2026-08-17 05:47:03.374814+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
fefba1f5-3bae-402d-ad91-1301b97468c1	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-17 00:19:58.490755+00	2026-08-17 00:19:58.490755+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36	171.254.137.227	\N	\N	\N	\N	\N
7056f734-37d3-4866-8f41-9281a6a65188	140cd2a9-fd20-492f-8d0e-598929dcf97c	2026-08-16 23:19:55.092268+00	2026-08-17 03:19:36.493081+00	\N	aal1	\N	2026-08-17 03:19:36.49295	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	6f61a0af-f0c6-4299-a89c-dfbca10e016b	authenticated	authenticated	admin@system.com	$2a$10$jz2k/Rr8A1WVGFaMjMKFWe32YXUXWzfZYyNQSpeqNebs9ZjnVE8PS	2026-08-15 03:15:33.235836+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "Admin", "fullName": "Quản trị viên hệ thống", "username": "Admin"}	f	2026-08-15 03:15:33.235836+00	2026-08-17 05:46:46.313701+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	140cd2a9-fd20-492f-8d0e-598929dcf97c	authenticated	authenticated	admin@htqltd.vn	$2a$10$56.l6RsPQ4mHH1ZvTgXGWOTdURTNDJ.4Y0R3QdHzuzZNpeS5iWCvu	2026-08-15 07:29:29.680357+00	\N		\N		\N			\N	2026-08-17 05:47:03.37472+00	{"provider": "email", "providers": ["email"]}	{"sub": "140cd2a9-fd20-492f-8d0e-598929dcf97c", "email": "admin@htqltd.vn", "email_verified": true, "phone_verified": false}	\N	2026-08-15 07:29:29.663163+00	2026-08-17 05:47:03.378122+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	d60dd419-93ee-4570-9a5d-87a81f540576	authenticated	authenticated	nguoicham12b109l1f7@htqltd.vn	$2a$10$/XnWUV7wH0JvtRbG/MsHOu5f9vymapah.dv9AOCK1JCw96I3pz/Ni	2026-08-15 23:42:00.995363+00	\N		\N		\N			\N	2026-08-15 23:43:44.519095+00	{"provider": "email", "providers": ["email"]}	{"sub": "d60dd419-93ee-4570-9a5d-87a81f540576", "email": "nguoicham12b109l1f7@htqltd.vn", "email_verified": true, "phone_verified": false}	\N	2026-08-15 23:42:00.968721+00	2026-08-15 23:43:44.530499+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5d05d505-b42c-4251-99aa-da542602fc1d	authenticated	authenticated	hht1@system.com	$2a$10$T90piqNzGx6gvBCxMQur5uoYiSDwN2wnvMqrSbEvc28JT/UDXagki	2026-08-15 03:40:56.898706+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "Admin", "fullName": "hht1", "username": "hht1"}	f	2026-08-15 03:40:56.898706+00	2026-08-15 03:59:09.535851+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	38cb2cd3-d5ed-498f-bd50-f6555145324d	authenticated	authenticated	nguyenphamduonganhbv3oo@system.com	$2a$10$luc0z2odMtc8INKm8U8hDOk0XtU9xRhRe6kqfAdeZqqEWTsYaI.Ri	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Phạm Dương Anh", "username": "nguyenphamduonganhbv3oo"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a1dafda8-6e37-4f5b-88fa-1441fe2b043f	authenticated	authenticated	nguyenphamvanbey4tve@system.com	$2a$10$jAYwH7Rpui.J3R1s/f/o7eIyCE6xKYGtPLsWolgwcRhIJzpxSwVkq	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Phạm Văn Bé", "username": "nguyenphamvanbey4tve"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	bb69e6a4-076e-4073-96e2-27797725ad2e	authenticated	authenticated	nguyenluongthanhbinh2zap4@system.com	$2a$10$LTO2x4ho.3tBJj.nm/l3puA6CUcDTqTqJi54v8Hv3ZeDPsH..NL4i	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Lương Thanh Bình", "username": "nguyenluongthanhbinh2zap4"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	24d4f4e4-d10d-49b7-ad7f-62cb0ac8cc03	authenticated	authenticated	nguyentrankhanhha4a4d2@system.com	$2a$10$x9J1j4RDSbZPkRUAd1ZWTuIxK.PdLXvh80r18OE1G4nA1jsE87DQ.	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn TRẦN KHÁNH HÀ", "username": "nguyentrankhanhha4a4d2"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	cf9e678b-ad8b-4f82-a8d9-707594e081e8	authenticated	authenticated	nguyennguyenconghaumz2ct@system.com	$2a$10$8y2c.ocAYDoGBu9kLot0e.7fkVRa4US2A1sv50WujmXFlU74M8KUy	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Công Hậu", "username": "nguyennguyenconghaumz2ct"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	96ddd380-02f5-4d17-ac01-d3eceeadbeff	authenticated	authenticated	nguyennguyenduchieuvx2wy@system.com	$2a$10$OJX87WMB5tqH702Xqo.rC.71FPtP2DWNW2qh4TERZPYe5PXrJNaVO	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Đức Hiếu", "username": "nguyennguyenduchieuvx2wy"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	bd2e86c3-0b30-4cb5-a77d-fbcec0af847b	authenticated	authenticated	nguyennguyenvanhieuwgnc2@system.com	$2a$10$QGYL.PTQCJdWoqJ/BA8LrujPo3DER0gSMZ9ID1H/ghe1PG0/Lkc9y	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Văn Hiếu", "username": "nguyennguyenvanhieuwgnc2"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	37139cab-63ae-4973-ab82-b9dbf30765bc	authenticated	authenticated	nguyenlethithuyhoairu60z@system.com	$2a$10$IlL3kBw0rtcMopfETiW0AOhWWDsuIGiQSQZAEyfCEAkE0tcTwAmyS	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Lê Thị Thúy Hoài", "username": "nguyenlethithuyhoairu60z"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c1d64ced-3d55-4d62-bd30-967be8dddb33	authenticated	authenticated	nguyendinhngockhanhhuyeneumhw@system.com	$2a$10$7/qmPxNodxh80uXuYo3puuqhulZNILVUiUmF9jhesfLqQq.aCXEB2	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Đinh Ngọc Khánh Huyền", "username": "nguyendinhngockhanhhuyeneumhw"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	07a4ede9-0b6e-4171-8865-45a2da4ffcea	authenticated	authenticated	nguyenphamquochungbamkv@system.com	$2a$10$379NqnICj7L8VAbKA9cmd.DcyydA3aAiQyVmNgMsYyvv7uG7vyoQS	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Phạm Quốc Hưng", "username": "nguyenphamquochungbamkv"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	456c5a51-7c3d-4ca1-9c6c-9f019a0ffd52	authenticated	authenticated	nguyendaovietkhanhol3wo@system.com	$2a$10$OPxDlRWEHypJeCn4RrH7muYzm9tQVBpB9DgCfYWJ0EVBwMjFgg7mu	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Đào Viết Khánh", "username": "nguyendaovietkhanhol3wo"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	673411e6-b468-41dd-aae5-a2c1e51bfd1e	authenticated	authenticated	nguyennguyenquangkiensh68o@system.com	$2a$10$L9KlCEXQuMqcZpeKxNbEqOMN3eQXGUzfyhjgoTpWb9sKBQNvhgGui	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Quang Kiên", "username": "nguyennguyenquangkiensh68o"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4b6baf68-a7d8-447e-b44e-56f9f3038f53	authenticated	authenticated	nguyennguyenkhanhlinh91v1i@system.com	$2a$10$7/0r05j3i2EtA5swR2k0zO3EyPrDg91P.dRhDrmzEaI.FCdx4zFsy	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Khánh Linh", "username": "nguyennguyenkhanhlinh91v1i"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c16704e7-05ee-4447-abc5-15d172eeb1ea	authenticated	authenticated	nguyennguyenphilong36w60@system.com	$2a$10$M6bl.4I4ptMG04N8m6kJhufjBCvSuYKIk5Q96UPF.sl6XH46hnFNa	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Phi Long", "username": "nguyennguyenphilong36w60"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c464267d-889c-4187-8575-fcff914eb4a4	authenticated	authenticated	nguyentranducluongzaai8@system.com	$2a$10$XTbX8qqkEniQzi9tt7yIL.CogTzuBiYZhrwH1i8boIJq6BAo/bgzu	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Trần Đức Lương", "username": "nguyentranducluongzaai8"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	688c33dd-72d7-41f2-9c26-acba9bb378c3	authenticated	authenticated	nguyenhothikhanhlyx92w0@system.com	$2a$10$ocNIvjjNztsCermNHviHYORMuri0bf7QU0AjD9r6nG2ihoHJnh4Jm	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Hồ Thị Khánh Ly", "username": "nguyenhothikhanhlyx92w0"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	857e94ef-38dd-4d8c-84c0-7a5ea94587df	authenticated	authenticated	nguyennguyenhoangbaominhkmh5y@system.com	$2a$10$oFKQ./apTqHvvBz5D.K6E.cW76sal0IbpqzrReY3AUFOwH3wKOzpq	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Hoàng Bảo Minh", "username": "nguyennguyenhoangbaominhkmh5y"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a3d8ebe4-a181-416a-8a33-e824fbd23f0d	authenticated	authenticated	nguyenhothunga8kgqc@system.com	$2a$10$PNhx3Rohy28di0.ygRvZweberxOzwVqQi6caCpFc5uRfZ82rIXUOO	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Hồ Thu Nga", "username": "nguyenhothunga8kgqc"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	14a4ef5f-f86a-45b3-8ca6-b5edea4be73b	authenticated	authenticated	nguyentrinhthihangngab43ll@system.com	$2a$10$mwc5630WgTN/vJ8HEAgnZe/mzpF9cgyVgf3W9PP3Ry1K00WLxLrsm	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Trịnh Thị Hằng Nga", "username": "nguyentrinhthihangngab43ll"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:56:48.509717+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	62e2ac5b-f50e-474a-b6d5-534b90bd9945	authenticated	authenticated	nguyennguyenthihuyentrang17089@system.com	$2a$10$GXqrKL66gBkpuhS4ethksuujrbdtJJhnQxdgNz9eujm7pDOGIXVwi	2026-08-15 03:56:51.902784+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Thị Huyền Trang", "username": "nguyennguyenthihuyentrang17089"}	f	2026-08-15 03:56:51.902784+00	2026-08-15 03:56:51.902784+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	bcd7863c-4fd8-48ec-bf7a-3a1241b5cf54	authenticated	authenticated	nguyennguyentranhuyentrang5w0v3@system.com	$2a$10$YtpGIYOdNoax78Z/B99UNeUEGQbvJ8Dt7iRd9gpycQwmkM.ZcLVY2	2026-08-15 03:56:51.902784+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Trần Huyền Trang", "username": "nguyennguyentranhuyentrang5w0v3"}	f	2026-08-15 03:56:51.902784+00	2026-08-15 03:56:51.902784+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4a3ec3b7-e4b7-4e77-85bc-84b54ead11c7	authenticated	authenticated	nguyennguyenquoctrongidauv@system.com	$2a$10$42XPG/AXjB0y6oFOrIB2s.RwegHwWXraN6pCueCjqi2Rj.JKjWosO	2026-08-15 03:56:51.902784+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Quốc Trọng", "username": "nguyennguyenquoctrongidauv"}	f	2026-08-15 03:56:51.902784+00	2026-08-15 03:56:51.902784+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	bdbd1e10-9aad-473d-9b0d-883523436796	authenticated	authenticated	nguyendoantuongvyvyo04@system.com	$2a$10$Ci/rD27bQq0sSDMT.zDx3eUHSYbJevMXJWJGIBqb86vxVWla/qNBy	2026-08-15 03:56:51.902784+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Đoàn Tường Vy", "username": "nguyendoantuongvyvyo04"}	f	2026-08-15 03:56:51.902784+00	2026-08-15 03:56:51.902784+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f1e3fe92-23a4-4861-9dd8-366fe5c6e9b5	authenticated	authenticated	nguoicham10a1zzzmd@system.com	$2a$10$XYmHDXAWIKLs8EGiz5iLiuh6mfkk7VznF4q6gA2PDuSwkkMS9JTBi	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A1", "username": "Nguoicham10a1zzzmd"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2abfd50f-1991-4218-a512-e04ea3708105	authenticated	authenticated	nguoicham10a2s4dqd@system.com	$2a$10$.1OplCwtFMOSjDzMVo1cBuSWfiWySDPl4q3UHV0/hEFeGxPovZK8G	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A2", "username": "Nguoicham10a2s4dqd"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	13ad8a84-912e-47ee-aa9f-bedaf61bb688	authenticated	authenticated	nguoicham10a3mwxmn@system.com	$2a$10$nZTWhHeS9bDevnE2u4OoFeSeDYXMHNp9m4Zh9xpTqA4JuPLSlhYku	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A3", "username": "Nguoicham10a3mwxmn"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	80f1d7ac-ceb3-4561-92c8-917d0a6b33f4	authenticated	authenticated	nguoicham10a5annhq@system.com	$2a$10$C8kdfG2KqZru83NGVj8HA.A5PjoZi.3extoAfH82wY0CRcG.RdkgC	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A5", "username": "Nguoicham10a5annhq"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	31fcc99a-701a-48f2-ae06-85c4b2ff2d4d	authenticated	authenticated	nguoicham10a634zib@system.com	$2a$10$BS2/k0f5F6oYhhAeRfJcmO3KIipPrgLTX5mrKZhnVgdJUInmZzyJ2	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A6", "username": "Nguoicham10a634zib"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ce9afc61-47bb-48a3-a69f-4f2d3dd37b93	authenticated	authenticated	nguoicham10a7gry8l@system.com	$2a$10$3No74953pdz9eDYaCfMAbefkewlFKS8ATmR8xWIh82JUBlKX7EMEy	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A7", "username": "Nguoicham10a7gry8l"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	d14159ea-5683-4c98-9b39-2afe849d7301	authenticated	authenticated	nguoicham10a8u3jpb@system.com	$2a$10$9eifnJDLwOxN6uQ87t.88euskM1tnuxtXAFAwIlNqHy9YcGWB16Sy	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A8", "username": "Nguoicham10a8u3jpb"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5de7c0d7-a00b-4ab3-b13b-ff7ca1b6d41d	authenticated	authenticated	nguoicham10a9gzalm@system.com	$2a$10$4HsV0gzQopU/6eXLIbVpzOLGd9imSYGYvnhdxmspVK1fcJ.dPCmwK	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A9", "username": "Nguoicham10a9gzalm"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ac03ad6e-4b5f-4c2b-a7b4-1c004f3f3553	authenticated	authenticated	nguoicham10a10tkzqk@system.com	$2a$10$IAeFz5i9et00mnIzzhZSpupSEN9BxsOS01TtKgd8deEZ89030RvL6	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A10", "username": "Nguoicham10a10tkzqk"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a41c7171-b4ea-46ca-bdf5-db82c83fd928	authenticated	authenticated	nguoicham10a11nvsae@system.com	$2a$10$rY4wMkEkGq8PCGQZz9a7tO4n/FeNGPM/QEr4qBeIEEMIkf0NhgK6C	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A11", "username": "Nguoicham10a11nvsae"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	de774bcb-de5a-4770-97a8-33cd4a660fc5	authenticated	authenticated	nguoicham11c13gpvo@system.com	$2a$10$NSedyBQIQTId8a6aONFaHeeKNFq7aBqTvHvIaGMXyeRjDYTrq/sMu	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C1", "username": "Nguoicham11c13gpvo"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b0ab3854-db9e-46cd-b367-184a62f872a6	authenticated	authenticated	nguoicham11c26e7qv@system.com	$2a$10$z5uUWMJbLGDp6kBztYbG2ONYQmerJTtLkjVDqRC.Zjcrv./qIaVRe	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C2", "username": "Nguoicham11c26e7qv"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	cff04e41-2eac-4c2e-943b-d2a8181f25da	authenticated	authenticated	nguoicham11c3z7l8m@system.com	$2a$10$qz9ejO0DuoibxZoks2MbbeKpbJLafSHJNzMB3wx4Xw2pBvLbm75Ke	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C3", "username": "Nguoicham11c3z7l8m"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c3a4207b-fad7-4d72-ab9f-917fa19c8639	authenticated	authenticated	nguoicham11c4gaf8m@system.com	$2a$10$xn3OtByW9B5SNQSxYimWFuNdeH9UCVeOQEWrBXgcigjUWvfy5Oh6y	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C4", "username": "Nguoicham11c4gaf8m"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	18ef2f51-6b37-4524-af19-9e6e529aad63	authenticated	authenticated	nguyennguyenlucngan5szu2@system.com	$2a$10$xYy4NiusG2M0dv5dBToX6erSwBDOe4/vNOCp1u7wYm115/k74ykwG	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Lục Ngạn", "username": "nguyennguyenlucngan5szu2"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	efad92ab-e375-4fe0-ab14-0c0be155d41b	authenticated	authenticated	nguyenlehoangmyngocwjdh9@system.com	$2a$10$zNQ2SZEeeDZY7zbJGxlEwuVEhqoJWanIBmkClfH8xcOaCZmOGMvbe	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Lê Hoàng Mỹ Ngọc", "username": "nguyenlehoangmyngocwjdh9"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b5561643-81b4-4f72-b6cf-26c5f7be0376	authenticated	authenticated	nguyenlethibaongoc1cfpy@system.com	$2a$10$H7gSO0Tg1mCpQDBMKh5IOeYScfX.SxThCevkyFQcljNji2L2B6/hi	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Lê Thị Bảo Ngọc", "username": "nguyenlethibaongoc1cfpy"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	cf3a2afa-3f86-432a-9641-32971b2329f2	authenticated	authenticated	nguyencaoanhnhanu211u@system.com	$2a$10$EQY5Nu5szEfUeXAHIrHS.OoMYPZYn.ID5osu3J7vKPH9Kp6l94d.S	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Cao Anh Nhân", "username": "nguyencaoanhnhanu211u"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ccb1f782-8a4f-428b-96eb-55c5ff823db4	authenticated	authenticated	nguyenlevothanhnhat4snme@system.com	$2a$10$yxBksMxNQqjmru6MKX18C.FiWEi2lWbLmn8EBXM6OyLZFC.QynHg6	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Lê Võ Thanh Nhật", "username": "nguyenlevothanhnhat4snme"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	30a3672f-c1c3-43f7-9850-84918a85261b	authenticated	authenticated	nguyendangthithuphuongychdb@system.com	$2a$10$ltAZRINJxvXkELIJYpJ1X.2PUy0/wqDlmZ4QChNT.ZRF/HFQcW7H2	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Đặng Thị Thu Phương", "username": "nguyendangthithuphuongychdb"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b21e4eec-3524-4199-a67a-1efb9620494f	authenticated	authenticated	nguyendobaoquango3exb@system.com	$2a$10$lbGT0ottPamM9fbHCNkC/u7JKQ259RSQzd9ihJWMXQCbPs4.gJBNK	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Đỗ Bảo Quang", "username": "nguyendobaoquango3exb"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c1449a84-5470-45d7-9134-dda9bf515527	authenticated	authenticated	nguyenhohuuquang3arre@system.com	$2a$10$.CwsZykg8RIo8W.xZK/hd.O63hMygukHuhwQubFifXMTh5UByIY5m	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Hồ Hữu Quang", "username": "nguyenhohuuquang3arre"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	983323f6-0d94-493e-ad44-7630b36f496b	authenticated	authenticated	nguyenhokhacanhquane9vc6@system.com	$2a$10$WwCTxyba4hdYCyPUIM4GROIsQptRnJUTCME7qR/lZI.lI/6w98Scu	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Hô Khắc Anh Quân", "username": "nguyenhokhacanhquane9vc6"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	96f7386c-0bbb-4f74-ab73-6ced5607a1e3	authenticated	authenticated	nguyenhosyquanqgfzf@system.com	$2a$10$G2IorGOa21nplcRzn02dG.cPPt2OvvCzLOMsOAJUyO0APlf81WWS6	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Hồ Sỹ Quân", "username": "nguyenhosyquanqgfzf"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7165ac01-016b-49db-beae-017e880982c0	authenticated	authenticated	nguyenphamvunhuquynhf8onh@system.com	$2a$10$.B/tn3wbYm4PnP3tx1Dz3eeU8p2DDdbbwD9oQyJAgznbQ2aW1/MZy	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Phạm Vũ Như Quỳnh", "username": "nguyenphamvunhuquynhf8onh"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	49f2eab4-688f-4be8-ae5f-c951bbfbc43c	authenticated	authenticated	nguyennguyenngoclanthanhxg1bg@system.com	$2a$10$etOhrNlvIya.GPRThT.64urKiIdL4fONfWy7ZNitgyK9B4V6ApIe.	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Nguyễn Ngọc Lan Thanh", "username": "nguyennguyenngoclanthanhxg1bg"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	29b3d0e6-0da6-4cc0-9ccf-891c9c01aa70	authenticated	authenticated	nguyenvohanhthaoec5ss@system.com	$2a$10$6l97IG7WBT0vLuuawMYtWepnRrjNT4LpDbBSn9i4S8g1tfticLmUK	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Võ Hạnh Thảo", "username": "nguyenvohanhthaoec5ss"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e749dc25-0d65-47bd-8a4d-831652d0857f	authenticated	authenticated	nguyentranhongthe1dhkb@system.com	$2a$10$Usfr6Gc1blpg0qNq.dqaX.O8gKlNZ6N55q0pPdSr67ShoS82fJ3Me	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Trần Hồng Thế", "username": "nguyentranhongthe1dhkb"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4b858668-9582-47da-ac95-a920aed6cc02	authenticated	authenticated	nguyenduongducthinhgi94v@system.com	$2a$10$rqvg3PPeQ85Q99esKmJRW.a/29mijmfeKk//iyS3R7IO3522i2p8G	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Dương Đức Thịnh", "username": "nguyenduongducthinhgi94v"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	227dd64d-32df-4a2c-a6a8-3330ba4b9802	authenticated	authenticated	nguyenphanngocthinhmaouh@system.com	$2a$10$0S6SVSVPTPuByVEETmya6OQoJX2YdSGQk8FMNiZeK70quf2dG/aG.	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Phan Ngọc Thịnh", "username": "nguyenphanngocthinhmaouh"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e315af28-d9e7-4a0b-861a-ee5709d754e3	authenticated	authenticated	nguyenbuithilythuc7pjb@system.com	$2a$10$LouevZHEfGdgkcgddJvuhe5YxruVJxZVBB8LctPxsosyFxnThZjA.	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Bùi Thị Lý Thu", "username": "nguyenbuithilythuc7pjb"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6f7a1629-78d9-4381-bd19-1a8f4c9d6574	authenticated	authenticated	nguyenhonguyenkhanhtrangaj796@system.com	$2a$10$CF5zRf4ZiouMqeU5Nt8JhOjETlCWDCM1dF2aF77S8p.R6Y4MHZcHK	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Hồ Nguyễn Khánh Trang", "username": "nguyenhonguyenkhanhtrangaj796"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	20f45931-9621-4e44-a63c-eed032e52185	authenticated	authenticated	nguyenhothithuytrang7zz8y@system.com	$2a$10$zdYlDdLx1dCxUw/xMKY3WOku0F/.ocsT50z1pRt4Z99PvDLXqk1Om	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Hồ Thị Thùy Trang", "username": "nguyenhothithuytrang7zz8y"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2a819d42-ade1-456c-85fe-7133a9365b22	authenticated	authenticated	nguoicham12b2q00du@system.com	$2a$10$Uim/MJPBGD/QLvmjnKIIxOMaDIggPFjL4X6UI0wd286NmjNOBXp22	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B2", "username": "Nguoicham12b2q00du"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	40840543-d1e0-4333-9c72-7afb7c3b4363	authenticated	authenticated	nguoicham12b3mdjd0@system.com	$2a$10$mdL5tH05zszoH5HAW/ceEuxJ0eRLkC8lWsCMn1yvnHA/c8A0zD.N.	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B3", "username": "Nguoicham12b3mdjd0"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1f902a36-eecb-484a-b87e-05ce05bc2fed	authenticated	authenticated	nguoicham12b4fa7hg@system.com	$2a$10$z2JpHKKe0RB53KrJ5qmnMeKAL/houmD/embsr2Dv1XCqVvTUuwXF2	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B4", "username": "Nguoicham12b4fa7hg"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5122a3de-2fbe-4fbd-aff5-39405ea7179c	authenticated	authenticated	nguoicham12b5qgkg0@system.com	$2a$10$M.bUsrilSMZ34ZQ8EH36MOmbbXAT9Zb.5KhtCcjJ55iC3zOtduJT2	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B5", "username": "Nguoicham12b5qgkg0"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5813e30c-046f-4560-ad1c-853f9b7b4be7	authenticated	authenticated	hht@system.com	$2a$10$ve/2g5K/ImaPMiKYU0WyzubCakpkc08MYaLCRLNLjsIWpx7VVQA4y	2026-08-15 03:35:44.363288+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "Admin", "fullName": "hht", "username": "hht"}	f	2026-08-15 03:35:44.363288+00	2026-08-15 03:35:58.84861+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2650291f-4c32-41c9-a53e-388609e9a370	authenticated	authenticated	nguyenlethithuytrang1kbeh@system.com	$2a$10$vEOHiW.UIzxbDGyU8I0f6eb.kU36aA/j0yJsX6Rv7JAvRQhd.nKOO	2026-08-15 03:56:50.238029+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Lê Thị Thùy Trang", "username": "nguyenlethithuytrang1kbeh"}	f	2026-08-15 03:56:50.238029+00	2026-08-15 03:56:50.238029+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	841f3a65-2f6c-43a5-85c4-18d6b20c8d8b	authenticated	authenticated	nguoicham12b6ancjl@system.com	$2a$10$wvFpARx03DacXUayUfT54uAThQkQnzsUNBWUAY2ytsvT1KTscRhym	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B6", "username": "Nguoicham12b6ancjl"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f387d27c-0cf4-4935-a3c0-eb03329d409a	authenticated	authenticated	nguyenbuingocdatmcanq@system.com	$2a$10$hSbvtbSQvRBArr3cvu/wleXS.W5bwGcj.Je0Wfn6LhOenHNHJ0rBC	2026-08-15 03:56:48.509717+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullName": "Nguyễn Bùi Ngọc Đạt", "username": "nguyenbuingocdatmcanq"}	f	2026-08-15 03:56:48.509717+00	2026-08-15 03:58:41.31176+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e90ac88d-2afd-4362-b697-8c9a90b6ef33	authenticated	authenticated	nguoicham11c5oina8@system.com	$2a$10$H4ew9P8hp.WkfbEKEWP/FurRt8HBVo4wUrL7RoGiCVdzUfCwfpwpK	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C5", "username": "Nguoicham11c5oina8"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4390d7e9-4456-428f-b595-a61403943683	authenticated	authenticated	nguoicham11c6dt0a8@system.com	$2a$10$jXhKXcd7A9VeXVRfNdoOI.Psj4PfGZLoQunW70JcebJjf2FX6mUSC	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C6", "username": "Nguoicham11c6dt0a8"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	60fdd515-f80d-4b9a-a0b3-cc9429639239	authenticated	authenticated	nguoicham11c7nsrz2@system.com	$2a$10$Ihd1Jewl7AfDwfEIMvVgTemT7s1wFlgtNw/pYWe.OzAYAc5aUdYPi	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C7", "username": "Nguoicham11c7nsrz2"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a626443a-f65f-4e5d-9710-e3283a628a64	authenticated	authenticated	nguoicham11c8h0zxt@system.com	$2a$10$tpghZdLJwayAWOh/xb38c.t5CZCfaKqQxu9SVjB4NfhjtdMUMCdpS	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C8", "username": "Nguoicham11c8h0zxt"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	01796988-91bb-46da-b5ba-3cf1084e2391	authenticated	authenticated	nguoicham11c905pk2@system.com	$2a$10$BjcP.Ixz0a2w8fCIfYwt5OMMoysMrplA/VQ2yj2HUiPOdW1VQmoWe	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C9", "username": "Nguoicham11c905pk2"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 03:59:26.63405+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	dbd574ca-738c-40e6-b5f9-2ce01f647957	authenticated	authenticated	nguoicham11c10s38bz@system.com	$2a$10$tx1XI0MVKJCwfRKgmMLYge9lTrRSWA.x11PDqTwGLD.JOwDLuWpG.	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C10", "username": "Nguoicham11c10s38bz"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b692b7fc-2e2f-4abc-b8e6-31359f148502	authenticated	authenticated	nguoicham11c11c22c8@system.com	$2a$10$qMU0am6XK55JJmaArjQlF.Av5iP8DUPtGqJ3F1YeMlqhLFblQv/DW	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C11", "username": "Nguoicham11c11c22c8"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	cab41401-e1b2-4c30-9a9b-c2aba0377f85	authenticated	authenticated	nguoicham11c12qasiy@system.com	$2a$10$CHcglULFvtEfApH61IKunuwcmZ1xSAAFIRePR/dOgVZurVSeVklei	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 11C12", "username": "Nguoicham11c12qasiy"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	fb067e46-c98d-4867-a20a-64cdd42100e2	authenticated	authenticated	nguoicham12b1soros@system.com	$2a$10$ZNw/.xnAcm5lH745ht7Ja.oaWViB4.KGmYpL5MPtSLBbVepRoyoZe	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B1", "username": "Nguoicham12b1soros"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3f4a4432-bb60-4f31-a58a-e1b40066977f	authenticated	authenticated	nguoicham12b7e9fkj@system.com	$2a$10$vSxtzOFLeN0pRDEjC3DV6.4olmMXb2sLtf3FstwD4xDqvkPyfXGXC	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B7", "username": "Nguoicham12b7e9fkj"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7dd7904d-cbe5-41e0-822e-2fbd58c92198	authenticated	authenticated	nguoicham12b88ynlk@system.com	$2a$10$rMv3JZcC87pQuuZlP9GfO.evWueKsvAYNm.2WTLDiUSoKlo8pEx8i	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B8", "username": "Nguoicham12b88ynlk"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	587fbc12-a441-4b35-979e-e97c397a8578	authenticated	authenticated	nguoicham12b9f0gtq@system.com	$2a$10$kODgV6fdG2RNxTSl8/CejO//8xe8jXDym3Xw4rImE9iiT584ZkjGC	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B9", "username": "Nguoicham12b9f0gtq"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	596cc5cb-7903-4956-8ed3-726ca5e50313	authenticated	authenticated	nguoicham12b100ergv@system.com	$2a$10$2xqYzCdzvhX8T1VpyFG.SOyRY2EMcKgNnYiCAGcwFZcrbbLSNP8V2	2026-08-15 03:59:28.337276+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 12B10", "username": "Nguoicham12b100ergv"}	f	2026-08-15 03:59:28.337276+00	2026-08-15 03:59:28.337276+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	04634be0-2deb-4841-815d-ad344631e26b	authenticated	authenticated	nguoicham10a44i7wb@system.com	$2a$10$jKWjUXiRHUy1YAjHoH.a9.p9jzQxlU9EEllFIkWhztN6NRXQMRXaq	2026-08-15 03:59:26.63405+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "NC", "fullName": "Người chấm 10A4", "username": "Nguoicham10a44i7wb"}	f	2026-08-15 03:59:26.63405+00	2026-08-15 04:01:57.566901+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."activity_logs" ("id", "user_id", "username", "full_name", "tab_name", "table_name", "action_type", "description", "old_data", "new_data", "created_at", "namhoc") FROM stdin;
\.


--
-- Data for Name: cauhinh_tieuchi_xet_thidua; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cauhinh_tieuchi_xet_thidua" ("id", "namhoc_id", "hoc_ky", "ten_tieuchi_1", "sudung_1", "kieudulieu_1", "ten_tieuchi_2", "sudung_2", "kieudulieu_2", "ten_tieuchi_3", "sudung_3", "kieudulieu_3", "ten_tieuchi_4", "sudung_4", "kieudulieu_4", "ten_tieuchi_5", "sudung_5", "kieudulieu_5", "ten_tieuchi_6", "sudung_6", "kieudulieu_6", "ten_tieuchi_7", "sudung_7", "kieudulieu_7", "ten_tieuchi_8", "sudung_8", "kieudulieu_8", "ten_tieuchi_9", "sudung_9", "kieudulieu_9", "ten_tieuchi_10", "sudung_10", "kieudulieu_10", "created_at", "updated_at", "ghi_chu", "giai_thich", "trang_thai") FROM stdin;
\.


--
-- Data for Name: chamdiem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."chamdiem" ("id", "namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "hotendoanvien", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "ghichu", "nguoicham", "updatedat", "chidoan_id", "createdat") FROM stdin;
\.


--
-- Data for Name: doanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."doanvien" ("id", "hoten", "ngaysinh", "gioitinh", "dantoc", "doituong", "doanvien", "chidoan", "ngayvaodoan", "sdt", "thongtinthem", "updatedat", "namhoc", "diachi", "chidoan_id", "createdat") FROM stdin;
\.


--
-- Data for Name: dotptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."dotptdoanvien" ("id", "namhoc", "hocky", "tendot", "tungay", "denngay", "isdefault", "islocked", "ghichu", "updatedat", "createdat") FROM stdin;
\.


--
-- Data for Name: duytricsdl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."duytricsdl" ("id", "so", "thoigian", "createdat", "updatedat") FROM stdin;
1b671eeb-04c9-417a-8bd7-b1aba8f07518	20	2026-04-29 13:45:42.476892+00	2026-05-10 03:15:08.557405+00	2026-08-17 05:54:16.943983+00
\.


--
-- Data for Name: gio_hoc_tap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."gio_hoc_tap" ("id", "namhoc_id", "chidoan_id", "tuan_id", "so_tot", "so_kha", "so_tb", "so_yeu", "diem_tot_cauhinh", "diem_kha_cauhinh", "diem_tb_cauhinh", "diem_yeu_cauhinh", "diem_tb_hoc_tap", "updated_at", "hocky") FROM stdin;
\.


--
-- Data for Name: github_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."github_settings" ("id", "github_repo_path", "github_branch", "github_workflow_file", "github_restore_workflow_file", "github_token", "updated_at", "updated_by", "createdat", "updatedat") FROM stdin;
default	hohuuthe/hethongquanlythidua.id.vn	main	supabase-backup.yml	supabase-restore.yml	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	2026-08-14 14:37:02.524+00	Admin	2026-05-10 03:14:45.814898+00	2026-08-14 14:37:01.687336+00
\.


--
-- Data for Name: namhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."namhoc" ("id", "tennamhoc", "islocked", "updatedat", "createdat", "isdefault") FROM stdin;
7bf537ba-8581-49ec-8bd1-7922b3a6e5db	2026-2027	f	2026-08-07 09:26:31.364232+00	2026-07-11 08:26:23.11618+00	f
1f34a7f5-a416-405f-b15d-921bffa677d5	2027-2028	f	2026-08-07 09:26:31.364232+00	2026-08-06 21:50:10.069014+00	f
9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2025-2026	f	2026-08-07 09:26:32.297859+00	2026-05-12 09:15:01.271856+00	t
\.


--
-- Data for Name: phancong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phancong" ("id", "hocky", "tuan", "lopcham", "chamlop", "updatedat", "namhoc", "createdat") FROM stdin;
\.


--
-- Data for Name: phanquyen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phanquyen" ("id", "doi_tuong", "tab_chuc_nang", "ngay_cap_nhat", "nam_hoc", "createdat", "updatedat", "quyen_xem", "quyen_them", "quyen_sua", "quyen_xoa", "giai_thich") FROM stdin;
9248	BCH	chamdiem	2026-08-14 18:31:07.339063+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-08-14 18:31:07.339063+00	t	f	f	f	
9258	GVCN	doanvien	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-08-14 15:02:36.65319+00	t	f	f	f	
9282	DV	doanvien	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-08-14 15:02:36.65319+00	t	f	f	f	
9216	BGH	phancong	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9217	BGH	chamdiem	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9218	BGH	namtuan	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9219	BGH	baocao	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9220	BGH	tonghopbc	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9221	BGH	qlbaocao	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9222	BGH	qlnopbc	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9223	BGH	theodoi360	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9224	BTV	tongquan	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9225	BTV	qlchidoan	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	f	
9227	BTV	doanvien	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	f	
9228	BTV	ptdoanvien	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	f	
9229	BTV	tieuchitd	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	f	
9230	BTV	phancong	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	f	
9231	BTV	chamdiem	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	f	
9232	BTV	namtuan	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9233	BTV	baocao	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9234	BTV	tonghopbc	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9235	BTV	qlbaocao	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	f	
9236	BTV	qlnopbc	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	f	
9237	BTV	theodoi360	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	t	f	
9239	BTV	phanquyen	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9240	BTV	saoluu	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9241	BCH	tongquan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9242	BCH	qlchidoan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	t	f	
9244	BCH	doanvien	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	t	f	
9245	BCH	ptdoanvien	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	t	
9246	BCH	tieuchitd	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9247	BCH	phancong	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9249	BCH	namtuan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9250	BCH	baocao	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9251	BCH	tonghopbc	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9252	BCH	qlbaocao	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9253	BCH	qlnopbc	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	t	
9254	BCH	theodoi360	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	t	f	
9255	GVCN	tongquan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9256	GVCN	qlchidoan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9259	GVCN	ptdoanvien	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9260	GVCN	tieuchitd	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9261	GVCN	phancong	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9262	GVCN	chamdiem	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9263	GVCN	namtuan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9264	GVCN	baocao	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9265	GVCN	tonghopbc	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9266	GVCN	qlbaocao	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9267	GVCN	qlnopbc	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	t	
9268	GVCN	theodoi360	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9269	NC	tongquan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9270	NC	qlchidoan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9271	NC	doanvien	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9272	NC	tieuchitd	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9273	NC	phancong	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9274	NC	chamdiem	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	t	
9275	NC	namtuan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9276	NC	baocao	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9277	NC	tonghopbc	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9278	NC	qlbaocao	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9279	NC	qlnopbc	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	t	
9280	NC	theodoi360	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	t	f	
9281	DV	tongquan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9283	DV	ptdoanvien	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9284	DV	tieuchitd	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9285	DV	phancong	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9286	DV	chamdiem	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9287	BGH	tongquan	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9288	BGH	qlchidoan	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9289	BGH	doanvien	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9290	BGH	ptdoanvien	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9291	BGH	tieuchitd	2026-07-28 13:28:29.24+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9292	DV	namtuan	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9293	DV	qlbaocao	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9294	DV	qlnopbc	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	t	
9295	DV	theodoi360	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	t	t	t	
9296	PH	tieuchitd	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9297	PH	chamdiem	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9298	PH	qlbaocao	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
9299	PH	qlnopbc	2026-07-28 13:28:29.241+00	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-07-02 03:15:48.133813+00	2026-07-28 13:28:28.619059+00	t	f	f	f	
\.


--
-- Data for Name: ptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ptdoanvien" ("id", "doanvien_id", "dotdangki", "thongkerenluyen", "diemrenluyen", "pheduyet", "createdat", "updatedat", "namhoc", "soquyetdinh", "ngayquyetdinh") FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."push_subscriptions" ("id", "user_id", "role", "chidoan_id", "subscription", "endpoint", "created_at") FROM stdin;
\.


--
-- Data for Name: ql_baocao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_baocao" ("id", "chu_de", "chu_de_phu", "tu_ngay", "den_ngay", "cho_phep_minh_chung", "doi_tuong_nop", "huong_dan", "ngay_tao", "nam_hoc_id", "hoc_ky", "config_noi_dung1", "config_noi_dung2", "config_noi_dung3", "config_noi_dung4", "config_noi_dung5", "config_noi_dung6", "config_noi_dung7", "config_noi_dung8", "config_noi_dung9", "config_noi_dung10", "allowed_file_types", "max_file_size") FROM stdin;
\.


--
-- Data for Name: ql_nop_bc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_nop_bc" ("id", "ql_bao_cao_id", "doanvien_id", "noi_dung1", "noi_dung2", "noi_dung3", "noi_dung4", "noi_dung5", "noi_dung6", "noi_dung7", "noi_dung8", "noi_dung9", "noi_dung10", "duong_dan_minh_chung", "ghi_chu", "trang_thai", "ngay_capnhat", "chi_doan_id", "danh_sach_anh", "vaitro_nop", "doituong_nop", "nguoi_tao_id") FROM stdin;
\.


--
-- Data for Name: qlchidoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."qlchidoan" ("id", "tenchidoan", "buoihoc", "ban", "phonghoc", "bithu", "gvcn", "namhoc", "updatedat", "createdat", "he_so_tru", "he_so_cong") FROM stdin;
4c6892d9-08b6-40c7-90fb-357745b185c6	10A3	Chiều	TN	9	Nguyễn Thị Trâm Anh	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
d310f4db-72b5-4ec3-9200-ae53af36051f	10A4	Chiều	TN	8	Phạm Hà Anh	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
4dec191f-67f7-40e1-ae29-1f402c50c046	10A5	Chiều	XH	7	Nguyễn Thị Minh Hằng	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
515ff95e-a824-473a-82ee-0aa2f9cd1bd4	10A6	Chiều	XH	1	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
3e472426-2282-4407-82c2-331bf418fc7f	10A7	Chiều	XH	2	Phạm Khánh Chi	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
0752aefe-02d6-410a-84a7-40260303f0a3	10A8	Chiều	XH	3	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
8eddec37-5c16-40a8-83af-5c94fd6ac02e	10A9	Chiều	XH	4	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
bf3de950-ced7-4bb1-b8a2-4433a53e4e29	10A10	Chiều	XH	5	Hồ Thị Ngọc Trâm	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
7ba87a2c-261e-454b-8c9d-bb35fd06eed7	10A11	Chiều	XH	6	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
29ad20ee-673d-4c83-8589-7bb0dee8d6d1	11C1	Chiều	TN	12	Lê Minh Phương	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
1868a20c-490f-4db2-bc22-d85f4f69b497	11C2	Chiều	TN	13	Nguyễn Thị Yến Nhi	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
3ab3bcb4-3575-43c6-95ae-73f824b28ef3	11C3	Chiều	TN	14	Phạm Minh Anh	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
b810e758-01b0-43f5-aa70-8a9088efa2fd	11C4	Chiều	TN	15	Cù Hoàng Gia An	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
f603988f-cb60-4443-940a-d3c0116c784c	11C5	Chiều	TN	16	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
49482452-f8a6-4345-a1e6-0506a641cd2f	11C6	Sáng	XH	1	Vũ Đỗ Thùy Lâm	Trần Thị Huệ	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
0372fedc-3ce9-4484-823e-d7587838ca34	11C7	Sáng	XH	2	nguyễn hồng lai	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
473ec1ae-2792-4f8f-a2dd-f5803b44186a	11C8	Sáng	XH	3	Nguyễn Trung Hiếu	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
70924dff-ae3f-4737-bc36-34503d81d2f0	11C9	Sáng	XH	4	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	11C10	Sáng	XH	5	Nguyễn Ngọc Tiên Nhi	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
a9b2b57f-b578-4799-a790-c951def81dc4	11C11	Sáng	XH	6	Bùi Thị Tường Vy	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
d9432471-04ff-4bae-b307-ca83ee8907c2	11C12	Sáng	XH	7	Nguyễn Thị Ngọc Hân	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
954194a1-bde4-41fc-8fc2-196f4f77c43c	12B1	Sáng	TN	8	Phạm Ngọc Gia Hân	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
0759f20d-917b-497c-a424-c1c80b3a9eee	12B2	Sáng	TN	9	Hoàng Thị Thu Huyền	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
4f330808-8e49-4958-a90d-945234bd6d66	12B3	Sáng	TN	10	Nguyễn Gia Hân	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
362d1fb7-681a-4425-a1d9-7b5cbe3243b5	12B4	Sáng	TN	11	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
f9353b84-a3a8-49bf-b97f-e1fd07619c34	12B5	Sáng	XH	12	Hoàng Thị Quỳnh Chi	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
229ebe21-a1f4-4762-992e-525d59e56343	12B6	Sáng	XH	13	Nguyễn Thanh Phương	Nguyễn Thị Thảo Trinh	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	12B7	Sáng	XH	14	Trần Lê Ngọc Khánh	Võ Thị Bình	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
df556f4e-09a0-4224-b29b-7d9912eef51c	12B8	Sáng	XH	15	Quế Trân	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
55ccbeef-a96a-4801-9bb9-c35f17e4b669	12B9	Sáng	XH	16	Thành Tín	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
f9f7ba97-9aba-4cd0-bb64-74567c927c56	12B10	Sáng	XH	17	Lê Tiến Công	Đoàn Thị Minh Hương	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-06-16 02:27:51.970634+00	2026-05-12 09:21:22.021491+00	1	1
35e180f6-6d54-4a30-a1ac-a55760d259f7	10A1	Chiều	CB	11	Nguyễn Khánh Linh	Nguyễn văn a	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-08-12 13:23:31.247427+00	2026-05-12 09:21:22.021491+00	2	2
2ad031fd-d814-44c0-a31a-144fd9b75bce	10A2	Chiều	TN	10	Lê Hồ Hoài An	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-08-12 13:36:29.281471+00	2026-05-12 09:21:22.021491+00	2	2
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."settings" ("id", "title1", "title2", "diemsan", "aiprompttemplate", "geminiapikey", "diemsanhocky", "aiassistantprompt", "thongbaochamdiem", "doituongthongbao", "noidungthongbao", "thongbaodoanvien", "autopenaltytime", "autopenaltypoints", "autopenaltycriteria", "autopenaltyenabled", "autopenaltyreporter", "autopenaltyday", "thongbaophattriendoan", "excel_header_left", "excel_header_right", "excel_footer_left", "excel_footer_right", "word_header_left", "word_header_right", "word_footer_left", "word_footer_right", "namhoc", "createdat", "updatedat", "cloudinary_cloud_name", "cloudinary_upload_preset", "cloudinary_api_key", "cloudinary_api_secret", "r2_account_id", "r2_access_key_id", "r2_secret_access_key", "r2_bucket_name", "r2_custom_domain", "show_class_select_gvcn", "diem_tot", "diem_kha", "diem_tb", "diem_yeu", "ti_trong_diem_tuan", "ti_trong_diem_hoc_tap") FROM stdin;
8cd408b6-c59d-46ef-b619-81fc0f9da248	HỆ THỐNG QUẢN LÝ THI ĐUA	Đoàn trường THPT ABC (Giới thiệu)1	300			100						23:55	30	Lỗi không báo cáo điểm tuần	t	Hệ thống tự động	0		[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[U][C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[C][B]NGƯỜI LẬP BIỂU\n[C][I](Ký và ghi rõ họ tên)\n\n\n\n[C]{{HOTEN}}	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]Lê Trung Thành	[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[L][B]NƠI NHẬN:\n[L]- Như Điều 1;\n[L]- Lưu VT.	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]Lê Trung Thành	7bf537ba-8581-49ec-8bd1-7922b3a6e5db	2026-07-11 08:29:28.818774+00	2026-08-13 08:41:31.532198+00	du8ro0tqr	minh_chung_360	532496326355534	\N	707664771b38d2605f49a2c0d5cdb770	ac84c89545417ee5c01e4f77d2cdeede	\N	hethongquanlythidua-minhchung-gioithieu	https://pub-45b42ded95594cb896fe13d8081f860d.r2.dev	Không hiển thị	12	7	4	1	50	50
c7169282-3b3c-4821-9b9e-13d6350511af	HỆ THỐNG QUẢN LÝ THI ĐUA	Đoàn trường THPT ABC (Giới thiệu)	300	Bạn là chuyên viên phân tích dữ liệu thi đua cấp cao, là một Bí thư đoàn trường. Hãy lập Báo cáo Tổng hợp Thi đua Học sinh với văn phong hành chính, trang trọng, khách quan và khoa học.\nYêu cầu trình bày:\n•\tKhông câu nệ, không lời chào, vào thẳng nội dung báo cáo.\n•\tSử dụng ngôn ngữ hành chính chuẩn mực (Ví dụ: Thay vì "vi phạm", hãy dùng "tồn tại hạn chế"; thay vì "lời khuyên", hãy dùng "định hướng khắc phục").\n•\tSử dụng Markdown: Tiêu đề rõ ràng, Bảng số liệu, Danh sách phân tích.\nThông tin chung:\n•\tThời gian: {{tuan}}, Học kỳ {{hocKy}}, Năm học {{namHoc}}.\n•\tĐối tượng: Các Chi đoàn thuộc hệ thống quản lý.\nDữ liệu đầu vào: > {{data}}\nNhiệm vụ phân tích:\n1.\tTổng quan tình hình: Khái quát chung về ý thức kỷ luật và phong trào thi đua trong giai đoạn này.\n2.\tPhân tích chỉ số thi đua: Thống kê các nội dung hạn chế phổ biến nhất (phân tích theo tần suất xuất hiện).\n3.\tBiểu dương điển hình: Đánh giá các đơn vị có thành tích xuất sắc và các mặt tích cực ghi nhận được (điểm cộng).\n4.\tĐánh giá chi tiết đơn vị: Lập bảng nhận xét cho từng chi đoàn bao gồm: Ưu điểm, Hạn chế tồn tại và Phương hướng xử lý/duy trì.\n5.\tKết luận và Kiến nghị: Đưa ra đánh giá tổng thể về xu hướng thi đua và đề xuất giải pháp cho Ban giám hiệu/Đoàn trường.\nLưu ý: Nếu dữ liệu không có điểm trừ, hãy tập trung phân tích các mô hình tiên tiến và sự ổn định của nề nếp trường học.\n- Không thêm vào tiêu đề trên đầu báo cáo.\n- Không thêm vào người lập báo cáo.\n- Các Mục đều phải đánh chỉ số rõ ràng khoa học.\nLưu ý: Tuyệt đối không ghi tên tiêu đề báo cáo vì bên trên đã có rồi	AQ.Ab8RN6K-Vx0AFZkSRF9dZgacZg8YLkWQ8CWZGHmgIbNv_AWcvw	100	Bạn là Trợ lý AI thông minh cho hệ thống Quản lý Đoàn viên và Chấm điểm thi đua THPT Lê Hoàn.\nNhiệm vụ của bạn là hỗ trợ người dùng thực hiện các thao tác trên TOÀN BỘ các bảng dữ liệu của hệ thống theo đúng phân quyền.\n\nCÁC BẢNG DỮ LIỆU:\n1. qlchidoan: Quản lý thông tin các chi đoàn.\n2. taikhoan: Quản lý tài khoản người dùng.\n3. doanvien: Quản lý thông tin đoàn viên.\n4. tieuchitd: Quản lý các tiêu chí thi đua (điểm cộng/trừ).\n5. phancong: Quản lý phân công chấm chéo giữa các lớp.\n6. chamdiem: Ghi nhận kết quả chấm điểm thi đua hàng ngày.\n7. namhoc: Quản lý các năm học và học kỳ.\n8. tuanhoc: Quản lý các tuần học.\n9. phanquyen: Quản lý phân quyền người dùng.\n10. settings: Cấu hình hệ thống.\n\nQUY TẮC PHÂN QUYỀN NGHIÊM NGẶT:\n- Bạn phải tuân thủ tuyệt đối quy tắc phân quyền của ứng dụng.\n- Người dùng hiện tại:\n  + Tên đăng nhập: {{username}}\n  + Họ tên: {{fullName}}\n  + Vai trò: {{role}}\n  + Chi đoàn: {{chiDoan}}\n  + ID: {{userId}}\n\n- Quyền hạn theo vai trò:\n  + Admin: Có toàn quyền trên TẤT CẢ các bảng.\n  + BTV/BCH (Ban Thường vụ / Ban Chấp hành): Có quyền trên hầu hết các bảng (qlchidoan, doanvien, tieuchitd, phancong, chamdiem, namhoc, tuanhoc), trừ việc quản lý tài khoản (taikhoan).\n  + Người chấm điểm (NC): \n    * Chỉ được quản lý đoàn viên (doanvien) thuộc chi đoàn của mình ({{chiDoan}}).\n    * Chỉ được tạo chấm điểm (chamdiem) cho lớp mình được phân công chấm (kiểm tra trong phancong).\n    * Không có quyền trên các bảng khác.\n  + Đoàn viên (DV): Chỉ có quyền xem, không có quyền chỉnh sửa bất kỳ bảng nào.\n\n- Nếu người dùng yêu cầu làm việc vượt quá quyền hạn của họ, bạn phải từ chối ngay.\n\n- Cách từ chối:\n  + Nếu chưa đăng nhập: "Xin lỗi, tôi không có quyền làm việc này. Việc này đòi hỏi bạn phải đăng nhập vào hệ thống trước."\n  + Nếu sai vai trò: "Xin lỗi, tôi không có quyền làm việc này. Việc này đòi hỏi bạn phải có quyền [Tên quyền cần thiết] để thực hiện."\n\nKhi người dùng yêu cầu thao tác dữ liệu (tạo, sửa, xóa), hãy sử dụng công cụ 'manage_data'.\nKhi người dùng yêu cầu phân tích dữ liệu, hãy sử dụng 'get_system_context' để lấy dữ liệu thực tế trước khi đưa ra nhận xét.\n\nNgữ cảnh hiện tại:\n- Năm học: {{namHoc}}\n- Học kỳ: {{hocKy}}\n- Tuần: {{tuan}}\n\nHãy luôn trả lời bằng tiếng Việt, thân thiện và chuyên nghiệp		Tất cả			23:55	30	Lỗi không báo cáo điểm tuần	t	Hệ thống tự động	0		[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[U][C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[C][B]NGƯỜI LẬP BIỂU\n[C][I](Ký và ghi rõ họ tên)\n\n\n\n[C]{{HOTEN}}	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]Lê Trung Thành	[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[L][B]NƠI NHẬN:\n[L]- Như Điều 1;\n[L]- Lưu VT.	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]Lê Trung Thành	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:17:29.603726+00	2026-08-13 08:41:28.693021+00	du8ro0tqr	minh_chung_360	532496326355534	62WMQVmN_LIKaqP6pJEHlSHcbnk	151de50b25d3d0fe070b13eaf76c771e	aaf51778319d255d40de26b003580e03	7a6ebcd673f726525577497214327dfc9074ab74901bc5bfea7a5a9c41b862ae	hethongquanlythiduaidvn	https://pub-4d071bdc829e4179b658d8b3dac1e105.r2.dev	Không hiển thị	12	7	4	1	50	50
\.


--
-- Data for Name: taikhoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."taikhoan" ("id", "username", "password", "fullname", "role", "updatedat", "chidoan_id", "createdat", "doanvien_id", "sl_dangnhap", "tg_truycap") FROM stdin;
a0389d2c-caf7-4655-bdb2-8bca7551e46f	Nguoicham11c3mb6hi	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C3	NC	2026-08-15 23:41:10.132104+00	8eb65c48-fb35-419d-9c3a-07d16f553f3a	2026-08-15 23:41:10.132104+00	\N	0	\N
8d70cec7-4f5f-4478-84c6-38fc2e4c006b	Nguoicham11c4fha5z	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C4	NC	2026-08-15 23:41:10.132104+00	bdc9d710-be4b-4b41-beff-95979da345f7	2026-08-15 23:41:10.132104+00	\N	0	\N
e78de3d2-f9f4-4a43-bdef-5d32df32e199	Nguoicham11c5wb8ru	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C5	NC	2026-08-15 23:41:10.132104+00	b2a70b61-e3e5-4e22-a941-814e6d624305	2026-08-15 23:41:10.132104+00	\N	0	\N
8317ad60-f0f3-419a-8ebb-ca84c26c334f	Nguoicham11c6891xk	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C6	NC	2026-08-15 23:41:10.132104+00	c139026c-c996-4831-b25c-c152c6df4229	2026-08-15 23:41:10.132104+00	\N	0	\N
3e6a9f41-c5e8-4cd8-aa04-ffc3b3540576	Nguoicham11c7cdjp9	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C7	NC	2026-08-15 23:41:10.132104+00	6bbfe960-c2ae-45d8-8f46-caae91d2b9b0	2026-08-15 23:41:10.132104+00	\N	0	\N
ebd4b20c-4685-489d-a68e-7ff3c67e6e8c	Nguoicham11c8cs93f	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C8	NC	2026-08-15 23:41:10.132104+00	7bf81adc-a445-4bdf-9ddc-fd60524f3a7a	2026-08-15 23:41:10.132104+00	\N	0	\N
b1ffdd82-01e7-41c2-bb4c-3863cc598825	Nguoicham11c9gfgys	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C9	NC	2026-08-15 23:41:10.132104+00	7d3252a2-7221-4d39-a816-4d2278b6158a	2026-08-15 23:41:10.132104+00	\N	0	\N
8b079dfd-f550-401c-b17e-da874b7cf32d	Nguoicham11c109lw6p	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C10	NC	2026-08-15 23:41:10.132104+00	cdce0fb9-3a38-444c-9888-9b3d6c27949e	2026-08-15 23:41:10.132104+00	\N	0	\N
c2ae7cbe-f4ed-43e9-b042-3ee7712eedd3	Bch12b852iiz	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B8	BCH	2026-08-15 23:41:24.894014+00	693a3584-6dea-4dab-bd32-2786b9e8ebd3	2026-08-15 23:41:24.894014+00	\N	0	\N
c1315f97-4071-406f-a39a-3237efc6664b	Bch12b9q9jly	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B9	BCH	2026-08-15 23:41:24.894014+00	9338c71a-2c89-4f91-89fc-827ea1631689	2026-08-15 23:41:24.894014+00	\N	0	\N
4d3e5a80-9e2c-4316-81a7-ae4ea3d93e00	Bch12b10sk60w	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B10	BCH	2026-08-15 23:41:24.894014+00	d8553fed-24fb-4622-8492-cc77616ad142	2026-08-15 23:41:24.894014+00	\N	0	\N
5813e30c-046f-4560-ad1c-853f9b7b4be7	hht	$2a$10$ve/2g5K/ImaPMiKYU0WyzubCakpkc08MYaLCRLNLjsIWpx7VVQA4y	hht	Admin	2026-08-15 03:35:58.84861+00	\N	2026-08-15 03:35:44.363288+00	\N	1	2026-08-15 10:35:59+00
38cb2cd3-d5ed-498f-bd50-f6555145324d	nguyenphamduonganhbv3oo	$2a$10$luc0z2odMtc8INKm8U8hDOk0XtU9xRhRe6kqfAdeZqqEWTsYaI.Ri	Nguyễn Phạm Dương Anh	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	ff274fde-e036-45d3-ac00-aff15ed9dece	0	\N
a1dafda8-6e37-4f5b-88fa-1441fe2b043f	nguyenphamvanbey4tve	$2a$10$jAYwH7Rpui.J3R1s/f/o7eIyCE6xKYGtPLsWolgwcRhIJzpxSwVkq	Nguyễn Phạm Văn Bé	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	5bd84857-9f16-4a7b-9912-b9ceee882f88	0	\N
f5a8b1c1-9bc5-4949-b9ad-d697aff57626	Nguoicham12b109l1f7	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B10	NC	2026-08-15 23:41:10.242408+00	d8553fed-24fb-4622-8492-cc77616ad142	2026-08-15 23:41:10.242408+00	\N	0	\N
bb69e6a4-076e-4073-96e2-27797725ad2e	nguyenluongthanhbinh2zap4	$2a$10$LTO2x4ho.3tBJj.nm/l3puA6CUcDTqTqJi54v8Hv3ZeDPsH..NL4i	Nguyễn Lương Thanh Bình	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	08d657a8-2d18-4fed-8cf8-ad27b923a7d1	0	\N
24d4f4e4-d10d-49b7-ad7f-62cb0ac8cc03	nguyentrankhanhha4a4d2	$2a$10$x9J1j4RDSbZPkRUAd1ZWTuIxK.PdLXvh80r18OE1G4nA1jsE87DQ.	Nguyễn TRẦN KHÁNH HÀ	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	1d6aac1b-bc8b-42b4-811c-a5ebd7d64b61	0	\N
cf9e678b-ad8b-4f82-a8d9-707594e081e8	nguyennguyenconghaumz2ct	$2a$10$8y2c.ocAYDoGBu9kLot0e.7fkVRa4US2A1sv50WujmXFlU74M8KUy	Nguyễn Nguyễn Công Hậu	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	ebf46acb-22e6-4e0a-895b-f5a5d28a4093	0	\N
96ddd380-02f5-4d17-ac01-d3eceeadbeff	nguyennguyenduchieuvx2wy	$2a$10$OJX87WMB5tqH702Xqo.rC.71FPtP2DWNW2qh4TERZPYe5PXrJNaVO	Nguyễn Nguyễn Đức Hiếu	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	bda4ef04-9f4b-4e34-ad37-840f3420d90b	0	\N
bd2e86c3-0b30-4cb5-a77d-fbcec0af847b	nguyennguyenvanhieuwgnc2	$2a$10$QGYL.PTQCJdWoqJ/BA8LrujPo3DER0gSMZ9ID1H/ghe1PG0/Lkc9y	Nguyễn Nguyễn Văn Hiếu	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	d6810a04-750e-4a5a-a37b-d4d5c9177df1	0	\N
37139cab-63ae-4973-ab82-b9dbf30765bc	nguyenlethithuyhoairu60z	$2a$10$IlL3kBw0rtcMopfETiW0AOhWWDsuIGiQSQZAEyfCEAkE0tcTwAmyS	Nguyễn Lê Thị Thúy Hoài	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	c6c29a73-19bc-450e-9c60-83b971a5f5b2	0	\N
c1d64ced-3d55-4d62-bd30-967be8dddb33	nguyendinhngockhanhhuyeneumhw	$2a$10$7/qmPxNodxh80uXuYo3puuqhulZNILVUiUmF9jhesfLqQq.aCXEB2	Nguyễn Đinh Ngọc Khánh Huyền	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	dd6e7e72-0efc-4184-86a5-bf75ff821c61	0	\N
07a4ede9-0b6e-4171-8865-45a2da4ffcea	nguyenphamquochungbamkv	$2a$10$379NqnICj7L8VAbKA9cmd.DcyydA3aAiQyVmNgMsYyvv7uG7vyoQS	Nguyễn Phạm Quốc Hưng	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	7abf1c46-e632-416c-a236-77b735cad37a	0	\N
456c5a51-7c3d-4ca1-9c6c-9f019a0ffd52	nguyendaovietkhanhol3wo	$2a$10$OPxDlRWEHypJeCn4RrH7muYzm9tQVBpB9DgCfYWJ0EVBwMjFgg7mu	Nguyễn Đào Viết Khánh	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	2dcc7033-77eb-44be-b603-e96fe34d03da	0	\N
673411e6-b468-41dd-aae5-a2c1e51bfd1e	nguyennguyenquangkiensh68o	$2a$10$L9KlCEXQuMqcZpeKxNbEqOMN3eQXGUzfyhjgoTpWb9sKBQNvhgGui	Nguyễn Nguyễn Quang Kiên	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	a3add910-2421-4306-85ee-79586d984b44	0	\N
4b6baf68-a7d8-447e-b44e-56f9f3038f53	nguyennguyenkhanhlinh91v1i	$2a$10$7/0r05j3i2EtA5swR2k0zO3EyPrDg91P.dRhDrmzEaI.FCdx4zFsy	Nguyễn Nguyễn Khánh Linh	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	94dd7549-b924-4ad9-b4b9-9ad66be90117	0	\N
c16704e7-05ee-4447-abc5-15d172eeb1ea	nguyennguyenphilong36w60	$2a$10$M6bl.4I4ptMG04N8m6kJhufjBCvSuYKIk5Q96UPF.sl6XH46hnFNa	Nguyễn Nguyễn Phi Long	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	28fdc614-e3bb-4ca0-aa7f-a23fe0e24fed	0	\N
c464267d-889c-4187-8575-fcff914eb4a4	nguyentranducluongzaai8	$2a$10$XTbX8qqkEniQzi9tt7yIL.CogTzuBiYZhrwH1i8boIJq6BAo/bgzu	Nguyễn Trần Đức Lương	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	3887a79b-a272-4c75-95fb-6f9c4276b719	0	\N
f387d27c-0cf4-4935-a3c0-eb03329d409a	nguyenbuingocdatmcanq	$2a$10$hSbvtbSQvRBArr3cvu/wleXS.W5bwGcj.Je0Wfn6LhOenHNHJ0rBC	Nguyễn Bùi Ngọc Đạt	DV	2026-08-15 03:58:41.31176+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	66a985bd-c92a-4ffe-ba56-72f86bbcadfd	3	2026-08-15 10:58:41+00
5d05d505-b42c-4251-99aa-da542602fc1d	hht1	$2a$10$T90piqNzGx6gvBCxMQur5uoYiSDwN2wnvMqrSbEvc28JT/UDXagki	hht1	Admin	2026-08-15 03:59:09.535851+00	\N	2026-08-15 03:40:56.898706+00	\N	3	2026-08-15 10:59:09+00
13cf4a1b-28a7-4836-9ea0-4eaa0b01a28e	nguyenphamduonganhehgwr	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Phạm Dương Anh	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	5937bded-561a-46f2-b2c9-33ed9223f5b4	0	\N
23cd55a8-058a-45a6-8df8-0111ad3f4105	nguyenphamvanbel7cqq	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Phạm Văn Bé	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	eb30c592-a234-498b-afca-65afc1b0cd23	0	\N
d886aea7-5d00-4ee0-894d-54c4ca2d9bed	nguyenluongthanhbinh7xhqg	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Lương Thanh Bình	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	3b1cfc2b-d54b-4e1f-9e54-b998e371dd97	0	\N
464d3e85-3b51-4899-9c0f-1e2a6e34abdf	Admin	$argon2id$v=19$m=65536,t=3,p=4$RyZ9G8hX/VSkDZq0tej/CQ$ENao8cP6o5yBUZ7AuP64TXlgezSjVmnfBxVSd5YQLNQ	Quản trị	Admin	2026-08-17 05:47:03.829821+00	\N	2026-08-15 05:13:59.903386+00	\N	45	2026-08-17 12:47:04+00
86e6966f-e8ba-4596-8624-f4c6e7f84fce	nguyenbuingocdat16gkk	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Bùi Ngọc Đạt	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	5974ac16-3f3c-44a0-a57c-9102382cf7fd	0	\N
be066c27-efab-4bbc-921e-f67fee19dc71	nguyentrankhanhhah9scg	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn TRẦN KHÁNH HÀ	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	7011c31a-61a5-48f5-8d59-22fe64b66818	0	\N
f2f50e11-f2cc-453f-9a5c-778bcb7a236d	nguyennguyenconghaun0ik4	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Công Hậu	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	7879adb6-51ef-4031-a43a-8219027a7f59	0	\N
fba9bcbe-7a00-45f5-98bf-2e75fed32e72	nguyennguyenduchieu8p3c7	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Đức Hiếu	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	2d2ec77e-02a1-47ca-b756-5c03273f35e4	0	\N
631fef61-2969-4f6a-a2df-8dba55f35154	nguyennguyenvanhieu3c8sb	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Văn Hiếu	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	535f309d-68af-4b30-a7bd-c3fe769a7834	0	\N
0d089530-360f-4373-b260-ebfce1af0bfb	nguyenlethithuyhoaibel3q	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Lê Thị Thúy Hoài	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	7690055d-2e91-4ad3-8103-0d2efdd50919	0	\N
36ed746b-8dd0-4c0b-b7ac-f4b538c3db5d	nguyendinhngockhanhhuyenwi238	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Đinh Ngọc Khánh Huyền	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	58007dea-8416-47c7-a31d-9349595f0f8d	0	\N
fada5fdb-f811-44de-80ad-822da6808f62	nguyenphamquochungz484j	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Phạm Quốc Hưng	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	9a73f2f7-b97f-4913-a1d7-83a9c24ef455	0	\N
dfc12d00-8bd3-482d-96c8-f249830d8d19	nguyendaovietkhanhgn4ly	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Đào Viết Khánh	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	dc296f51-5ee1-415c-81ee-55908b1288d3	0	\N
c8493e22-99eb-48df-be52-425522142529	nguyennguyenquangkien6b4mz	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Quang Kiên	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	e86a21d8-c5fd-4d2e-8c94-11897c9e3d8b	0	\N
deb289a0-8c7c-46d1-891a-fe0802c497c0	nguyennguyenkhanhlinhob5qh	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Khánh Linh	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	e4e505a6-26c3-4989-aae0-947e25a2ec87	0	\N
dcfd7142-98de-486b-8530-d8f840dce426	nguyennguyenphilong02m7b	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Phi Long	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	f7cce73f-41a8-4219-a811-5057d8f25d6e	0	\N
98253573-9c8b-4c91-8653-22c5e4564923	nguyentranducluongq7dt9	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Trần Đức Lương	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	9abd7ef3-684a-4330-961b-e6fe91b5749e	0	\N
8b5c629e-9217-47e2-a6f4-029ada6b2715	nguyenhothikhanhly86rdg	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Hồ Thị Khánh Ly	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	31182419-2281-4141-a990-01dc814899fe	0	\N
44314c3e-774f-4d58-b0dc-1b8a5844c302	nguyennguyenhoangbaominheotz1	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Hoàng Bảo Minh	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	cc695091-37fd-4e8a-811d-9caf26fe0a70	0	\N
28345f1c-1a8b-405b-82bd-5f77f5a39bdc	nguyenhothunga1gywj	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Hồ Thu Nga	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	3c9b7000-8be2-44f1-a2a4-4d8ced27c96a	0	\N
dce3d37a-b612-479f-81ca-38d1b6ee6324	nguyentrinhthihangnga3rrj2	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Trịnh Thị Hằng Nga	DV	2026-08-15 23:40:58.049483+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.049483+00	f44c57f6-abd7-4220-9a01-3e8aa20e9339	0	\N
5cc4ecf0-2bfc-433c-a656-9515b31089d7	Nguoicham11c11s7ods	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C11	NC	2026-08-15 23:41:10.242408+00	4f95dc5a-d654-451e-95f8-1190d14e9ea4	2026-08-15 23:41:10.242408+00	\N	0	\N
dc17821d-8c72-45e5-84d8-55a5a306950a	Nguoicham11c12kxhkt	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C12	NC	2026-08-15 23:41:10.242408+00	fec4e2ea-2b69-4f0b-b11e-5aac08c3255b	2026-08-15 23:41:10.242408+00	\N	0	\N
35521073-3d13-4730-b03e-3f842e0dc338	Nguoicham12b1s7yaw	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B1	NC	2026-08-15 23:41:10.242408+00	e54c44f1-8254-432f-9fe3-a5dc705341dd	2026-08-15 23:41:10.242408+00	\N	0	\N
d50db433-f0cc-4d82-bf7c-9a33651c7327	Nguoicham12b228qff	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B2	NC	2026-08-15 23:41:10.242408+00	e2b49b7e-8cd1-4073-96d2-20933dded630	2026-08-15 23:41:10.242408+00	\N	0	\N
8ae700cb-8007-4a36-81fd-6c15bdbe2d29	Nguoicham12b3v4u7o	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B3	NC	2026-08-15 23:41:10.242408+00	b2578008-6d95-4628-9d82-1d3aed45382a	2026-08-15 23:41:10.242408+00	\N	0	\N
c497dfb6-7495-4d1d-bea8-dc02052f0537	Nguoicham12b48tgt4	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B4	NC	2026-08-15 23:41:10.242408+00	1a6cfd3e-c013-4395-9b5d-b6076f6da465	2026-08-15 23:41:10.242408+00	\N	0	\N
1ce8d64d-f945-47d0-9dcf-65774d8e5e2a	Nguoicham12b58q53f	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B5	NC	2026-08-15 23:41:10.242408+00	7c976b7d-7c6e-47de-a711-f1540a87ceff	2026-08-15 23:41:10.242408+00	\N	0	\N
c47feeac-a9ab-4421-81a0-294cdc80f84e	Nguoicham12b6m2mbi	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B6	NC	2026-08-15 23:41:10.242408+00	82e04c48-c0ff-46b5-bead-c0442905a447	2026-08-15 23:41:10.242408+00	\N	0	\N
70f4955f-7471-4801-ae33-11c1ee4e2cf9	Nguoicham12b7bn4ts	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B7	NC	2026-08-15 23:41:10.242408+00	dff84d4c-4bd2-42df-a051-9a8aff7e3ce4	2026-08-15 23:41:10.242408+00	\N	0	\N
1e8d7d0d-4457-4230-b774-ee604d46e5b7	Nguoicham12b8ljzgn	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B8	NC	2026-08-15 23:41:10.242408+00	693a3584-6dea-4dab-bd32-2786b9e8ebd3	2026-08-15 23:41:10.242408+00	\N	0	\N
d315a6c9-00c6-4272-b15e-2b133de33326	Nguoicham12b9c4smd	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 12B9	NC	2026-08-15 23:41:10.242408+00	9338c71a-2c89-4f91-89fc-827ea1631689	2026-08-15 23:41:10.242408+00	\N	0	\N
c7167928-46f7-42bf-bb98-09e9ed20acc9	demo	$argon2id$v=19$m=65536,t=3,p=4$ZWVL0eY8xm4inghl9DykFA$270glrUfVxt0bDimRnF1yeqxIWGw2ciP5RlDHI7Ub/g	Demo	Admin	2026-08-16 03:16:12.697151+00	\N	2026-08-16 03:16:12.697151+00	\N	0	\N
d23ad8f5-cfa8-4327-8ad6-1d1dff3f43be	nguyennguyenlucnganh3w21	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Lục Ngạn	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	c5aa70d5-2e5b-4d55-bd26-ba5e0f385f95	0	\N
71d24f12-5159-4213-95fb-31a480d69ce6	nguyenlehoangmyngocpqtre	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Lê Hoàng Mỹ Ngọc	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	e03de094-3295-4845-9227-9ab3b89d6a60	0	\N
81ae5a0b-7dcf-4adb-b863-001fe75b5738	nguyenlethibaongocq8sfr	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Lê Thị Bảo Ngọc	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	7c19005a-7862-4cca-b742-a8bb0ade9cc6	0	\N
9352eb30-5be3-4ce1-af8c-9b07e4fd0828	nguyencaoanhnhanv3kv5	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Cao Anh Nhân	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	af215145-d1c4-4d8e-8ebb-79fb9082630d	0	\N
a0e13278-a3ec-4540-a0c7-bbf2d7e80307	nguyenlevothanhnhatqvk7c	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Lê Võ Thanh Nhật	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	8ee10cc8-dc0c-48ff-b6d8-cd9f9be18982	0	\N
a6ff2c04-3505-4605-a61a-ffc8bca8ea2d	nguyendangthithuphuongtw2s4	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Đặng Thị Thu Phương	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	8e226e44-a623-4098-984b-e2868c7fd177	0	\N
ddf33462-826a-47df-abd1-0078d831c110	nguyendobaoquang138r9	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Đỗ Bảo Quang	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	f4afab56-6984-4adb-92bd-30242d83d772	0	\N
de5ef870-30de-4467-91d2-b300adca8f37	nguyenhohuuquangkql5n	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Hồ Hữu Quang	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	1d676c60-9a8c-4504-a706-511d44f0cf49	0	\N
d740cc99-93b7-4c09-97c6-fb971f407462	nguyenhokhacanhquannl6bq	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Hô Khắc Anh Quân	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	3acdd472-62da-4cd9-a45a-cc2e57faba25	0	\N
411d3a14-817a-4f9b-a5ff-b8506b616e83	nguyenhosyquanztmap	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Hồ Sỹ Quân	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	b7f06187-8478-40f5-9b33-ef7a2a2d8358	0	\N
cce8cfb1-fe52-49d7-86db-fa982dbe22b9	nguyenphamvunhuquynhogcjl	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Phạm Vũ Như Quỳnh	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	db713bd2-0d5f-42b1-8849-c89bb3fbda3c	0	\N
6995cce3-9442-4567-ad48-e4302ed7db35	nguyennguyenngoclanthanhplqga	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Ngọc Lan Thanh	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	418cfe25-cb5b-45fb-93cf-7af0edc02245	0	\N
c20bcf2e-ef0c-4a49-b0d7-ce6254d5e690	nguyenvohanhthao8wfkx	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Võ Hạnh Thảo	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	ccc8cac8-1559-4c6f-b7a4-ecc20d1d9d71	0	\N
a6c2f7e3-a482-4ff3-853e-befbd85dc335	nguyentranhongthebdp5a	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Trần Hồng Thế	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	f6fc5ca2-dcef-40ec-8b10-812591e34908	0	\N
ff4f0193-d4c3-40e3-ae90-56656c159e49	nguyenduongducthinheiwqu	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Dương Đức Thịnh	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	dbfc1013-a572-4b28-932a-71fff8186fcd	0	\N
ce28a5cc-94bc-4248-9d75-45ac0d98bdf6	nguyenphanngocthinhko9t6	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Phan Ngọc Thịnh	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	8528189a-b1ee-4564-ac60-848ef2706303	0	\N
d812ca8a-ad93-48e7-8ee3-d7f522d179cc	nguyenbuithilythukzwi2	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Bùi Thị Lý Thu	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	4be491fe-7474-4d23-abbe-bd13318c0aa2	0	\N
71acde09-c20a-45a8-b17e-5b06117ffd67	nguyenhonguyenkhanhtrangl0crc	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Hồ Nguyễn Khánh Trang	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	4f8af45c-732e-40ec-9597-56379797ef4d	0	\N
3d4bae06-f987-410c-b7b2-044f68cc9d2e	nguyenhothithuytrangdht4b	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Hồ Thị Thùy Trang	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	67adfe02-ff38-48d5-979e-645b5e7d9ddf	0	\N
860cdc91-6d63-4f51-af69-c4a383dc88b2	nguyenlethithuytrangwyd1c	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Lê Thị Thùy Trang	DV	2026-08-15 23:40:58.176888+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.176888+00	8cc4dfdf-982a-4596-8652-1b57b432842e	0	\N
107fd0de-8209-4877-a5c8-a1d467f93d77	Nguoicham10a1sppmb	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A1	NC	2026-08-15 23:41:10.132104+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:41:10.132104+00	\N	0	\N
8c265af2-c28d-4081-ac29-8d72308d4deb	Nguoicham10a2hf3z9	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A2	NC	2026-08-15 23:41:10.132104+00	58c19dcd-c418-4c1d-b256-248aff746476	2026-08-15 23:41:10.132104+00	\N	0	\N
3d79002b-7f30-4150-816c-e965d2b80f3f	Nguoicham10a3vgvke	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A3	NC	2026-08-15 23:41:10.132104+00	a2aa2a51-a0d5-4af3-9e4a-ba8fa1d090a9	2026-08-15 23:41:10.132104+00	\N	0	\N
fe7843c9-036e-4a6e-b910-6e001c43d961	Nguoicham10a5odb0e	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A5	NC	2026-08-15 23:41:10.132104+00	9f221621-512d-4029-8840-12d8ed19fdac	2026-08-15 23:41:10.132104+00	\N	0	\N
288eb110-1b04-4612-b994-8c8f028be0ec	Nguoicham10a6uawtj	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A6	NC	2026-08-15 23:41:10.132104+00	dd18b1e5-f377-4bef-bd17-c8d70983f595	2026-08-15 23:41:10.132104+00	\N	0	\N
a4536b0e-7741-4ff2-a283-aed96d288c5b	Nguoicham10a7ma8vp	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A7	NC	2026-08-15 23:41:10.132104+00	16299531-4b2f-46df-8b58-d7907b9d7e0f	2026-08-15 23:41:10.132104+00	\N	0	\N
f733b209-eb4a-4246-a6d3-af60ba3f6f07	Nguoicham10a8aelzz	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A8	NC	2026-08-15 23:41:10.132104+00	4da46fbc-f3a7-43c4-9a2c-a926d44d68dd	2026-08-15 23:41:10.132104+00	\N	0	\N
5e313936-6f91-4cc3-a861-c0cc13952ecd	Nguoicham10a97w0mt	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A9	NC	2026-08-15 23:41:10.132104+00	2ea48bf2-04f2-47f8-8527-c245ee48e8d1	2026-08-15 23:41:10.132104+00	\N	0	\N
62d5415d-bf92-40d6-b093-5855719496ba	Nguoicham10a10a4cpv	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A10	NC	2026-08-15 23:41:10.132104+00	acf03c18-618e-4dca-89ac-946d2834ee14	2026-08-15 23:41:10.132104+00	\N	0	\N
ec3088c4-53b5-444d-9343-1f79343bed07	Nguoicham10a11m5zoa	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 10A11	NC	2026-08-15 23:41:10.132104+00	e8abc25f-77f7-45f8-a94f-d99f005f6454	2026-08-15 23:41:10.132104+00	\N	0	\N
00863940-f9fd-4b0a-963c-7369acbb709d	Nguoicham11c11dywa	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C1	NC	2026-08-15 23:41:10.132104+00	e6f02b61-d5a0-4bd8-9f55-cb1c5109ca5c	2026-08-15 23:41:10.132104+00	\N	0	\N
24dd7612-b00b-4c33-86bc-c5b05bfa0e97	Nguoicham11c2kztp4	$argon2id$v=19$m=65536,t=3,p=4$PxO3AuYWzhMVzoZv84DjEg$PtDeEy+34jnLmoW96j8/U2h4lwmb3JPqJMiFzeIyYE8	Người chấm 11C2	NC	2026-08-15 23:41:10.132104+00	ff60c253-1612-493b-abc8-5f156e90d654	2026-08-15 23:41:10.132104+00	\N	0	\N
a4e942ac-4834-4e28-992c-fea78a8d170f	Bch11c65rwni	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C6	BCH	2026-08-15 23:41:24.746636+00	c139026c-c996-4831-b25c-c152c6df4229	2026-08-15 23:41:24.746636+00	\N	0	\N
b5bca213-8903-423c-a9f1-45bac9c355d3	Bch11c7g56cq	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C7	BCH	2026-08-15 23:41:24.746636+00	6bbfe960-c2ae-45d8-8f46-caae91d2b9b0	2026-08-15 23:41:24.746636+00	\N	0	\N
556f0c44-3730-4b6e-9102-44032cfaec95	Bch11c8y7k0z	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C8	BCH	2026-08-15 23:41:24.746636+00	7bf81adc-a445-4bdf-9ddc-fd60524f3a7a	2026-08-15 23:41:24.746636+00	\N	0	\N
45e59583-5b55-4903-8556-d334d0a4f43e	Bch11c9v3w0v	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C9	BCH	2026-08-15 23:41:24.746636+00	7d3252a2-7221-4d39-a816-4d2278b6158a	2026-08-15 23:41:24.746636+00	\N	0	\N
c33fbe39-a6f0-45be-a04f-b9019d087137	Bch11c1033mfw	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C10	BCH	2026-08-15 23:41:24.746636+00	cdce0fb9-3a38-444c-9888-9b3d6c27949e	2026-08-15 23:41:24.746636+00	\N	0	\N
b322591c-6977-4c16-811f-90e036d6f1f8	Bch11c116pujl	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C11	BCH	2026-08-15 23:41:24.894014+00	4f95dc5a-d654-451e-95f8-1190d14e9ea4	2026-08-15 23:41:24.894014+00	\N	0	\N
feebb173-5f77-4d25-88d7-5c9c99df1f40	Bch11c124wx3b	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C12	BCH	2026-08-15 23:41:24.894014+00	fec4e2ea-2b69-4f0b-b11e-5aac08c3255b	2026-08-15 23:41:24.894014+00	\N	0	\N
8e83118e-d6c4-4001-8654-e4b3168cc9c5	Bch12b1s9y3q	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B1	BCH	2026-08-15 23:41:24.894014+00	e54c44f1-8254-432f-9fe3-a5dc705341dd	2026-08-15 23:41:24.894014+00	\N	0	\N
fb2d39fa-8a11-4434-baa7-28f823d6c765	Bch12b2yu6mt	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B2	BCH	2026-08-15 23:41:24.894014+00	e2b49b7e-8cd1-4073-96d2-20933dded630	2026-08-15 23:41:24.894014+00	\N	0	\N
c420e6fc-2f53-47b0-9e95-20d25c9ce5a3	Bch12b3qmtru	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B3	BCH	2026-08-15 23:41:24.894014+00	b2578008-6d95-4628-9d82-1d3aed45382a	2026-08-15 23:41:24.894014+00	\N	0	\N
ec53b2cb-9987-4948-b0b1-6ea937470ee6	Bch12b4xi0hf	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B4	BCH	2026-08-15 23:41:24.894014+00	1a6cfd3e-c013-4395-9b5d-b6076f6da465	2026-08-15 23:41:24.894014+00	\N	0	\N
3acffd56-36bb-48e7-8703-12e022472b9f	Bch12b52l6c0	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B5	BCH	2026-08-15 23:41:24.894014+00	7c976b7d-7c6e-47de-a711-f1540a87ceff	2026-08-15 23:41:24.894014+00	\N	0	\N
5f747c9c-aad7-4fdb-a31a-69bf8240989a	nguyennguyenthihuyentrangza053	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Thị Huyền Trang	DV	2026-08-15 23:40:58.293285+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.293285+00	6ae84915-ae1a-4ff1-a710-6cc408b84a3d	0	\N
501c8c0f-333f-4cb5-a263-ef140f6d9721	nguyennguyentranhuyentrangdl0af	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Trần Huyền Trang	DV	2026-08-15 23:40:58.293285+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.293285+00	f1671ef3-1f0f-4c87-9911-930fa0087af8	0	\N
4134f443-6220-466a-896e-160da5fcee47	nguyennguyenquoctronguce4x	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Nguyễn Quốc Trọng	DV	2026-08-15 23:40:58.293285+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.293285+00	da17d543-c207-4e09-a0d3-688fef71aa09	0	\N
6c6e73e5-c78a-4970-941c-d7201489ae3d	nguyendoantuongvyw8yia	$argon2id$v=19$m=65536,t=3,p=4$bBzHUmhcPi/qgsRNJVt01A$mzSVOUVX6HNBBtAOdMdAJU9M6xcJ7JMI7LINXBTBk4Q	Nguyễn Đoàn Tường Vy	DV	2026-08-15 23:40:58.293285+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:40:58.293285+00	780ae73d-9e67-4b0a-bf78-1d2fea04220c	0	\N
bba5cd72-4910-4e19-a904-1047471fc5f2	Bch10a14hho9	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A1	BCH	2026-08-15 23:41:24.746636+00	51e9cda4-28d6-4522-8fd0-bdea46d5df79	2026-08-15 23:41:24.746636+00	\N	0	\N
e469a78f-60c0-4eb9-a79f-fc6758515e74	Bch10a20q7cy	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A2	BCH	2026-08-15 23:41:24.746636+00	58c19dcd-c418-4c1d-b256-248aff746476	2026-08-15 23:41:24.746636+00	\N	0	\N
94515259-a7e3-410e-a57a-1f06d5c90c13	Bch10a36nphj	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A3	BCH	2026-08-15 23:41:24.746636+00	a2aa2a51-a0d5-4af3-9e4a-ba8fa1d090a9	2026-08-15 23:41:24.746636+00	\N	0	\N
a35245a7-dd14-40f3-944c-cdcdff45cb8f	Bch10a5mh4f0	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A5	BCH	2026-08-15 23:41:24.746636+00	9f221621-512d-4029-8840-12d8ed19fdac	2026-08-15 23:41:24.746636+00	\N	0	\N
ca80ede9-52f5-4144-a8d1-12567d2ea72a	Bch10a6j78zx	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A6	BCH	2026-08-15 23:41:24.746636+00	dd18b1e5-f377-4bef-bd17-c8d70983f595	2026-08-15 23:41:24.746636+00	\N	0	\N
af49952c-f8d8-4fee-ac3c-6e9491e4a625	Bch10a7zrjz4	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A7	BCH	2026-08-15 23:41:24.746636+00	16299531-4b2f-46df-8b58-d7907b9d7e0f	2026-08-15 23:41:24.746636+00	\N	0	\N
3883ab1b-29ca-4f65-9974-2b4a22d790fc	Bch10a8ybrqk	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A8	BCH	2026-08-15 23:41:24.746636+00	4da46fbc-f3a7-43c4-9a2c-a926d44d68dd	2026-08-15 23:41:24.746636+00	\N	0	\N
0d2e8e38-536f-4566-a8bc-99f2ab692bbc	Bch10a99hy66	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A9	BCH	2026-08-15 23:41:24.746636+00	2ea48bf2-04f2-47f8-8527-c245ee48e8d1	2026-08-15 23:41:24.746636+00	\N	0	\N
4c2d2c76-2e57-4d8d-83a1-fc2196826909	Bch10a108b4cc	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A10	BCH	2026-08-15 23:41:24.746636+00	acf03c18-618e-4dca-89ac-946d2834ee14	2026-08-15 23:41:24.746636+00	\N	0	\N
124141ca-84c2-4103-a2be-264a2ab801af	Bch10a11ifolg	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 10A11	BCH	2026-08-15 23:41:24.746636+00	e8abc25f-77f7-45f8-a94f-d99f005f6454	2026-08-15 23:41:24.746636+00	\N	0	\N
5c22a425-f37b-40ea-8a95-18a9f9a77f91	Bch11c1sah0g	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C1	BCH	2026-08-15 23:41:24.746636+00	e6f02b61-d5a0-4bd8-9f55-cb1c5109ca5c	2026-08-15 23:41:24.746636+00	\N	0	\N
8519a390-93a0-403a-a13d-5d9d212a986c	Bch11c253zu3	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C2	BCH	2026-08-15 23:41:24.746636+00	ff60c253-1612-493b-abc8-5f156e90d654	2026-08-15 23:41:24.746636+00	\N	0	\N
d29bcf56-3905-496e-9be4-da10537b663e	Bch11c3tlvcs	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C3	BCH	2026-08-15 23:41:24.746636+00	8eb65c48-fb35-419d-9c3a-07d16f553f3a	2026-08-15 23:41:24.746636+00	\N	0	\N
e0a7bd1a-b1b3-439c-be39-f4641c5a1d4a	Bch11c4v76wh	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C4	BCH	2026-08-15 23:41:24.746636+00	bdc9d710-be4b-4b41-beff-95979da345f7	2026-08-15 23:41:24.746636+00	\N	0	\N
fec9cce3-7eee-4cad-846a-282a0a3081be	Bch11c54odjj	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 11C5	BCH	2026-08-15 23:41:24.746636+00	b2a70b61-e3e5-4e22-a941-814e6d624305	2026-08-15 23:41:24.746636+00	\N	0	\N
3fe5f5d7-18ef-4bda-89aa-a852e459f3ca	Bch12b64cz5i	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B6	BCH	2026-08-15 23:41:24.894014+00	82e04c48-c0ff-46b5-bead-c0442905a447	2026-08-15 23:41:24.894014+00	\N	0	\N
d1fa428f-ffce-4929-b4c6-943535b99981	Bch12b7i10qj	$argon2id$v=19$m=65536,t=3,p=4$39EnleNhzsivTA6Pz7bYnQ$REor2tjinpBUfkswIetl3aKh4JoV0Cznwm5NZCiZf9w	Ban chấp hành 12B7	BCH	2026-08-15 23:41:24.894014+00	dff84d4c-4bd2-42df-a051-9a8aff7e3ce4	2026-08-15 23:41:24.894014+00	\N	0	\N
688c33dd-72d7-41f2-9c26-acba9bb378c3	nguyenhothikhanhlyx92w0	$2a$10$ocNIvjjNztsCermNHviHYORMuri0bf7QU0AjD9r6nG2ihoHJnh4Jm	Nguyễn Hồ Thị Khánh Ly	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	24ee73f0-abab-4340-b895-0d0b407ea519	0	\N
857e94ef-38dd-4d8c-84c0-7a5ea94587df	nguyennguyenhoangbaominhkmh5y	$2a$10$oFKQ./apTqHvvBz5D.K6E.cW76sal0IbpqzrReY3AUFOwH3wKOzpq	Nguyễn Nguyễn Hoàng Bảo Minh	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	6a8cc4d6-2d9b-4d50-a147-8e84f0d8d693	0	\N
a3d8ebe4-a181-416a-8a33-e824fbd23f0d	nguyenhothunga8kgqc	$2a$10$PNhx3Rohy28di0.ygRvZweberxOzwVqQi6caCpFc5uRfZ82rIXUOO	Nguyễn Hồ Thu Nga	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	a3908f0a-4617-42d0-ba98-d701f7f9b832	0	\N
14a4ef5f-f86a-45b3-8ca6-b5edea4be73b	nguyentrinhthihangngab43ll	$2a$10$mwc5630WgTN/vJ8HEAgnZe/mzpF9cgyVgf3W9PP3Ry1K00WLxLrsm	Nguyễn Trịnh Thị Hằng Nga	DV	2026-08-15 03:56:48.509717+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:48.509717+00	79279359-c6b2-4bc0-bfa7-82c8befff0af	0	\N
18ef2f51-6b37-4524-af19-9e6e529aad63	nguyennguyenlucngan5szu2	$2a$10$xYy4NiusG2M0dv5dBToX6erSwBDOe4/vNOCp1u7wYm115/k74ykwG	Nguyễn Nguyễn Lục Ngạn	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	24acf2af-5e90-4ea0-af02-fa8d087d3f17	0	\N
efad92ab-e375-4fe0-ab14-0c0be155d41b	nguyenlehoangmyngocwjdh9	$2a$10$zNQ2SZEeeDZY7zbJGxlEwuVEhqoJWanIBmkClfH8xcOaCZmOGMvbe	Nguyễn Lê Hoàng Mỹ Ngọc	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	ff78d8b8-9a51-4d02-bb4e-6b8cafbabd34	0	\N
b5561643-81b4-4f72-b6cf-26c5f7be0376	nguyenlethibaongoc1cfpy	$2a$10$H7gSO0Tg1mCpQDBMKh5IOeYScfX.SxThCevkyFQcljNji2L2B6/hi	Nguyễn Lê Thị Bảo Ngọc	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	21f1a3d1-c453-46c9-98d4-006229bb71f0	0	\N
cf3a2afa-3f86-432a-9641-32971b2329f2	nguyencaoanhnhanu211u	$2a$10$EQY5Nu5szEfUeXAHIrHS.OoMYPZYn.ID5osu3J7vKPH9Kp6l94d.S	Nguyễn Cao Anh Nhân	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	6070d770-1a62-4423-987b-9b6b04d6731a	0	\N
ccb1f782-8a4f-428b-96eb-55c5ff823db4	nguyenlevothanhnhat4snme	$2a$10$yxBksMxNQqjmru6MKX18C.FiWEi2lWbLmn8EBXM6OyLZFC.QynHg6	Nguyễn Lê Võ Thanh Nhật	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	bdd0b563-4d04-4ce4-858b-473243286656	0	\N
30a3672f-c1c3-43f7-9850-84918a85261b	nguyendangthithuphuongychdb	$2a$10$ltAZRINJxvXkELIJYpJ1X.2PUy0/wqDlmZ4QChNT.ZRF/HFQcW7H2	Nguyễn Đặng Thị Thu Phương	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	1f23ead5-8bad-40ea-b50b-4889ae25b951	0	\N
b21e4eec-3524-4199-a67a-1efb9620494f	nguyendobaoquango3exb	$2a$10$lbGT0ottPamM9fbHCNkC/u7JKQ259RSQzd9ihJWMXQCbPs4.gJBNK	Nguyễn Đỗ Bảo Quang	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	56661cbe-689f-4dba-abac-7b8ff530bd3e	0	\N
c1449a84-5470-45d7-9134-dda9bf515527	nguyenhohuuquang3arre	$2a$10$.CwsZykg8RIo8W.xZK/hd.O63hMygukHuhwQubFifXMTh5UByIY5m	Nguyễn Hồ Hữu Quang	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	08a186ff-0a6b-4d48-86eb-cb046837c5d6	0	\N
983323f6-0d94-493e-ad44-7630b36f496b	nguyenhokhacanhquane9vc6	$2a$10$WwCTxyba4hdYCyPUIM4GROIsQptRnJUTCME7qR/lZI.lI/6w98Scu	Nguyễn Hô Khắc Anh Quân	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	b28ca061-2a06-4af1-9c59-6bc5bebbbd27	0	\N
96f7386c-0bbb-4f74-ab73-6ced5607a1e3	nguyenhosyquanqgfzf	$2a$10$G2IorGOa21nplcRzn02dG.cPPt2OvvCzLOMsOAJUyO0APlf81WWS6	Nguyễn Hồ Sỹ Quân	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	44e5fafc-b092-497d-842a-887023171093	0	\N
7165ac01-016b-49db-beae-017e880982c0	nguyenphamvunhuquynhf8onh	$2a$10$.B/tn3wbYm4PnP3tx1Dz3eeU8p2DDdbbwD9oQyJAgznbQ2aW1/MZy	Nguyễn Phạm Vũ Như Quỳnh	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	c7a307e4-bd40-44e2-87df-fa6c5c4e5773	0	\N
49f2eab4-688f-4be8-ae5f-c951bbfbc43c	nguyennguyenngoclanthanhxg1bg	$2a$10$etOhrNlvIya.GPRThT.64urKiIdL4fONfWy7ZNitgyK9B4V6ApIe.	Nguyễn Nguyễn Ngọc Lan Thanh	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	af188f23-4b87-4667-9a8b-ecdbd184e25a	0	\N
29b3d0e6-0da6-4cc0-9ccf-891c9c01aa70	nguyenvohanhthaoec5ss	$2a$10$6l97IG7WBT0vLuuawMYtWepnRrjNT4LpDbBSn9i4S8g1tfticLmUK	Nguyễn Võ Hạnh Thảo	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	eeac0126-540c-486c-9d60-1611981fbced	0	\N
e749dc25-0d65-47bd-8a4d-831652d0857f	nguyentranhongthe1dhkb	$2a$10$Usfr6Gc1blpg0qNq.dqaX.O8gKlNZ6N55q0pPdSr67ShoS82fJ3Me	Nguyễn Trần Hồng Thế	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	b28f2b79-eb81-4eb6-9679-ef6f6ea48d6c	0	\N
4b858668-9582-47da-ac95-a920aed6cc02	nguyenduongducthinhgi94v	$2a$10$rqvg3PPeQ85Q99esKmJRW.a/29mijmfeKk//iyS3R7IO3522i2p8G	Nguyễn Dương Đức Thịnh	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	b77fb88a-0c2b-457f-ae8d-5b788929c376	0	\N
227dd64d-32df-4a2c-a6a8-3330ba4b9802	nguyenphanngocthinhmaouh	$2a$10$0S6SVSVPTPuByVEETmya6OQoJX2YdSGQk8FMNiZeK70quf2dG/aG.	Nguyễn Phan Ngọc Thịnh	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	0a69b601-9e46-4b4d-98b8-e4ae7705d3fb	0	\N
e315af28-d9e7-4a0b-861a-ee5709d754e3	nguyenbuithilythuc7pjb	$2a$10$LouevZHEfGdgkcgddJvuhe5YxruVJxZVBB8LctPxsosyFxnThZjA.	Nguyễn Bùi Thị Lý Thu	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	bbb92e37-e04e-4e29-a560-f8b6eee8f7d2	0	\N
6f7a1629-78d9-4381-bd19-1a8f4c9d6574	nguyenhonguyenkhanhtrangaj796	$2a$10$CF5zRf4ZiouMqeU5Nt8JhOjETlCWDCM1dF2aF77S8p.R6Y4MHZcHK	Nguyễn Hồ Nguyễn Khánh Trang	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	1003b661-914c-48cb-8b6d-588eae1bcf71	0	\N
20f45931-9621-4e44-a63c-eed032e52185	nguyenhothithuytrang7zz8y	$2a$10$zdYlDdLx1dCxUw/xMKY3WOku0F/.ocsT50z1pRt4Z99PvDLXqk1Om	Nguyễn Hồ Thị Thùy Trang	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	62317796-c74f-44b4-8d26-4368945c4dc8	0	\N
2650291f-4c32-41c9-a53e-388609e9a370	nguyenlethithuytrang1kbeh	$2a$10$vEOHiW.UIzxbDGyU8I0f6eb.kU36aA/j0yJsX6Rv7JAvRQhd.nKOO	Nguyễn Lê Thị Thùy Trang	DV	2026-08-15 03:56:50.238029+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:50.238029+00	282f61d3-20be-4cbc-ad08-05f63ba2bf37	0	\N
62e2ac5b-f50e-474a-b6d5-534b90bd9945	nguyennguyenthihuyentrang17089	$2a$10$GXqrKL66gBkpuhS4ethksuujrbdtJJhnQxdgNz9eujm7pDOGIXVwi	Nguyễn Nguyễn Thị Huyền Trang	DV	2026-08-15 03:56:51.902784+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:51.902784+00	ab602b7d-fdf9-4b59-9b50-5484f04b906a	0	\N
bcd7863c-4fd8-48ec-bf7a-3a1241b5cf54	nguyennguyentranhuyentrang5w0v3	$2a$10$YtpGIYOdNoax78Z/B99UNeUEGQbvJ8Dt7iRd9gpycQwmkM.ZcLVY2	Nguyễn Nguyễn Trần Huyền Trang	DV	2026-08-15 03:56:51.902784+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:51.902784+00	ecec11e9-ee98-4d41-abe6-4ec37d0293ab	0	\N
4a3ec3b7-e4b7-4e77-85bc-84b54ead11c7	nguyennguyenquoctrongidauv	$2a$10$42XPG/AXjB0y6oFOrIB2s.RwegHwWXraN6pCueCjqi2Rj.JKjWosO	Nguyễn Nguyễn Quốc Trọng	DV	2026-08-15 03:56:51.902784+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:51.902784+00	49e2207e-1f84-4aa0-b3f6-41c8f1792516	0	\N
bdbd1e10-9aad-473d-9b0d-883523436796	nguyendoantuongvyvyo04	$2a$10$Ci/rD27bQq0sSDMT.zDx3eUHSYbJevMXJWJGIBqb86vxVWla/qNBy	Nguyễn Đoàn Tường Vy	DV	2026-08-15 03:56:51.902784+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:56:51.902784+00	cbca41d2-93bd-44ea-bcab-7bf151c5f4ea	0	\N
f1e3fe92-23a4-4861-9dd8-366fe5c6e9b5	Nguoicham10a1zzzmd	$2a$10$XYmHDXAWIKLs8EGiz5iLiuh6mfkk7VznF4q6gA2PDuSwkkMS9JTBi	Người chấm 10A1	NC	2026-08-15 03:59:26.63405+00	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-08-15 03:59:26.63405+00	\N	0	\N
2abfd50f-1991-4218-a512-e04ea3708105	Nguoicham10a2s4dqd	$2a$10$.1OplCwtFMOSjDzMVo1cBuSWfiWySDPl4q3UHV0/hEFeGxPovZK8G	Người chấm 10A2	NC	2026-08-15 03:59:26.63405+00	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-08-15 03:59:26.63405+00	\N	0	\N
13ad8a84-912e-47ee-aa9f-bedaf61bb688	Nguoicham10a3mwxmn	$2a$10$nZTWhHeS9bDevnE2u4OoFeSeDYXMHNp9m4Zh9xpTqA4JuPLSlhYku	Người chấm 10A3	NC	2026-08-15 03:59:26.63405+00	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-08-15 03:59:26.63405+00	\N	0	\N
80f1d7ac-ceb3-4561-92c8-917d0a6b33f4	Nguoicham10a5annhq	$2a$10$C8kdfG2KqZru83NGVj8HA.A5PjoZi.3extoAfH82wY0CRcG.RdkgC	Người chấm 10A5	NC	2026-08-15 03:59:26.63405+00	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-08-15 03:59:26.63405+00	\N	0	\N
31fcc99a-701a-48f2-ae06-85c4b2ff2d4d	Nguoicham10a634zib	$2a$10$BS2/k0f5F6oYhhAeRfJcmO3KIipPrgLTX5mrKZhnVgdJUInmZzyJ2	Người chấm 10A6	NC	2026-08-15 03:59:26.63405+00	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-08-15 03:59:26.63405+00	\N	0	\N
ce9afc61-47bb-48a3-a69f-4f2d3dd37b93	Nguoicham10a7gry8l	$2a$10$3No74953pdz9eDYaCfMAbefkewlFKS8ATmR8xWIh82JUBlKX7EMEy	Người chấm 10A7	NC	2026-08-15 03:59:26.63405+00	3e472426-2282-4407-82c2-331bf418fc7f	2026-08-15 03:59:26.63405+00	\N	0	\N
d14159ea-5683-4c98-9b39-2afe849d7301	Nguoicham10a8u3jpb	$2a$10$9eifnJDLwOxN6uQ87t.88euskM1tnuxtXAFAwIlNqHy9YcGWB16Sy	Người chấm 10A8	NC	2026-08-15 03:59:26.63405+00	0752aefe-02d6-410a-84a7-40260303f0a3	2026-08-15 03:59:26.63405+00	\N	0	\N
5de7c0d7-a00b-4ab3-b13b-ff7ca1b6d41d	Nguoicham10a9gzalm	$2a$10$4HsV0gzQopU/6eXLIbVpzOLGd9imSYGYvnhdxmspVK1fcJ.dPCmwK	Người chấm 10A9	NC	2026-08-15 03:59:26.63405+00	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-08-15 03:59:26.63405+00	\N	0	\N
ac03ad6e-4b5f-4c2b-a7b4-1c004f3f3553	Nguoicham10a10tkzqk	$2a$10$IAeFz5i9et00mnIzzhZSpupSEN9BxsOS01TtKgd8deEZ89030RvL6	Người chấm 10A10	NC	2026-08-15 03:59:26.63405+00	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-08-15 03:59:26.63405+00	\N	0	\N
a41c7171-b4ea-46ca-bdf5-db82c83fd928	Nguoicham10a11nvsae	$2a$10$rY4wMkEkGq8PCGQZz9a7tO4n/FeNGPM/QEr4qBeIEEMIkf0NhgK6C	Người chấm 10A11	NC	2026-08-15 03:59:26.63405+00	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-08-15 03:59:26.63405+00	\N	0	\N
de774bcb-de5a-4770-97a8-33cd4a660fc5	Nguoicham11c13gpvo	$2a$10$NSedyBQIQTId8a6aONFaHeeKNFq7aBqTvHvIaGMXyeRjDYTrq/sMu	Người chấm 11C1	NC	2026-08-15 03:59:26.63405+00	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-08-15 03:59:26.63405+00	\N	0	\N
b0ab3854-db9e-46cd-b367-184a62f872a6	Nguoicham11c26e7qv	$2a$10$z5uUWMJbLGDp6kBztYbG2ONYQmerJTtLkjVDqRC.Zjcrv./qIaVRe	Người chấm 11C2	NC	2026-08-15 03:59:26.63405+00	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-08-15 03:59:26.63405+00	\N	0	\N
cff04e41-2eac-4c2e-943b-d2a8181f25da	Nguoicham11c3z7l8m	$2a$10$qz9ejO0DuoibxZoks2MbbeKpbJLafSHJNzMB3wx4Xw2pBvLbm75Ke	Người chấm 11C3	NC	2026-08-15 03:59:26.63405+00	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-08-15 03:59:26.63405+00	\N	0	\N
c3a4207b-fad7-4d72-ab9f-917fa19c8639	Nguoicham11c4gaf8m	$2a$10$xn3OtByW9B5SNQSxYimWFuNdeH9UCVeOQEWrBXgcigjUWvfy5Oh6y	Người chấm 11C4	NC	2026-08-15 03:59:26.63405+00	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-08-15 03:59:26.63405+00	\N	0	\N
e90ac88d-2afd-4362-b697-8c9a90b6ef33	Nguoicham11c5oina8	$2a$10$H4ew9P8hp.WkfbEKEWP/FurRt8HBVo4wUrL7RoGiCVdzUfCwfpwpK	Người chấm 11C5	NC	2026-08-15 03:59:26.63405+00	f603988f-cb60-4443-940a-d3c0116c784c	2026-08-15 03:59:26.63405+00	\N	0	\N
4390d7e9-4456-428f-b595-a61403943683	Nguoicham11c6dt0a8	$2a$10$jXhKXcd7A9VeXVRfNdoOI.Psj4PfGZLoQunW70JcebJjf2FX6mUSC	Người chấm 11C6	NC	2026-08-15 03:59:26.63405+00	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-08-15 03:59:26.63405+00	\N	0	\N
60fdd515-f80d-4b9a-a0b3-cc9429639239	Nguoicham11c7nsrz2	$2a$10$Ihd1Jewl7AfDwfEIMvVgTemT7s1wFlgtNw/pYWe.OzAYAc5aUdYPi	Người chấm 11C7	NC	2026-08-15 03:59:26.63405+00	0372fedc-3ce9-4484-823e-d7587838ca34	2026-08-15 03:59:26.63405+00	\N	0	\N
a626443a-f65f-4e5d-9710-e3283a628a64	Nguoicham11c8h0zxt	$2a$10$tpghZdLJwayAWOh/xb38c.t5CZCfaKqQxu9SVjB4NfhjtdMUMCdpS	Người chấm 11C8	NC	2026-08-15 03:59:26.63405+00	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-08-15 03:59:26.63405+00	\N	0	\N
01796988-91bb-46da-b5ba-3cf1084e2391	Nguoicham11c905pk2	$2a$10$BjcP.Ixz0a2w8fCIfYwt5OMMoysMrplA/VQ2yj2HUiPOdW1VQmoWe	Người chấm 11C9	NC	2026-08-15 03:59:26.63405+00	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-08-15 03:59:26.63405+00	\N	0	\N
dbd574ca-738c-40e6-b5f9-2ce01f647957	Nguoicham11c10s38bz	$2a$10$tx1XI0MVKJCwfRKgmMLYge9lTrRSWA.x11PDqTwGLD.JOwDLuWpG.	Người chấm 11C10	NC	2026-08-15 03:59:28.337276+00	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-08-15 03:59:28.337276+00	\N	0	\N
b692b7fc-2e2f-4abc-b8e6-31359f148502	Nguoicham11c11c22c8	$2a$10$qMU0am6XK55JJmaArjQlF.Av5iP8DUPtGqJ3F1YeMlqhLFblQv/DW	Người chấm 11C11	NC	2026-08-15 03:59:28.337276+00	a9b2b57f-b578-4799-a790-c951def81dc4	2026-08-15 03:59:28.337276+00	\N	0	\N
cab41401-e1b2-4c30-9a9b-c2aba0377f85	Nguoicham11c12qasiy	$2a$10$CHcglULFvtEfApH61IKunuwcmZ1xSAAFIRePR/dOgVZurVSeVklei	Người chấm 11C12	NC	2026-08-15 03:59:28.337276+00	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-08-15 03:59:28.337276+00	\N	0	\N
fb067e46-c98d-4867-a20a-64cdd42100e2	Nguoicham12b1soros	$2a$10$ZNw/.xnAcm5lH745ht7Ja.oaWViB4.KGmYpL5MPtSLBbVepRoyoZe	Người chấm 12B1	NC	2026-08-15 03:59:28.337276+00	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-08-15 03:59:28.337276+00	\N	0	\N
2a819d42-ade1-456c-85fe-7133a9365b22	Nguoicham12b2q00du	$2a$10$Uim/MJPBGD/QLvmjnKIIxOMaDIggPFjL4X6UI0wd286NmjNOBXp22	Người chấm 12B2	NC	2026-08-15 03:59:28.337276+00	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-08-15 03:59:28.337276+00	\N	0	\N
40840543-d1e0-4333-9c72-7afb7c3b4363	Nguoicham12b3mdjd0	$2a$10$mdL5tH05zszoH5HAW/ceEuxJ0eRLkC8lWsCMn1yvnHA/c8A0zD.N.	Người chấm 12B3	NC	2026-08-15 03:59:28.337276+00	4f330808-8e49-4958-a90d-945234bd6d66	2026-08-15 03:59:28.337276+00	\N	0	\N
1f902a36-eecb-484a-b87e-05ce05bc2fed	Nguoicham12b4fa7hg	$2a$10$z2JpHKKe0RB53KrJ5qmnMeKAL/houmD/embsr2Dv1XCqVvTUuwXF2	Người chấm 12B4	NC	2026-08-15 03:59:28.337276+00	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-08-15 03:59:28.337276+00	\N	0	\N
5122a3de-2fbe-4fbd-aff5-39405ea7179c	Nguoicham12b5qgkg0	$2a$10$M.bUsrilSMZ34ZQ8EH36MOmbbXAT9Zb.5KhtCcjJ55iC3zOtduJT2	Người chấm 12B5	NC	2026-08-15 03:59:28.337276+00	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-08-15 03:59:28.337276+00	\N	0	\N
841f3a65-2f6c-43a5-85c4-18d6b20c8d8b	Nguoicham12b6ancjl	$2a$10$wvFpARx03DacXUayUfT54uAThQkQnzsUNBWUAY2ytsvT1KTscRhym	Người chấm 12B6	NC	2026-08-15 03:59:28.337276+00	229ebe21-a1f4-4762-992e-525d59e56343	2026-08-15 03:59:28.337276+00	\N	0	\N
3f4a4432-bb60-4f31-a58a-e1b40066977f	Nguoicham12b7e9fkj	$2a$10$vSxtzOFLeN0pRDEjC3DV6.4olmMXb2sLtf3FstwD4xDqvkPyfXGXC	Người chấm 12B7	NC	2026-08-15 03:59:28.337276+00	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-08-15 03:59:28.337276+00	\N	0	\N
7dd7904d-cbe5-41e0-822e-2fbd58c92198	Nguoicham12b88ynlk	$2a$10$rMv3JZcC87pQuuZlP9GfO.evWueKsvAYNm.2WTLDiUSoKlo8pEx8i	Người chấm 12B8	NC	2026-08-15 03:59:28.337276+00	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-08-15 03:59:28.337276+00	\N	0	\N
587fbc12-a441-4b35-979e-e97c397a8578	Nguoicham12b9f0gtq	$2a$10$kODgV6fdG2RNxTSl8/CejO//8xe8jXDym3Xw4rImE9iiT584ZkjGC	Người chấm 12B9	NC	2026-08-15 03:59:28.337276+00	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-08-15 03:59:28.337276+00	\N	0	\N
596cc5cb-7903-4956-8ed3-726ca5e50313	Nguoicham12b100ergv	$2a$10$2xqYzCdzvhX8T1VpyFG.SOyRY2EMcKgNnYiCAGcwFZcrbbLSNP8V2	Người chấm 12B10	NC	2026-08-15 03:59:28.337276+00	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-08-15 03:59:28.337276+00	\N	0	\N
04634be0-2deb-4841-815d-ad344631e26b	Nguoicham10a44i7wb	$2a$10$jKWjUXiRHUy1YAjHoH.a9.p9jzQxlU9EEllFIkWhztN6NRXQMRXaq	Người chấm 10A4	NC	2026-08-15 04:01:57.566901+00	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-08-15 03:59:26.63405+00	\N	2	2026-08-15 11:01:57+00
6f61a0af-f0c6-4299-a89c-dfbca10e016b	Admin	$2a$10$jz2k/Rr8A1WVGFaMjMKFWe32YXUXWzfZYyNQSpeqNebs9ZjnVE8PS	Quản trị viên hệ thống	Admin	2026-08-17 05:46:46.313701+00	\N	2026-08-15 03:15:33.235836+00	\N	5	2026-08-17 12:46:47+00
\.


--
-- Data for Name: theodoi360; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."theodoi360" ("id", "nguoi_to_cao_id", "doan_vien_vi_pham_id", "tieu_chi_id", "chi_tiet_vi_pham", "danh_sach_hinh_anh", "url_video", "trang_thai", "nam_hoc_id", "tuan_id", "ngay_vi_pham", "ngay_tao", "hoc_ky", "phan_hoi_bi_to_cao", "phan_hoi_lop", "minh_chung_drive") FROM stdin;
\.


--
-- Data for Name: thongbao_hethong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_hethong" ("id", "title", "content", "sender", "target_role", "target_chidoan_id", "target_user_id", "created_at", "read_by") FROM stdin;
edd97ab6-4c88-427a-b070-6020186b47b0	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Lê Quang Khải - 11C1 - Tuần 36, Ngày 2026-07-11, Thứ 7 - Không đội mũ bảo hiểm, Điểm trừ: 30 - Ghi chú: Không có - Người chấm: Demo	Hệ thống tự động	DV	\N	3c7f724e-cf97-4b1f-8802-1f06a15ae22b	2026-07-11 02:57:48.597+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
4b91f55c-2679-4994-a3a2-fa78da89bf8e	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Lê Quang Khải - 11C1 - Tuần 36, Ngày 2026-07-11, Thứ 7 - Không đội mũ bảo hiểm, Điểm trừ: 30 - Ghi chú: Không có - Người chấm: Demo	Hệ thống tự động	PH	\N	234c79f0-dd8f-4248-ae03-a0b53f687e9f	2026-07-11 02:57:48.597+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
61197e10-3c3c-49c2-bd05-afe40ccc4b90	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Hồ Ngọc Trâm Anh - 10A4 - Tuần 36, Ngày 2026-07-11, Thứ 7 - Đi học muộn2, Điểm trừ: 2 - Ghi chú: Không có - Người chấm: Demo	Hệ thống tự động	DV	\N	566e6d0f-d031-4786-95c7-8a25c7996d12	2026-07-11 02:18:15.685+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
9ce8c99b-d70f-4415-9a82-8a978cbf0df2	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Hồ Ngọc Trâm Anh - 10A4 - Tuần 36, Ngày 2026-07-11, Thứ 7 - Đi học muộn2, Điểm trừ: 2 - Ghi chú: Không có - Người chấm: Demo	Hệ thống tự động	PH	\N	b93dd43f-94ca-4036-8226-fdbe429084a0	2026-07-11 02:18:15.685+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
e2d5262e-64a6-4720-9fe4-1aef66205cb1	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Hồ Ngọc Trâm Anh - 10A4 - Tuần 36, Ngày 2026-07-11, Thứ 7 - Trốn sinh hoạt 15p, Điểm trừ: 2 - Ghi chú: Không có - Người chấm: Demo	Hệ thống tự động	DV	\N	566e6d0f-d031-4786-95c7-8a25c7996d12	2026-07-11 02:18:04.932+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
9d5c61d8-debd-46f9-a1a0-1bf2b3ec4f14	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Hồ Ngọc Trâm Anh - 10A4 - Tuần 36, Ngày 2026-07-11, Thứ 7 - Trốn sinh hoạt 15p, Điểm trừ: 2 - Ghi chú: Không có - Người chấm: Demo	Hệ thống tự động	PH	\N	b93dd43f-94ca-4036-8226-fdbe429084a0	2026-07-11 02:18:04.932+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
7cc5a015-dd42-47bb-bf55-e5349703160e	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Đoàn Thị Ngọc An - 10A7 - Tuần 36, Ngày 2026-07-07, Thứ 3 - Không sơ vin, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	DV	\N	261a9d45-2ebb-464e-aa21-b9e6a54bc49c	2026-07-07 00:51:39.046+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
463334a6-9c77-4c82-b37a-609d52a92637	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Đoàn Thị Ngọc An - 10A7 - Tuần 36, Ngày 2026-07-07, Thứ 3 - Không sơ vin, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	PH	\N	03b5cc72-5aa0-442d-a87c-53180bec60d4	2026-07-07 00:51:39.046+00	["74ce48a4-566c-4f89-9ef6-fc0d938ece94", "e53e265f-5ccd-443f-ac69-3b584e15b835"]
09edb27c-8f9b-40aa-8a6c-016980e45ce1	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Trần Đức Lương - 10A1 - Tuần 36, Ngày 2026-07-12, Chủ nhật - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	PH	\N	c79a73d5-2961-44cc-82cb-b653b07b2d7f	2026-07-12 12:54:05.787+00	["74ce48a4-566c-4f89-9ef6-fc0d938ece94", "e53e265f-5ccd-443f-ac69-3b584e15b835"]
0b43fca6-f738-4001-beba-d58db6945591	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Nguyễn Hoàng Bảo Minh - 10A1 - Tuần 36, Ngày 2026-08-05, Thứ 4 - Không đội mũ bảo hiểm, Điểm trừ: 30 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	PH	\N	457d5835-98ca-4fa5-8bbf-fa702b4016e0	2026-08-05 13:40:14.388+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
2eca8624-0c8c-4134-8e8d-408af290df7c	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Trần Đức Lương - 10A1 - Tuần 36, Ngày 2026-07-12, Chủ nhật - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	DV	\N	bc4e6d32-7216-4840-907c-8716317c74d7	2026-07-12 12:54:05.787+00	["74ce48a4-566c-4f89-9ef6-fc0d938ece94", "e53e265f-5ccd-443f-ac69-3b584e15b835"]
42e2db53-78b9-4766-be38-48406e766bd8	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Nguyễn Hoàng Bảo Minh - 10A1 - Tuần 36, Ngày 2026-08-05, Thứ 4 - Không đội mũ bảo hiểm, Điểm trừ: 30 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	DV	\N	37d22df0-f721-4bb8-8a67-4ba87acd8d03	2026-08-05 13:40:14.388+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
dbff31b0-076a-45f9-8721-cdee654c733f	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Cao Anh Nhân - 10A1 - Tuần 36, Ngày 01/07/2026, Thứ Tư - Ở ngoài khi trống vào lớp, Điểm trừ: 2 - Ghi chú: Từ nguồn phản ánh và đúng sự thật. Chi tiết: d - Người chấm: Demo	Hệ thống tự động	DV	\N	acc7e61b-ee4d-4f46-add6-6919ae461b48	2026-07-11 03:00:05.038+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
de7ed0a9-05d3-409d-b482-1e58d559ff43	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Cao Anh Nhân - 10A1 - Tuần 36, Ngày 01/07/2026, Thứ Tư - Ở ngoài khi trống vào lớp, Điểm trừ: 2 - Ghi chú: Từ nguồn phản ánh và đúng sự thật. Chi tiết: d - Người chấm: Demo	Hệ thống tự động	PH	\N	24574aeb-dd02-4524-8669-eb1153413365	2026-07-11 03:00:05.038+00	["e53e265f-5ccd-443f-ac69-3b584e15b835", "74ce48a4-566c-4f89-9ef6-fc0d938ece94"]
60f04b74-a57b-44b2-83ef-d8cbba06b48a	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Phạm Dương Anh - 10A1 - Tuần 36, Ngày 2026-08-12, Thứ 4 - Đi học muộn2, Điểm trừ: 4 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	DV	\N	18025870-d6b2-498e-8581-1718b3aee6d8	2026-08-12 13:37:55.722+00	[]
4372582f-9662-4d25-b56f-4a65f190b7bb	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Phạm Dương Anh - 10A1 - Tuần 36, Ngày 2026-08-12, Thứ 4 - Đi học muộn2, Điểm trừ: 4 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	PH	\N	4d6974d6-eb72-4a8d-9806-893115f18984	2026-08-12 13:37:55.722+00	[]
6ff0f464-3900-46db-bbad-44eaeaf07b38	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Phạm Dương Anh - 10A1 - Tuần 36, Ngày 2026-08-12, Thứ 4 - Đi học muộn2, Điểm trừ: 4 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	DV	\N	64583280-e01a-480d-9c2c-c27cd07b602d	2026-08-12 13:37:55.722+00	[]
0b55b651-adba-4cfa-ad53-1fc09392e08e	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Phạm Dương Anh - 10A1 - Tuần 36, Ngày 2026-08-12, Thứ 4 - Đi học muộn2, Điểm trừ: 4 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	PH	\N	e821e76c-bc59-4d68-bc5c-f24dd1621693	2026-08-12 13:37:55.722+00	[]
41d4e985-6402-4dd8-bc1d-1061a44fa810	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Hồ Xuân An - 10A3 - Tuần 36, Ngày 2026-08-14, Thứ 6 - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: Người chấm 10A1	Hệ thống tự động	PH	\N	4c1b0c2d-e811-4633-9176-b0a412e26ed4	2026-08-14 04:22:00.578+00	[]
ccc190c9-9e9c-43bb-8907-86defd3b846d	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Hồ Xuân An - 10A3 - Tuần 36, Ngày 2026-08-14, Thứ 6 - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: Người chấm 10A1	Hệ thống tự động	DV	\N	0155de51-4f7c-411c-817a-12245ba01c32	2026-08-14 04:22:00.578+00	[]
8ba3c328-44a9-4114-8395-29b7861ee956	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Hồ Xuân An - 10A3 - Tuần 36, Ngày 2026-08-14, Thứ 6 - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: Người chấm 10A1	Hệ thống tự động	DV	\N	5140ad93-26eb-48c7-899b-9ec6efbc42fe	2026-08-14 04:22:00.578+00	[]
b0844f6a-637c-438a-b393-1cfccba06479	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Hồ Xuân An - 10A3 - Tuần 36, Ngày 2026-08-14, Thứ 6 - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: Người chấm 10A1	Hệ thống tự động	PH	\N	5a73d17d-3b32-4dd4-a101-f42aa1a31e95	2026-08-14 04:22:00.578+00	[]
7b1a7965-9764-4d8d-9c5f-0ebda995416d	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Võ Đại Hùng - 10A3 - Tuần 36, Ngày 2026-08-14, Thứ 6 - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: Người chấm 10A1	Hệ thống tự động	PH	\N	8b876d4f-2f84-4615-9a24-607265a86524	2026-08-14 05:12:50.327+00	[]
42ba6b39-b301-47de-b633-d88c1f221e04	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Võ Đại Hùng - 10A3 - Tuần 36, Ngày 2026-08-14, Thứ 6 - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: Người chấm 10A1	Hệ thống tự động	DV	\N	527098bb-7089-4c2c-8474-1ea3befc7d77	2026-08-14 05:12:50.327+00	[]
1dbbcbbc-a13d-4173-885b-81a12d022d37	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Võ Đại Hùng - 10A3 - Tuần 36, Ngày 2026-08-14, Thứ 6 - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: Người chấm 10A1	Hệ thống tự động	DV	\N	4be2be05-5382-4fe1-9124-98711c55871e	2026-08-14 05:12:50.327+00	[]
76b26ff6-5802-433f-b83c-0892164eecfc	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Võ Đại Hùng - 10A3 - Tuần 36, Ngày 2026-08-14, Thứ 6 - Cúp tiết, Điểm trừ: 5 - Ghi chú: Không có - Người chấm: Người chấm 10A1	Hệ thống tự động	PH	\N	f3bf7907-ad89-4699-9725-31447c4bf9d6	2026-08-14 05:12:50.327+00	[]
2b7aaaa0-78a9-4263-9ced-d53e5154866d	Thông báo vi phạm thi đua (Trừ điểm)	Nội dung: Nguyễn Cao Anh Nhân - 10A1 - Tuần 36, Ngày 2026-08-14, Thứ 6 - Đi học muộn2, Điểm trừ: 4 - Ghi chú: Không có - Người chấm: HHT-Admin	Hệ thống tự động	DV	\N	5013f9e0-96d8-4ab8-85f8-78c464080034	2026-08-14 16:19:42.184+00	[]
\.


--
-- Data for Name: thongbao_riengbiet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_riengbiet" ("id", "namhoc_id", "sender_id", "sender_name", "sender_role", "title", "content", "attachments", "target_roles", "target_chidoan_ids", "start_at", "end_at", "created_at", "updated_at", "read_by") FROM stdin;
\.


--
-- Data for Name: tieuchitd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tieuchitd" ("id", "matieuchi", "tentieuchi", "mota", "loaitieuchi", "diemtru", "diemcong", "ghichu", "updatedat", "hocky", "namhoc", "createdat") FROM stdin;
9b65a7b8-df3c-4c42-96a4-79f21b931e17	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
4bf9d59a-4166-42be-aade-7277c15ee846	TC07	Không bảng tên		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
a73b8391-d973-4d4d-8c87-bd4f32759534	TC08	Sai đồng phục		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
8eba46b9-6acb-4a3f-95c9-9f77c923c516	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
b3c5034a-d499-447d-aa89-8cc5e34fd3be	TC10	Không quai dép		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
ccfedb6b-c0ca-4ea5-9235-d79480ae6db1	TC11	Đi dép lê		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
943862b8-39a5-4eee-aebf-1c4a1cd404f1	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
9a84ccec-1746-4b87-9a89-3dbc3024fdff	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
c5aa2ee2-4f40-46ab-9f52-bca9a6775f5d	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
89869641-8569-4778-b32d-733d2bc3a447	TC15	Sơn móng tay		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
5e2b98bb-6064-4196-ad47-114a9d874a51	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
b9cdcda2-ebe7-43c9-a3c6-242c0e928ac3	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
c8e1da91-ad60-4acc-a9c3-679aaa6c17b9	TC18	chở quá số người qui định		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
e3ea3f56-06a6-4b4c-b5ec-6d9df66cc9b6	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
e27ce27f-4fff-4274-9fcd-9d605658bce4	TC20	Học sinh để xe không đúng quy định		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
8bf9701b-ac47-4d6f-a838-2d6f142a2e9c	TC21	Hút thuốc lá		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
213090b2-a913-4a24-bafc-8fdb13f59167	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
29824e7f-45de-4c9f-85d9-0b2a5ff946e9	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
33943e11-8196-4085-ad32-51f613184eff	TC24	Có thái độ vô lễ với CB, CNV nhà trường: 		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
510fc98d-411d-4ec1-a52c-d16f8e9b6c33	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
a638b999-f511-4286-8ee6-73c745dccf71	TC26	Vệ sinh muộn 		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
ee4dc371-d1b2-4c12-8278-fa1252da74fd	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
570ccd7e-4661-41fb-b881-710bb7d68165	TC28	Học sinh vứt rác không đúng qui định 		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
c1c61f21-7d90-419a-8289-5a6861814b42	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
0089a35c-5d8a-4d83-b815-86a19c555471	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
c8e800d5-8060-41b1-89ea-3b8d47bf0a81	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
236e0986-b7a4-430a-968f-62b3280d84db	TC32	Không cất ghế ngồi chào cờ 		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
2c035d62-7619-4d0e-94b1-86378a8fba3b	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
8ef3a877-8748-4223-ae4f-d5e9f171e227	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
110b43a8-7d09-4ed9-97a2-8bda4ba9048d	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
baaaee9b-43db-451b-abc0-c959e02049f6	TC36	Học sinh vào lớp muộn trong giữa các tiết học 		Vi phạm	0.5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
f433985f-ef80-431d-9aab-a239177fe393	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
a0ec2461-b6fe-486f-a97f-589505ed71c0	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
0364e7a9-94ad-401f-a2bc-7dd9c2e19389	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
dd698c31-eba5-4edd-b783-12e54f3471b6	TC40	Đi chấm trễ		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
d8e914be-c7b5-470a-ae65-55671fffd78b	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
b3d1242c-023f-4fd6-a8e2-58b417053bc0	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
d30c441c-0b1e-4e48-9058-a95c32c21776	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
12e435ed-2933-4f64-b5b6-0c7a53ef8e20	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
1b54442e-15ea-4572-9844-46b564693749	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
f9483aed-cb92-4617-93ff-fec138e5e161	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
1bdc7d44-b442-41b7-bf4a-13cb607dc30a	TC48	Vắng học trên 3 buổi		Vi phạm	0	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
bbf7b391-e7f8-4dc0-89c7-92acfe27364d	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.		Vi phạm	0	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
5f2633e9-e4b5-4e6f-bd9b-76424de251d4	TC50	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
1ac87f0d-b4da-484d-8532-c3f20ddf3f2f	TC51	Lỗi không báo cáo điểm tuần		Vi phạm	30	0	Hệ thống tự trừ	2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
65815fec-52f3-4401-a95e-b71e20280e02	TC01	Đi học muộn2		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
3bb1ebfe-96ff-44de-acce-14583111a359	TC52	Không đi chấm		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
cd8b8223-4b78-4f2b-ae27-d87d1ada3f49	TC53	Trực cầu thang bẩn		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
58533c71-b22f-4936-80b0-4256c97afcef	TC02	Cúp tiết		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
3b4ad540-02ba-4c59-99c1-400a1cee6390	TC03	Cúp chào cờ		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
0bbbdbc3-1fd7-4e87-a277-a434fad3f2b0	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
fcbfdf61-381e-444f-8291-d9f2e4d9ded4	TC10	Không quai dép		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
654cce9b-f701-469a-a5d3-8c24dea2d9a3	TC11	Đi dép lê		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
62ab6de6-b5b0-4a85-a173-e5ef4fd4612a	TC02	Cúp tiết		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
09aaa4c8-2318-4765-ac8e-9c4a2969cbe1	TC03	Cúp chào cờ		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
13146eb7-ebb1-41af-a2fd-b1358dad66fa	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
e3d93349-f5c9-4051-8110-2b85333da282	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
01eaa8fa-ba3d-4582-a58b-d6c444391722	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
3af7f284-5f3a-4c73-bb75-75b66eb242af	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
148fae9c-1850-4221-b530-4fda54391f92	TC15	Sơn móng tay		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
337ef91c-9a53-4c2e-880c-25a19a60379e	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
d079b65b-f38c-45a9-820f-937f1d4341af	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
d3d576df-9a10-473f-bb98-d78dda21bdbc	TC18	chở quá số người qui định		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
5077f5b5-7478-49c9-ade4-ae71bba22d9e	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
31aa419a-7a2c-4c60-a2b1-fcc981d23010	TC20	Học sinh để xe không đúng quy định		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
3e392651-6dcd-4674-bfd8-a8488351dda1	TC21	Hút thuốc lá		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
418c0dd6-3edb-4817-90df-dd995280dfff	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
ebd7864e-7b15-4fea-b0e3-7e690d18ae63	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
309efe80-7a59-4d81-b41c-f8189e468e8a	TC24	Có thái độ vô lễ với CB, CNV nhà trường: 		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
d6fa6591-e95b-4d24-9e69-116f0321b6da	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
d454fb94-7aae-4acd-91be-e8774a4b7a6a	TC26	Vệ sinh muộn 		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
ca0ce3ec-3c78-4c76-bb5d-c0d58f793300	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
63253a27-17e3-450c-90c8-c4c87fb47758	TC28	Học sinh vứt rác không đúng qui định 		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
44293108-0570-4107-9626-c900d8e1549a	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
1b1e1218-b0d1-4351-8eb8-f56e9ff349f6	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
1ad5fe4c-39bb-4c1b-b93d-88df22b24c58	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
09c19187-c09e-4f24-a497-4bf02af84bc3	TC32	Không cất ghế ngồi chào cờ 		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
d344f921-ae59-4159-b5d7-d268c8075105	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
8dd66292-1995-4b5c-a066-100e9470563c	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
7e2cdc12-5f9e-458f-ab17-09984b248f42	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
502a734b-2d92-435e-b5d0-4d53f5487885	TC36	Học sinh vào lớp muộn trong giữa các tiết học 		Vi phạm	0.5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
7bc3ce5d-3ce3-4b8b-91d5-1c7785b982fe	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
4422140b-4f01-4a80-9e5c-78dd0dd6fb60	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
6e9c66f9-90f3-45a6-8171-48984d19b8c8	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
73e6b06e-f601-466e-b824-ee626a05b0aa	TC40	Đi chấm trễ		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
5860197d-b2ee-4879-a21f-6f232231dbf0	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
c3e7c77b-ecda-4409-8b09-18101953787f	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
f1f5fa16-eaf7-41f8-95dd-94ed5ea23ad5	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
9006d1a3-799e-454d-9735-93b5046c7e19	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
f8f406c1-6702-49fa-a86f-2471e31a0051	TC47	Học sinh tham gia đăng bài có nội dung xuyên tạc nói xấu nhà nước, cơ quan chức năng, đơn vị, xúc phạm nhân phẩm danh dự người khác vi phạm pháp luật, gây mất đoàn kết (nếu có bằng chứng).		Vi phạm	50	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
9f33421a-92eb-453c-9715-6b4a870daa54	TC01	Đi học muộn 1		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
7d7811d6-7540-48c5-a604-31c35a4c95ef	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
4778d7dc-5bdb-4db0-a903-713e4185df83	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
c8a7794c-1be4-43ae-9724-f2562fc8c24a	CD01	Điểm 10		Thành tích	0	3		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-06-02 15:56:20.258898+00
87dd1696-0663-4c2d-8a89-5122c4fc9a1a	CD02	Điểm 9		Thành tích	0	2		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-06-02 15:56:37.852805+00
31a8f23d-f550-4f7e-95d4-6f8b32f9ade1	TC56	Cúp 1 tiết		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-06-03 04:00:50.458446+00
306eb73a-89ed-408f-84cf-eacb319f2afd	CD03	Nhặt được của rơi		Thành tích	0	5		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-06-02 15:56:59.55941+00
3274204a-bb12-4203-ad2f-2f70eb252f6b	TC06	Không sơ vin		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK2	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:25:39.370239+00
d364b2dd-66dd-426b-878c-d0b5f6bbfa97	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
89bb3549-7580-4905-b9da-6d8e10d0b457	TC06	Không sơ vin		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
e7c5f693-1633-4c6c-9163-1bbb312b3aa5	TC07	Không bảng tên		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
95b229ed-e759-47f8-9920-40b53151778a	TC08	Sai đồng phục		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
89138e68-c7de-4986-b108-0936cf82b065	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-06-16 02:27:51.632125+00	HK1	1f34a7f5-a416-405f-b15d-921bffa677d5	2026-05-12 09:32:33.09602+00
\.


--
-- Data for Name: tuanhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tuanhoc" ("id", "namhoc", "hocky", "tuan", "tungay", "denngay", "isdefault", "islocked", "createdat", "ghichu", "updatedat") FROM stdin;
\.


--
-- Data for Name: xet_thidua; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."xet_thidua" ("id", "namhoc_id", "hoc_ky", "chidoan_id", "tong_diem_cham_tuan", "tieuchi_1", "tieuchi_2", "tieuchi_3", "tieuchi_4", "tieuchi_5", "tieuchi_6", "tieuchi_7", "tieuchi_8", "tieuchi_9", "tieuchi_10", "tong_diem", "xep_hang", "danh_hieu_thi_dua", "ghi_chu", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_14; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_14" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_15; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_15" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_16; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_16" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_17; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_17" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_18; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_18" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_19; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_19" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_20; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_20" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-08-14 04:01:35
20211116045059	2026-08-14 04:01:35
20211116050929	2026-08-14 04:01:35
20211116051442	2026-08-14 04:01:35
20211116212300	2026-08-14 04:01:35
20211116213355	2026-08-14 04:01:35
20211116213934	2026-08-14 04:01:35
20211116214523	2026-08-14 04:01:35
20211122062447	2026-08-14 04:01:35
20211124070109	2026-08-14 04:01:35
20211202204204	2026-08-14 04:01:35
20211202204605	2026-08-14 04:01:35
20211210212804	2026-08-14 04:01:35
20211228014915	2026-08-14 04:01:35
20220107221237	2026-08-14 04:01:35
20220228202821	2026-08-14 04:01:35
20220312004840	2026-08-14 04:01:35
20220603231003	2026-08-14 04:01:35
20220603232444	2026-08-14 04:01:35
20220615214548	2026-08-14 04:01:35
20220712093339	2026-08-14 04:01:35
20220908172859	2026-08-14 04:01:35
20220916233421	2026-08-14 04:01:35
20230119133233	2026-08-14 04:01:35
20230128025114	2026-08-14 04:01:35
20230128025212	2026-08-14 04:01:35
20230227211149	2026-08-14 04:01:35
20230228184745	2026-08-14 04:01:35
20230308225145	2026-08-14 04:01:35
20230328144023	2026-08-14 04:01:35
20231018144023	2026-08-14 04:01:35
20231204144023	2026-08-14 04:01:35
20231204144024	2026-08-14 04:01:35
20231204144025	2026-08-14 04:01:35
20240108234812	2026-08-14 04:01:35
20240109165339	2026-08-14 04:01:35
20240227174441	2026-08-14 04:01:35
20240311171622	2026-08-14 04:01:35
20240321100241	2026-08-14 04:01:35
20240401105812	2026-08-14 04:01:35
20240418121054	2026-08-14 04:01:35
20240523004032	2026-08-14 04:01:35
20240618124746	2026-08-14 04:01:35
20240801235015	2026-08-14 04:01:35
20240805133720	2026-08-14 04:01:35
20240827160934	2026-08-14 04:01:35
20240919163303	2026-08-14 04:01:35
20240919163305	2026-08-14 04:01:35
20241019105805	2026-08-14 04:01:35
20241030150047	2026-08-14 04:01:35
20241108114728	2026-08-14 04:01:35
20241121104152	2026-08-14 04:01:35
20241130184212	2026-08-14 04:01:35
20241220035512	2026-08-14 04:01:35
20241220123912	2026-08-14 04:01:35
20241224161212	2026-08-14 04:01:35
20250107150512	2026-08-14 04:01:35
20250110162412	2026-08-14 04:01:35
20250123174212	2026-08-14 04:01:35
20250128220012	2026-08-14 04:01:35
20250506224012	2026-08-14 04:01:35
20250523164012	2026-08-14 04:01:35
20250714121412	2026-08-14 04:01:35
20250905041441	2026-08-14 04:01:35
20251103001201	2026-08-14 04:01:35
20251120212548	2026-08-14 04:01:35
20251120215549	2026-08-14 04:01:35
20260218120000	2026-08-14 04:01:35
20260326120000	2026-08-14 04:01:35
20260514120000	2026-08-14 04:01:35
20260527120000	2026-08-14 04:01:35
20260528120000	2026-08-14 04:01:35
20260603120000	2026-08-14 04:01:35
20260605120000	2026-08-14 04:01:35
20260606110000	2026-08-14 04:01:35
20260616120000	2026-08-14 04:01:35
20260624120000	2026-08-14 04:01:35
20260626120000	2026-08-14 04:01:35
20260706120000	2026-08-14 04:01:35
20260707120000	2026-08-14 04:01:35
20260709120000	2026-08-14 04:01:35
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter", "selected_columns") FROM stdin;
138291	786b18ea-9a04-11f1-af08-0a58a9feac02	"public"."chamdiem"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1786945623}], "aud": "authenticated", "exp": 1786949223, "iat": 1786945623, "iss": "https://arwolxwmmydhdavfkgnn.supabase.co/auth/v1", "sub": "140cd2a9-fd20-492f-8d0e-598929dcf97c", "role": "authenticated", "email": "admin@htqltd.vn", "phone": "", "session_id": "67a02f68-ce4a-4190-813c-f7ac37d3d853", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "140cd2a9-fd20-492f-8d0e-598929dcf97c", "email": "admin@htqltd.vn", "email_verified": true, "phone_verified": false}}	2026-08-17 06:25:41.624654	*	\N
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
theodoi360-attachments	theodoi360-attachments	\N	2026-06-18 06:45:05.70456+00	2026-06-18 06:45:05.70456+00	t	f	\N	\N	\N	STANDARD
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-08-14 03:59:47.424374
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-08-14 03:59:47.471646
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-08-14 03:59:47.475818
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-08-14 03:59:47.514592
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-08-14 03:59:47.541069
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-08-14 03:59:47.550125
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-08-14 03:59:47.583713
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-08-14 03:59:47.591217
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-08-14 03:59:47.60608
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-08-14 03:59:47.615215
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-08-14 03:59:47.619872
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-08-14 03:59:47.624929
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-08-14 03:59:47.629501
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-08-14 03:59:47.633666
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-08-14 03:59:47.638841
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-08-14 03:59:47.66372
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-08-14 03:59:47.667924
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-08-14 03:59:47.672223
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-08-14 03:59:47.676735
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-08-14 03:59:47.68233
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-08-14 03:59:47.687685
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-08-14 03:59:47.693473
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-08-14 03:59:47.706605
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-08-14 03:59:47.715612
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-08-14 03:59:47.719694
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-08-14 03:59:47.725631
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-08-14 03:59:47.72995
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-08-14 03:59:47.733875
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-08-14 03:59:47.737576
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-08-14 03:59:47.742344
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-08-14 03:59:47.746158
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-08-14 03:59:47.749794
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-08-14 03:59:47.753841
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-08-14 03:59:47.757497
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-08-14 03:59:47.76122
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-08-14 03:59:47.765209
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-08-14 03:59:47.769596
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-08-14 03:59:47.77344
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-08-14 03:59:47.778523
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-08-14 03:59:47.788848
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-08-14 03:59:47.793198
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-08-14 03:59:47.797143
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-08-14 03:59:47.801026
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-08-14 03:59:47.804859
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-08-14 03:59:47.809024
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-08-14 03:59:47.813494
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-08-14 03:59:47.823362
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-08-14 03:59:47.8277
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-08-14 03:59:47.832827
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-08-14 03:59:47.848321
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-08-14 03:59:47.853417
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-08-14 03:59:47.871165
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-08-14 03:59:47.873006
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-08-14 03:59:47.881497
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-08-14 03:59:47.884168
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-08-14 03:59:47.885819
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-08-14 03:59:47.890682
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-08-14 03:59:47.896014
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-08-14 03:59:47.900252
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-08-14 03:59:47.905256
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-08-14 03:59:47.90956
61	mark-filename-immutable	fe0096517ae9d60aaec1d110172ba9036dc66bb7	2026-08-14 03:59:47.914741
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 2280, true);


--
-- Name: phanquyen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."phanquyen_id_seq"', 11834, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_realtime_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 138291, true);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id");


--
-- Name: cauhinh_tieuchi_xet_thidua cauhinh_tieuchi_xet_thidua_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "cauhinh_tieuchi_xet_thidua_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem chamdiem_pkey2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_pkey2" PRIMARY KEY ("id");


--
-- Name: doanvien doanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_pkey" PRIMARY KEY ("id");


--
-- Name: dotptdoanvien dotptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "dotptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: duytricsdl duytricsdl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."duytricsdl"
    ADD CONSTRAINT "duytricsdl_pkey" PRIMARY KEY ("id");


--
-- Name: gio_hoc_tap gio_hoc_tap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "gio_hoc_tap_pkey" PRIMARY KEY ("id");


--
-- Name: github_settings github_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."github_settings"
    ADD CONSTRAINT "github_settings_pkey" PRIMARY KEY ("id");


--
-- Name: namhoc namhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."namhoc"
    ADD CONSTRAINT "namhoc_pkey" PRIMARY KEY ("id");


--
-- Name: phancong phancong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_pkey" PRIMARY KEY ("id");


--
-- Name: phanquyen phanquyen_doi_tuong_tab_namhoc_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_doi_tuong_tab_namhoc_unique" UNIQUE ("doi_tuong", "tab_chuc_nang", "nam_hoc");


--
-- Name: phanquyen phanquyen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_pkey" PRIMARY KEY ("id");


--
-- Name: ptdoanvien ptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "ptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_endpoint_key" UNIQUE ("endpoint");


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_pkey" PRIMARY KEY ("id");


--
-- Name: ql_baocao ql_baocao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "ql_baocao_pkey" PRIMARY KEY ("id");


--
-- Name: ql_nop_bc ql_nop_bc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "ql_nop_bc_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_ten_nam_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_ten_nam_unique" UNIQUE ("tenchidoan", "namhoc");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_pkey" PRIMARY KEY ("id");


--
-- Name: theodoi360 theodoi360_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_hethong thongbao_hethong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_hethong"
    ADD CONSTRAINT "thongbao_hethong_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_riengbiet thongbao_riengbiet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_riengbiet"
    ADD CONSTRAINT "thongbao_riengbiet_pkey" PRIMARY KEY ("id");


--
-- Name: tieuchitd tieuchitd_matieuchi_namhoc_hocky_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_matieuchi_namhoc_hocky_unique" UNIQUE ("matieuchi", "namhoc", "hocky");


--
-- Name: tieuchitd tieuchitd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_pkey" PRIMARY KEY ("id");


--
-- Name: tuanhoc tuanhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "tuanhoc_pkey" PRIMARY KEY ("id");


--
-- Name: cauhinh_tieuchi_xet_thidua unique_cauhinh_namhoc_hocky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "unique_cauhinh_namhoc_hocky" UNIQUE ("namhoc_id", "hoc_ky");


--
-- Name: chamdiem unique_chamdiem_record; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "unique_chamdiem_record" UNIQUE ("namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "chidoan_id");


--
-- Name: gio_hoc_tap unique_chidoan_tuan_namhoc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "unique_chidoan_tuan_namhoc" UNIQUE ("chidoan_id", "tuan_id", "namhoc_id");


--
-- Name: qlchidoan unique_namhoc_tenchidoan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "unique_namhoc_tenchidoan" UNIQUE ("namhoc", "tenchidoan");


--
-- Name: xet_thidua unique_xet_thidua_chidoan_hocky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "unique_xet_thidua_chidoan_hocky" UNIQUE ("namhoc_id", "hoc_ky", "chidoan_id");


--
-- Name: xet_thidua xet_thidua_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_pkey" PRIMARY KEY ("id");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_14 messages_2026_08_14_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_14"
    ADD CONSTRAINT "messages_2026_08_14_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_15 messages_2026_08_15_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_15"
    ADD CONSTRAINT "messages_2026_08_15_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_16 messages_2026_08_16_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_16"
    ADD CONSTRAINT "messages_2026_08_16_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_17 messages_2026_08_17_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_17"
    ADD CONSTRAINT "messages_2026_08_17_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_18 messages_2026_08_18_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_18"
    ADD CONSTRAINT "messages_2026_08_18_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_19 messages_2026_08_19_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_19"
    ADD CONSTRAINT "messages_2026_08_19_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_20 messages_2026_08_20_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_20"
    ADD CONSTRAINT "messages_2026_08_20_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages"
    ADD CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL))) NOT VALID;


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_created_at_desc" ON "auth"."users" USING "btree" ("created_at" DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_email" ON "auth"."users" USING "btree" ("email");


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_last_sign_in_at_desc" ON "auth"."users" USING "btree" ("last_sign_in_at" DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_name" ON "auth"."users" USING "btree" ((("raw_user_meta_data" ->> 'name'::"text"))) WHERE (("raw_user_meta_data" ->> 'name'::"text") IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_created_at" ON "public"."activity_logs" USING "btree" ("created_at" DESC);


--
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_user_id" ON "public"."activity_logs" USING "btree" ("user_id");


--
-- Name: idx_cauhinh_thidua_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_cauhinh_thidua_namhoc_hocky" ON "public"."cauhinh_tieuchi_xet_thidua" USING "btree" ("namhoc_id", "hoc_ky");


--
-- Name: idx_chamdiem_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_doanvienid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_doanvienid" ON "public"."chamdiem" USING "btree" ("doanvienid");


--
-- Name: idx_chamdiem_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_hocky" ON "public"."chamdiem" USING "btree" ("hocky");


--
-- Name: idx_chamdiem_loaitieuchi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_loaitieuchi" ON "public"."chamdiem" USING "btree" ("loaitieuchi");


--
-- Name: idx_chamdiem_lopcham_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_lopcham_chamlop" ON "public"."chamdiem" USING "btree" ("lopcham", "chamlop");


--
-- Name: idx_chamdiem_optimization_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_optimization_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_optimization_namhoc_hocky_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_hocky_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_chamdiem_optimization_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "tuan");


--
-- Name: idx_chamdiem_thongke; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_thongke" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan", "chamlop");


--
-- Name: idx_doanvien_chidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_namhoc" ON "public"."doanvien" USING "btree" ("chidoan_id", "namhoc");


--
-- Name: idx_doanvien_hoten; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_hoten" ON "public"."doanvien" USING "btree" ("hoten");


--
-- Name: idx_doanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_namhoc" ON "public"."doanvien" USING "btree" ("namhoc");


--
-- Name: idx_dotptdoanvien_nam_hk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_nam_hk" ON "public"."dotptdoanvien" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_namhoc_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_namhoc_isdefault_true" ON "public"."namhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_phancong_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_chamlop" ON "public"."phancong" USING "btree" ("chamlop");


--
-- Name: idx_phancong_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_context" ON "public"."phancong" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_phancong_lopcham; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_lopcham" ON "public"."phancong" USING "btree" ("lopcham");


--
-- Name: idx_phanquyen_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phanquyen_namhoc" ON "public"."phanquyen" USING "btree" ("nam_hoc");


--
-- Name: idx_ptdoanvien_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_dot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dot" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_namhoc" ON "public"."ptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_ql_nop_bc_baocao; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_baocao" ON "public"."ql_nop_bc" USING "btree" ("ql_bao_cao_id");


--
-- Name: idx_ql_nop_bc_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_chidoan" ON "public"."ql_nop_bc" USING "btree" ("chi_doan_id");


--
-- Name: idx_ql_nop_bc_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_doanvien" ON "public"."ql_nop_bc" USING "btree" ("doanvien_id");


--
-- Name: idx_qlchidoan_optimization_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_qlchidoan_optimization_namhoc" ON "public"."qlchidoan" USING "btree" ("namhoc");


--
-- Name: idx_settings_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_settings_namhoc" ON "public"."settings" USING "btree" ("namhoc");


--
-- Name: idx_taikhoan_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_doanvien_id" ON "public"."taikhoan" USING "btree" ("doanvien_id");


--
-- Name: idx_taikhoan_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_role" ON "public"."taikhoan" USING "btree" ("role");


--
-- Name: idx_taikhoan_username_lower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_username_lower" ON "public"."taikhoan" USING "btree" ("lower"("username"));


--
-- Name: idx_theodoi360_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_doanvien" ON "public"."theodoi360" USING "btree" ("doan_vien_vi_pham_id");


--
-- Name: idx_theodoi360_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_namhoc_tuan" ON "public"."theodoi360" USING "btree" ("nam_hoc_id", "tuan_id");


--
-- Name: idx_thongbao_riengbiet_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_thongbao_riengbiet_dates" ON "public"."thongbao_riengbiet" USING "btree" ("start_at", "end_at");


--
-- Name: idx_thongbao_riengbiet_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_thongbao_riengbiet_namhoc" ON "public"."thongbao_riengbiet" USING "btree" ("namhoc_id");


--
-- Name: idx_thongbao_riengbiet_sender; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_thongbao_riengbiet_sender" ON "public"."thongbao_riengbiet" USING "btree" ("sender_id");


--
-- Name: idx_tieuchitd_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_context" ON "public"."tieuchitd" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_tuan_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_tuan_isdefault_true" ON "public"."tuanhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_tuanhoc_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_context" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_tuanhoc_optimization_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_optimization_namhoc_hocky" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_xet_thidua_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_xet_thidua_chidoan" ON "public"."xet_thidua" USING "btree" ("chidoan_id");


--
-- Name: idx_xet_thidua_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_xet_thidua_namhoc_hocky" ON "public"."xet_thidua" USING "btree" ("namhoc_id", "hoc_ky");


--
-- Name: ngay_3_5_idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: ngay_3_5_idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_14_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_14_inserted_at_topic_idx" ON "realtime"."messages_2026_08_14" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_15_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_15_inserted_at_topic_idx" ON "realtime"."messages_2026_08_15" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_16_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_16_inserted_at_topic_idx" ON "realtime"."messages_2026_08_16" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_17_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_17_inserted_at_topic_idx" ON "realtime"."messages_2026_08_17" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_18_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_18_inserted_at_topic_idx" ON "realtime"."messages_2026_08_18" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_19_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_19_inserted_at_topic_idx" ON "realtime"."messages_2026_08_19" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_20_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_20_inserted_at_topic_idx" ON "realtime"."messages_2026_08_20" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_selec" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter", COALESCE("selected_columns", '{}'::"text"[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name_lower" ON "storage"."objects" USING "btree" ("bucket_id", "lower"("name") COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_08_14_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_14_inserted_at_topic_idx";


--
-- Name: messages_2026_08_14_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_14_pkey";


--
-- Name: messages_2026_08_15_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_15_inserted_at_topic_idx";


--
-- Name: messages_2026_08_15_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_15_pkey";


--
-- Name: messages_2026_08_16_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_16_inserted_at_topic_idx";


--
-- Name: messages_2026_08_16_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_16_pkey";


--
-- Name: messages_2026_08_17_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_17_inserted_at_topic_idx";


--
-- Name: messages_2026_08_17_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_17_pkey";


--
-- Name: messages_2026_08_18_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_18_inserted_at_topic_idx";


--
-- Name: messages_2026_08_18_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_18_pkey";


--
-- Name: messages_2026_08_19_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_19_inserted_at_topic_idx";


--
-- Name: messages_2026_08_19_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_19_pkey";


--
-- Name: messages_2026_08_20_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_20_inserted_at_topic_idx";


--
-- Name: messages_2026_08_20_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_20_pkey";


--
-- Name: taikhoan trg_hash_password_before_save; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trg_hash_password_before_save" BEFORE INSERT OR UPDATE OF "password" ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."hash_taikhoan_password_before_save"();


--
-- Name: taikhoan trg_sync_taikhoan_to_auth; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trg_sync_taikhoan_to_auth" AFTER INSERT OR DELETE OR UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."sync_taikhoan_to_auth_users"();


--
-- Name: qlchidoan trigger_chi_doan_deletion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trigger_chi_doan_deletion" AFTER DELETE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chi_doan_deletion"();


--
-- Name: chamdiem update_chamdiem_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_chamdiem_modtime" BEFORE UPDATE ON "public"."chamdiem" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: doanvien update_doanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_doanvien_modtime" BEFORE UPDATE ON "public"."doanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: dotptdoanvien update_dotptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_dotptdoanvien_modtime" BEFORE UPDATE ON "public"."dotptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: duytricsdl update_duytricsdl_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_duytricsdl_modtime" BEFORE UPDATE ON "public"."duytricsdl" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: github_settings update_github_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_github_settings_modtime" BEFORE UPDATE ON "public"."github_settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: namhoc update_namhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_namhoc_modtime" BEFORE UPDATE ON "public"."namhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phancong update_phancong_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phancong_modtime" BEFORE UPDATE ON "public"."phancong" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phanquyen update_phanquyen_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phanquyen_modtime" BEFORE UPDATE ON "public"."phanquyen" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: ptdoanvien update_ptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_ptdoanvien_modtime" BEFORE UPDATE ON "public"."ptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: qlchidoan update_qlchidoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_qlchidoan_modtime" BEFORE UPDATE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: settings update_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_settings_modtime" BEFORE UPDATE ON "public"."settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: taikhoan update_taikhoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_taikhoan_modtime" BEFORE UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tieuchitd update_tieuchitd_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tieuchitd_modtime" BEFORE UPDATE ON "public"."tieuchitd" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tuanhoc update_tuanhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tuanhoc_modtime" BEFORE UPDATE ON "public"."tuanhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_dotdangki_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_dotdangki_fkey" FOREIGN KEY ("dotdangki") REFERENCES "public"."dotptdoanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_namhoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_namhoc_fkey" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id");


--
-- Name: cauhinh_tieuchi_xet_thidua cauhinh_tieuchi_xet_thidua_namhoc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "cauhinh_tieuchi_xet_thidua_namhoc_id_fkey" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_doanvienid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_doanvienid_fkey" FOREIGN KEY ("doanvienid") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien doanvien_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem fk_chamdiem_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "fk_chamdiem_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien fk_doanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "fk_doanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dotptdoanvien fk_dotptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "fk_dotptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_chidoan" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_namhoc" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_tuan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_tuan" FOREIGN KEY ("tuan_id") REFERENCES "public"."tuanhoc"("id") ON DELETE CASCADE;


--
-- Name: phancong fk_phancong_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "fk_phancong_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phanquyen fk_phanquyen_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "fk_phanquyen_namhoc" FOREIGN KEY ("nam_hoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien fk_ptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "fk_ptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ql_baocao fk_ql_baocao_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "fk_ql_baocao_namhoc" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: ql_nop_bc fk_ql_nop_bc_baocao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_baocao" FOREIGN KEY ("ql_bao_cao_id") REFERENCES "public"."ql_baocao"("id") ON DELETE CASCADE;


--
-- Name: ql_nop_bc fk_ql_nop_bc_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_chidoan" FOREIGN KEY ("chi_doan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE SET NULL;


--
-- Name: ql_nop_bc fk_ql_nop_bc_doanvien; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_doanvien" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON DELETE CASCADE;


--
-- Name: qlchidoan fk_qlchidoan_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "fk_qlchidoan_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings fk_settings_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "fk_settings_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thongbao_riengbiet fk_thongbao_riengbiet_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_riengbiet"
    ADD CONSTRAINT "fk_thongbao_riengbiet_namhoc" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: thongbao_riengbiet fk_thongbao_riengbiet_taikhoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_riengbiet"
    ADD CONSTRAINT "fk_thongbao_riengbiet_taikhoan" FOREIGN KEY ("sender_id") REFERENCES "public"."taikhoan"("id") ON DELETE CASCADE;


--
-- Name: tieuchitd fk_tieuchitd_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "fk_tieuchitd_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tuanhoc fk_tuanhoc_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "fk_tuanhoc_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: theodoi360 theodoi360_doan_vien_vi_pham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_doan_vien_vi_pham_fkey" FOREIGN KEY ("doan_vien_vi_pham_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_nam_hoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nam_hoc_fkey" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: theodoi360 theodoi360_nguoi_to_cao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nguoi_to_cao_fkey" FOREIGN KEY ("nguoi_to_cao_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_tieu_chi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tieu_chi_fkey" FOREIGN KEY ("tieu_chi_id") REFERENCES "public"."tieuchitd"("id");


--
-- Name: theodoi360 theodoi360_tuan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tuan_fkey" FOREIGN KEY ("tuan_id") REFERENCES "public"."tuanhoc"("id");


--
-- Name: xet_thidua xet_thidua_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE CASCADE;


--
-- Name: xet_thidua xet_thidua_namhoc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_namhoc_id_fkey" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: cauhinh_tieuchi_xet_thidua Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."cauhinh_tieuchi_xet_thidua" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: doanvien Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."doanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: dotptdoanvien Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."dotptdoanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: namhoc Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."namhoc" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: phancong Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."phancong" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: ql_baocao Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."ql_baocao" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: qlchidoan Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."qlchidoan" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: tieuchitd Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."tieuchitd" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: tuanhoc Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."tuanhoc" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: thongbao_hethong Admin, BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV có full quyền" ON "public"."thongbao_hethong" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: xet_thidua Admin, BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV có full quyền" ON "public"."xet_thidua" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: ptdoanvien Admin, BTV, BCH có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, BCH có full quyền" ON "public"."ptdoanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BCH'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BCH'::"text"])));


--
-- Name: thongbao_riengbiet Admin, BTV, BGH, GVCN có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, BGH, GVCN có full quyền" ON "public"."thongbao_riengbiet" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BGH'::"text", 'GVCN'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BGH'::"text", 'GVCN'::"text"])));


--
-- Name: chamdiem Admin, BTV, NC có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, NC có full quyền" ON "public"."chamdiem" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"])));


--
-- Name: gio_hoc_tap Admin, BTV, NC có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, NC có full quyền" ON "public"."gio_hoc_tap" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"])));


--
-- Name: doanvien BCH chỉ được phép sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "BCH chỉ được phép sửa" ON "public"."doanvien" FOR UPDATE TO "authenticated" USING (("public"."get_auth_role"() = 'BCH'::"text")) WITH CHECK (("public"."get_auth_role"() = 'BCH'::"text"));


--
-- Name: qlchidoan BCH chỉ được phép sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "BCH chỉ được phép sửa" ON "public"."qlchidoan" FOR UPDATE TO "authenticated" USING (("public"."get_auth_role"() = 'BCH'::"text")) WITH CHECK (("public"."get_auth_role"() = 'BCH'::"text"));


--
-- Name: duytricsdl Cho phép mọi người cập nhật duytricsdl; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép mọi người cập nhật duytricsdl" ON "public"."duytricsdl" FOR UPDATE USING (true) WITH CHECK (true);


--
-- Name: duytricsdl Cho phép mọi người xem duytricsdl; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép mọi người xem duytricsdl" ON "public"."duytricsdl" FOR SELECT USING (true);


--
-- Name: taikhoan Cho phép đọc taikhoan để xác thực đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép đọc taikhoan để xác thực đăng nhập" ON "public"."taikhoan" FOR SELECT TO "authenticated", "anon" USING (true);


--
-- Name: github_settings Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."github_settings" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: phanquyen Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."phanquyen" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: settings Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."settings" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: taikhoan Chỉ Admin được sửa tài khoản; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa tài khoản" ON "public"."taikhoan" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: github_settings Mọi người có thể xem; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi người có thể xem" ON "public"."github_settings" FOR SELECT TO "authenticated" USING (true);


--
-- Name: phanquyen Mọi người có thể xem; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi người có thể xem" ON "public"."phanquyen" FOR SELECT TO "authenticated" USING (true);


--
-- Name: settings Mọi người có thể xem; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi người có thể xem" ON "public"."settings" FOR SELECT TO "authenticated" USING (true);


--
-- Name: taikhoan Mọi người có thể xem tài khoản; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi người có thể xem tài khoản" ON "public"."taikhoan" FOR SELECT TO "authenticated" USING (true);


--
-- Name: cauhinh_tieuchi_xet_thidua Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."cauhinh_tieuchi_xet_thidua" FOR SELECT TO "authenticated" USING (true);


--
-- Name: chamdiem Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."chamdiem" FOR SELECT TO "authenticated" USING (true);


--
-- Name: doanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."doanvien" FOR SELECT TO "authenticated" USING (true);


--
-- Name: dotptdoanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."dotptdoanvien" FOR SELECT TO "authenticated" USING (true);


--
-- Name: gio_hoc_tap Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."gio_hoc_tap" FOR SELECT TO "authenticated" USING (true);


--
-- Name: namhoc Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."namhoc" FOR SELECT TO "authenticated" USING (true);


--
-- Name: phancong Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."phancong" FOR SELECT TO "authenticated" USING (true);


--
-- Name: ptdoanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."ptdoanvien" FOR SELECT TO "authenticated" USING (true);


--
-- Name: ql_baocao Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."ql_baocao" FOR SELECT TO "authenticated" USING (true);


--
-- Name: qlchidoan Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."qlchidoan" FOR SELECT TO "authenticated" USING (true);


--
-- Name: thongbao_hethong Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."thongbao_hethong" FOR SELECT TO "authenticated" USING (true);


--
-- Name: thongbao_riengbiet Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."thongbao_riengbiet" FOR SELECT TO "authenticated" USING (true);


--
-- Name: tieuchitd Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."tieuchitd" FOR SELECT TO "authenticated" USING (true);


--
-- Name: tuanhoc Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."tuanhoc" FOR SELECT TO "authenticated" USING (true);


--
-- Name: xet_thidua Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."xet_thidua" FOR SELECT TO "authenticated" USING (true);


--
-- Name: activity_logs Public access activity_logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access activity_logs" ON "public"."activity_logs" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: chamdiem Public access chamdiem; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access chamdiem" ON "public"."chamdiem" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: doanvien Public access doanvien; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access doanvien" ON "public"."doanvien" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: dotptdoanvien Public access dotptdoanvien; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access dotptdoanvien" ON "public"."dotptdoanvien" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: namhoc Public access namhoc; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access namhoc" ON "public"."namhoc" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: phancong Public access phancong; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access phancong" ON "public"."phancong" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: phanquyen Public access phanquyen; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access phanquyen" ON "public"."phanquyen" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: ptdoanvien Public access ptdoanvien; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access ptdoanvien" ON "public"."ptdoanvien" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: qlchidoan Public access qlchidoan; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access qlchidoan" ON "public"."qlchidoan" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: settings Public access settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access settings" ON "public"."settings" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: taikhoan Public access taikhoan; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access taikhoan" ON "public"."taikhoan" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: tieuchitd Public access tieuchitd; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access tieuchitd" ON "public"."tieuchitd" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: tuanhoc Public access tuanhoc; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public access tuanhoc" ON "public"."tuanhoc" TO "authenticated", "anon" USING (true) WITH CHECK (true);


--
-- Name: taikhoan Tài khoản đăng nhập thành công có full quyền trên ; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Tài khoản đăng nhập thành công có full quyền trên " ON "public"."taikhoan" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."activity_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: cauhinh_tieuchi_xet_thidua; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."cauhinh_tieuchi_xet_thidua" ENABLE ROW LEVEL SECURITY;

--
-- Name: chamdiem; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."chamdiem" ENABLE ROW LEVEL SECURITY;

--
-- Name: doanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."doanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: dotptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."dotptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: duytricsdl; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."duytricsdl" ENABLE ROW LEVEL SECURITY;

--
-- Name: gio_hoc_tap; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."gio_hoc_tap" ENABLE ROW LEVEL SECURITY;

--
-- Name: github_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."github_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: namhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."namhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: phancong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phancong" ENABLE ROW LEVEL SECURITY;

--
-- Name: phanquyen; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ENABLE ROW LEVEL SECURITY;

--
-- Name: ptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: push_subscriptions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."push_subscriptions" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_baocao; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_baocao" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_nop_bc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_nop_bc" ENABLE ROW LEVEL SECURITY;

--
-- Name: qlchidoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."qlchidoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: taikhoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."taikhoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: theodoi360; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."theodoi360" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_hethong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_hethong" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_riengbiet; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_riengbiet" ENABLE ROW LEVEL SECURITY;

--
-- Name: tieuchitd; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tieuchitd" ENABLE ROW LEVEL SECURITY;

--
-- Name: tuanhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tuanhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: xet_thidua; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."xet_thidua" ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."activity_logs" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: duytricsdl Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."duytricsdl" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: push_subscriptions Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."push_subscriptions" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: ql_nop_bc Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."ql_nop_bc" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: theodoi360 Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."theodoi360" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects quyen pknxkg_0; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "quyen pknxkg_0" ON "storage"."objects" FOR SELECT USING (("bucket_id" = 'theodoi360-attachments'::"text"));


--
-- Name: objects quyen pknxkg_1; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "quyen pknxkg_1" ON "storage"."objects" FOR INSERT TO "authenticated" WITH CHECK (("bucket_id" = 'theodoi360-attachments'::"text"));


--
-- Name: objects quyen pknxkg_2; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "quyen pknxkg_2" ON "storage"."objects" FOR UPDATE TO "authenticated" USING (("bucket_id" = 'theodoi360-attachments'::"text"));


--
-- Name: objects quyen pknxkg_3; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "quyen pknxkg_3" ON "storage"."objects" FOR DELETE TO "authenticated" USING (("bucket_id" = 'theodoi360-attachments'::"text"));


--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: supabase_admin
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "supabase_admin";

--
-- Name: supabase_realtime chamdiem; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."chamdiem";


--
-- Name: supabase_realtime doanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."doanvien";


--
-- Name: supabase_realtime dotptdoanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."dotptdoanvien";


--
-- Name: supabase_realtime github_settings; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."github_settings";


--
-- Name: supabase_realtime namhoc; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."namhoc";


--
-- Name: supabase_realtime phancong; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."phancong";


--
-- Name: supabase_realtime phanquyen; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."phanquyen";


--
-- Name: supabase_realtime ptdoanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."ptdoanvien";


--
-- Name: supabase_realtime ql_baocao; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."ql_baocao";


--
-- Name: supabase_realtime ql_nop_bc; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."ql_nop_bc";


--
-- Name: supabase_realtime qlchidoan; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."qlchidoan";


--
-- Name: supabase_realtime settings; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."settings";


--
-- Name: supabase_realtime taikhoan; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."taikhoan";


--
-- Name: supabase_realtime thongbao_hethong; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."thongbao_hethong";


--
-- Name: supabase_realtime tieuchitd; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."tieuchitd";


--
-- Name: supabase_realtime tuanhoc; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."tuanhoc";


--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: supabase_admin
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA "extensions" TO "anon";
GRANT ALL ON SCHEMA "extensions" TO "authenticated";
GRANT ALL ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";
GRANT ALL ON SCHEMA "extensions" TO "supabase_auth_admin";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO "anon";
GRANT ALL ON SCHEMA "public" TO "authenticated";
GRANT ALL ON SCHEMA "public" TO "service_role";
GRANT ALL ON SCHEMA "public" TO "supabase_auth_admin";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "realtime" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "realtime" TO "supabase_realtime_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "vault" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "_internal_resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb"); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."_internal_resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql"."_internal_resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql"."_internal_resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."_internal_resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "comment_directive"("comment_" "text"); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."comment_directive"("comment_" "text") TO "postgres";
GRANT ALL ON FUNCTION "graphql"."comment_directive"("comment_" "text") TO "anon";
GRANT ALL ON FUNCTION "graphql"."comment_directive"("comment_" "text") TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."comment_directive"("comment_" "text") TO "service_role";


--
-- Name: FUNCTION "exception"("message" "text"); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."exception"("message" "text") TO "postgres";
GRANT ALL ON FUNCTION "graphql"."exception"("message" "text") TO "anon";
GRANT ALL ON FUNCTION "graphql"."exception"("message" "text") TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."exception"("message" "text") TO "service_role";


--
-- Name: FUNCTION "get_schema_version"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."get_schema_version"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."get_schema_version"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."get_schema_version"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."get_schema_version"() TO "service_role";


--
-- Name: FUNCTION "increment_schema_version"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."increment_schema_version"() TO "postgres";
GRANT ALL ON FUNCTION "graphql"."increment_schema_version"() TO "anon";
GRANT ALL ON FUNCTION "graphql"."increment_schema_version"() TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."increment_schema_version"() TO "service_role";


--
-- Name: FUNCTION "resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb"); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql"."resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql"."resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql"."resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql"."resolve"("query" "text", "variables" "jsonb", "operationName" "text", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "get_auth_chidoan_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "service_role";


--
-- Name: FUNCTION "get_auth_doanvien_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "service_role";


--
-- Name: FUNCTION "get_auth_role"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "service_role";


--
-- Name: FUNCTION "get_secure_chidoan_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_secure_chidoan_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_secure_chidoan_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_secure_chidoan_id"() TO "service_role";


--
-- Name: FUNCTION "get_secure_doanvien_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_secure_doanvien_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_secure_doanvien_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_secure_doanvien_id"() TO "service_role";


--
-- Name: FUNCTION "get_secure_role"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "service_role";


--
-- Name: FUNCTION "handle_chi_doan_deletion"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "service_role";


--
-- Name: FUNCTION "handle_post_like"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "service_role";


--
-- Name: FUNCTION "handle_update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "hash_taikhoan_password_before_save"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."hash_taikhoan_password_before_save"() TO "anon";
GRANT ALL ON FUNCTION "public"."hash_taikhoan_password_before_save"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."hash_taikhoan_password_before_save"() TO "service_role";


--
-- Name: FUNCTION "rpc_authenticate_user"("p_username" "text", "p_password" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_authenticate_user"("p_username" "text", "p_password" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_authenticate_user"("p_username" "text", "p_password" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_authenticate_user"("p_username" "text", "p_password" "text") TO "service_role";


--
-- Name: FUNCTION "rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "service_role";


--
-- Name: FUNCTION "rpc_get_user_by_username"("p_username" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "service_role";


--
-- Name: FUNCTION "sync_taikhoan_to_auth_users"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."sync_taikhoan_to_auth_users"() TO "anon";
GRANT ALL ON FUNCTION "public"."sync_taikhoan_to_auth_users"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."sync_taikhoan_to_auth_users"() TO "service_role";


--
-- Name: FUNCTION "update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "update_modified_column"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "service_role";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "service_role";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "wal2json_escape_identifier"("name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."schema_migrations" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."schema_migrations" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "dashboard_user";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "supabase_auth_admin";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: SEQUENCE "seq_schema_version"; Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "postgres";
GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "anon";
GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "authenticated";
GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "service_role";


--
-- Name: TABLE "activity_logs"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."activity_logs" TO "service_role";
GRANT ALL ON TABLE "public"."activity_logs" TO "supabase_auth_admin";


--
-- Name: TABLE "cauhinh_tieuchi_xet_thidua"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "anon";
GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "authenticated";
GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "service_role";
GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "supabase_auth_admin";


--
-- Name: TABLE "chamdiem"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."chamdiem" TO "anon";
GRANT ALL ON TABLE "public"."chamdiem" TO "authenticated";
GRANT ALL ON TABLE "public"."chamdiem" TO "service_role";
GRANT ALL ON TABLE "public"."chamdiem" TO "supabase_auth_admin";


--
-- Name: TABLE "doanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."doanvien" TO "anon";
GRANT ALL ON TABLE "public"."doanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."doanvien" TO "service_role";
GRANT ALL ON TABLE "public"."doanvien" TO "supabase_auth_admin";


--
-- Name: TABLE "dotptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."dotptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "service_role";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "supabase_auth_admin";


--
-- Name: TABLE "duytricsdl"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."duytricsdl" TO "anon";
GRANT ALL ON TABLE "public"."duytricsdl" TO "authenticated";
GRANT ALL ON TABLE "public"."duytricsdl" TO "service_role";
GRANT ALL ON TABLE "public"."duytricsdl" TO "supabase_auth_admin";


--
-- Name: TABLE "gio_hoc_tap"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "anon";
GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "authenticated";
GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "service_role";
GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "supabase_auth_admin";


--
-- Name: TABLE "github_settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."github_settings" TO "anon";
GRANT ALL ON TABLE "public"."github_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."github_settings" TO "service_role";
GRANT ALL ON TABLE "public"."github_settings" TO "supabase_auth_admin";


--
-- Name: TABLE "namhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."namhoc" TO "anon";
GRANT ALL ON TABLE "public"."namhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."namhoc" TO "service_role";
GRANT ALL ON TABLE "public"."namhoc" TO "supabase_auth_admin";


--
-- Name: TABLE "phancong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phancong" TO "anon";
GRANT ALL ON TABLE "public"."phancong" TO "authenticated";
GRANT ALL ON TABLE "public"."phancong" TO "service_role";
GRANT ALL ON TABLE "public"."phancong" TO "supabase_auth_admin";


--
-- Name: TABLE "phanquyen"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phanquyen" TO "anon";
GRANT ALL ON TABLE "public"."phanquyen" TO "authenticated";
GRANT ALL ON TABLE "public"."phanquyen" TO "service_role";
GRANT ALL ON TABLE "public"."phanquyen" TO "supabase_auth_admin";


--
-- Name: SEQUENCE "phanquyen_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "service_role";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "supabase_auth_admin";


--
-- Name: TABLE "ptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "service_role";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "supabase_auth_admin";


--
-- Name: TABLE "push_subscriptions"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."push_subscriptions" TO "anon";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "authenticated";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "service_role";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "supabase_auth_admin";


--
-- Name: TABLE "ql_baocao"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_baocao" TO "anon";
GRANT ALL ON TABLE "public"."ql_baocao" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_baocao" TO "service_role";
GRANT ALL ON TABLE "public"."ql_baocao" TO "supabase_auth_admin";


--
-- Name: TABLE "ql_nop_bc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_nop_bc" TO "anon";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "service_role";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "supabase_auth_admin";


--
-- Name: TABLE "qlchidoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."qlchidoan" TO "anon";
GRANT ALL ON TABLE "public"."qlchidoan" TO "authenticated";
GRANT ALL ON TABLE "public"."qlchidoan" TO "service_role";
GRANT ALL ON TABLE "public"."qlchidoan" TO "supabase_auth_admin";


--
-- Name: TABLE "settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";
GRANT ALL ON TABLE "public"."settings" TO "supabase_auth_admin";


--
-- Name: TABLE "taikhoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."taikhoan" TO "anon";
GRANT ALL ON TABLE "public"."taikhoan" TO "authenticated";
GRANT ALL ON TABLE "public"."taikhoan" TO "service_role";
GRANT ALL ON TABLE "public"."taikhoan" TO "supabase_auth_admin";


--
-- Name: TABLE "theodoi360"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."theodoi360" TO "anon";
GRANT ALL ON TABLE "public"."theodoi360" TO "authenticated";
GRANT ALL ON TABLE "public"."theodoi360" TO "service_role";
GRANT ALL ON TABLE "public"."theodoi360" TO "supabase_auth_admin";


--
-- Name: TABLE "thongbao_hethong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_hethong" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "service_role";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "supabase_auth_admin";


--
-- Name: TABLE "thongbao_riengbiet"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "service_role";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "supabase_auth_admin";


--
-- Name: TABLE "tieuchitd"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tieuchitd" TO "anon";
GRANT ALL ON TABLE "public"."tieuchitd" TO "authenticated";
GRANT ALL ON TABLE "public"."tieuchitd" TO "service_role";
GRANT ALL ON TABLE "public"."tieuchitd" TO "supabase_auth_admin";


--
-- Name: TABLE "tuanhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tuanhoc" TO "anon";
GRANT ALL ON TABLE "public"."tuanhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."tuanhoc" TO "service_role";
GRANT ALL ON TABLE "public"."tuanhoc" TO "supabase_auth_admin";


--
-- Name: TABLE "xet_thidua"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."xet_thidua" TO "anon";
GRANT ALL ON TABLE "public"."xet_thidua" TO "authenticated";
GRANT ALL ON TABLE "public"."xet_thidua" TO "service_role";
GRANT ALL ON TABLE "public"."xet_thidua" TO "supabase_auth_admin";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_08_14"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_14" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_14" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_15"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_15" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_15" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_16"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_16" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_16" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_17"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_17" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_17" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_18"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_18" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_18" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_19"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_19" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_19" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_20"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_20" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_20" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "service_role";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "supabase_auth_admin";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "service_role";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "supabase_auth_admin";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "auth" GRANT ALL ON TABLES TO "service_role";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "auth" GRANT ALL ON TABLES TO "supabase_auth_admin";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "supabase_auth_admin";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "supabase_auth_admin";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict EObl9lYRSfodcSqnOGcbWVKVmIBRuIVT6tgOOu4qEaoINxeZHOphkUfkmsZX4oa

